import React, { useState } from 'react';
import { useDisasterMode, setDisasterMode } from '../utils/disasterMode';
import { UserProfile, QualityLevel, AppTheme, FontFamilyType, LoginCustomizationData } from '../types';
import {
  X,
  Palette,
  Sparkles,
  Check,
  Tv,
  Eye,
  Trash2,
  Volume2,
  VolumeX,
  Sun,
  SunMedium,
  Zap,
  Sliders,
  Shield,
  Monitor,
  Upload,
  Play,
  Moon,
  Smartphone,
  Bell,
  Type,
  KeyRound,
  RotateCw,
  AlertTriangle,
  User,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';
import { soundManager, triggerHaptic } from '../utils/soundEffects';
import { WallpaperOptions, ChatWallpaperType } from './ChatBackground';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onOpenProfileDrawer?: () => void;
  coolMode: boolean;
  onToggleCoolMode: () => void;
  fontSize: 'small' | 'medium' | 'large';
  onChangeFontSize: (size: 'small' | 'medium' | 'large') => void;
  fontFamily?: FontFamilyType;
  onChangeFontFamily?: (font: FontFamilyType) => void;
  theme?: AppTheme;
  onChangeTheme?: (theme: AppTheme) => void;
  accentColor?: string;
  onChangeAccentColor?: (color: string) => void;
  notificationsEnabled: boolean;
  onToggleNotifications: (enabled: boolean) => void;
  notificationFrequency: 'rare' | 'frequent';
  onChangeNotificationFrequency: (freq: 'rare' | 'frequent') => void;
  quality?: QualityLevel;
  onChangeQuality?: (q: QualityLevel) => void;
  vrMode?: boolean;
  onToggleVrMode?: () => void;
  cinemaMode?: boolean;
  onToggleCinemaMode?: () => void;
  powerSavingMode?: boolean;
  onTogglePowerSavingMode?: () => void;
  sendSoundEnabled?: boolean;
  onToggleSendSound?: () => void;
  chatWallpaper?: ChatWallpaperType;
  onChangeChatWallpaper?: (wallpaper: ChatWallpaperType) => void;
  loginCustomization?: LoginCustomizationData;
  onUpdateLoginCustomization?: (custom: LoginCustomizationData) => void;
  onTestLoginScreen?: () => void;
  onTriggerBsod?: () => void;
}

const THEMES_LIST: Array<{ id: AppTheme; name: string; desc: string; previewClass: string }> = [
  {
    id: 'telegram_dark',
    name: 'Telegram Dark',
    desc: 'Классическая тёмная тема с изумрудным акцентом',
    previewClass: 'bg-[#eaeaea] border-[#5c5c5c] text-[#5c5c5c]',
  },
  {
    id: 'telegram_light',
    name: 'Telegram Light',
    desc: 'Светлая чистая тема с небесно-голубыми элементами',
    previewClass: 'bg-black border-[#919191] text-[#919191]',
  },
  {
    id: 'matrix_green',
    name: 'Matrix Neon',
    desc: 'Глубокий кибер-чёрный фон и светящийся лаймовый код',
    previewClass: 'bg-white border-[#626262] text-[#626262]',
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk 2077',
    desc: 'Неоновый фиолетовый, ультрафиолет и бирюза',
    previewClass: 'bg-[#ffffff] border-[#7f7f7f] text-[#555555]',
  },
  {
    id: 'sunset_gold',
    name: 'Sunset Gold',
    desc: 'Тёплый шоколадный градиент и золотистый янтарь',
    previewClass: 'bg-[#ebebeb] border-[#585858] text-[#585858]',
  },
  {
    id: 'oled_black',
    name: 'OLED Pure Black',
    desc: 'Абсолютный контрастный чёрный цвет для AMOLED экранов',
    previewClass: 'bg-white border-black/80 text-black',
  },
  {
    id: 'windows_xp',
    name: 'Windows XP Classic',
    desc: 'Ностальгический сине-серебряный стиль Luna',
    previewClass: 'bg-[#b2b2b2] border-[#858585] text-black',
  },
];

const ACCENT_COLORS = [
  { id: '#5c5c5c', name: 'Изумрудный', class: 'bg-[#5c5c5c]' },
  { id: '#919191', name: 'Telegram Blue', class: 'bg-[#919191]' },
  { id: '#555555', name: 'Неоновый Циан', class: 'bg-[#555555]' },
  { id: '#585858', name: 'Янтарное Золото', class: 'bg-[#585858]' },
  { id: '#888888', name: 'Рубиновый Красный', class: 'bg-[#888888]' },
  { id: '#7f7f7f', name: 'Фиолетовый Неон', class: 'bg-[#7f7f7f]' },
  { id: '#7d7d7d', name: 'Розовый Коралл', class: 'bg-[#7d7d7d]' },
];

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  onClose,
  userProfile,
  onUpdateProfile,
  onOpenProfileDrawer,
  coolMode,
  onToggleCoolMode,
  fontSize,
  onChangeFontSize,
  fontFamily = 'sans',
  onChangeFontFamily,
  theme = 'telegram_dark',
  onChangeTheme,
  accentColor = '#5c5c5c',
  onChangeAccentColor,
  notificationsEnabled,
  onToggleNotifications,
  notificationFrequency,
  onChangeNotificationFrequency,
  quality = '1080p',
  onChangeQuality,
  vrMode = false,
  onToggleVrMode,
  cinemaMode = false,
  onToggleCinemaMode,
  powerSavingMode = false,
  onTogglePowerSavingMode,
  sendSoundEnabled = true,
  onToggleSendSound,
  chatWallpaper = 'cyber_emerald',
  onChangeChatWallpaper,
  loginCustomization,
  onUpdateLoginCustomization,
  onTestLoginScreen,
  onTriggerBsod,
}) => {
  const disasterMode = useDisasterMode();
  const [showActiveSessions, setShowActiveSessions] = useState(false);
  const [showCacheModal, setShowCacheModal] = useState(false);
  const [isClearingCache, setIsClearingCache] = useState(false);
  const [clearedCacheAmount, setClearedCacheAmount] = useState('45 819 203 Гб');

  // Login Screen Customizer Local State
  const [loginButtonText, setLoginButtonText] = useState(loginCustomization?.buttonText || 'войти');
  const [loginPlaceholder, setLoginPlaceholder] = useState(loginCustomization?.placeholderText || 'Пароль');
  const [loginLogoValue, setLoginLogoValue] = useState(loginCustomization?.logoValue || '🚀');
  const [loginLogoType, setLoginLogoType] = useState<'emoji' | 'image'>(loginCustomization?.logoType || 'emoji');
  const [loginBgUrl, setLoginBgUrl] = useState(loginCustomization?.customBgUrl || '');
  const [loginSavedMsg, setLoginSavedMsg] = useState(false);

  // Active Sessions Mock Data
  const [activeSessions, setActiveSessions] = useState([
    { device: 'Текущее устройство (Windows 11 / Chrome)', location: 'Москва, Россия', time: 'Активно сейчас', isCurrent: true },
    { device: 'Nokia 3310 (Symbian OS)', location: 'Сызрань, Россия', time: '2 секунды назад', isCurrent: false },
    { device: 'Siemens A35 (Кнопочный)', location: 'Саратов, Россия', time: '15 секунд назад', isCurrent: false },
  ]);

  if (!isOpen) return null;

  const handleSaveLoginSettings = () => {
    triggerHaptic('success');
    soundManager.playBeep(1100, 0.1);
    const updated: LoginCustomizationData = {
      title: 'войти в любой аккаунт',
      subtitle: '',
      buttonText: loginButtonText.trim() || 'войти',
      placeholderText: loginPlaceholder.trim() || 'Пароль',
      logoType: loginLogoType,
      logoValue: loginLogoValue,
      customBgUrl: loginBgUrl.trim(),
    };
    if (onUpdateLoginCustomization) {
      onUpdateLoginCustomization(updated);
    }
    localStorage.setItem('app_login_customization', JSON.stringify(updated));
    setLoginSavedMsg(true);
    setTimeout(() => setLoginSavedMsg(false), 3000);
  };

  const handleFileUploadLogo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setLoginLogoType('image');
        setLoginLogoValue(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileUploadBg = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setLoginBgUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleClearCache = () => {
    triggerHaptic('heavy');
    soundManager.playDrillSound();
    setIsClearingCache(true);
    setTimeout(() => {
      const min = 1235646;
      const max = 78978461;
      const val = Math.floor(Math.random() * (max - min + 1)) + min;
      setClearedCacheAmount(`${val.toLocaleString('ru-RU')} Гб`);
      setIsClearingCache(false);
      setShowCacheModal(true);
    }, 1200);
  };

  // Volume and Brightness Sliders state
  const [currentVolume, setCurrentVolume] = useState<number>(() => soundManager.getMasterVolume());
  const [currentBrightness, setCurrentBrightness] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('app_screen_brightness');
      if (saved) {
        const val = parseFloat(saved);
        if (!isNaN(val) && val >= 0.2 && val <= 1) return val;
      }
    } catch {}
    return 1;
  });

  const handleVolumeChange = (newVal: number) => {
    const clamped = Math.max(0, Math.min(1, newVal));
    setCurrentVolume(clamped);
    soundManager.setMasterVolume(clamped);
    soundManager.playBeep(600 + clamped * 600, 0.03);
    window.dispatchEvent(new CustomEvent('volume_changed', { detail: clamped }));
  };

  const handleBrightnessChange = (newVal: number) => {
    const clamped = Math.max(0.2, Math.min(1, newVal));
    setCurrentBrightness(clamped);
    try {
      localStorage.setItem('app_screen_brightness', clamped.toString());
    } catch {}
    window.dispatchEvent(new CustomEvent('brightness_changed', { detail: clamped }));
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-white/80 backdrop-blur-sm animate-in fade-in duration-200">
      {/* Backdrop click to close */}
      <div className="flex-1 cursor-pointer" onClick={onClose} />

      {/* Settings Drawer Panel */}
      <div className="w-full max-w-xl h-full bg-[#eeeeee] border-l border-[#dbdbdb] text-black flex flex-col shadow-[0_0_50px_rgba(255,255,255,0.9)] relative z-10 animate-in slide-in-from-right duration-300">
        
        {/* Drawer Header */}
        <div className="p-4 border-b border-[#dbdbdb] flex items-center justify-between bg-[#e8e8e8] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[#e0e0e0] border border-[#d1d1d1] flex items-center justify-center text-[#5c5c5c]">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-black tracking-wide">Настройки</h2>
              <span className="text-[11px] text-neutral-600">Персонализация и управление приложением</span>
            </div>
          </div>

          <button
            onClick={() => {
              triggerHaptic('tap');
              onClose();
            }}
            className="p-2 rounded-2xl bg-[#e0e0e0] border border-[#d1d1d1] text-neutral-600 hover:text-black hover:border-[#5c5c5c] transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-xs">
          
          {/* HARDWARE SLIDERS: MASTER VOLUME & BRIGHTNESS */}
          <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
                <SlidersHorizontal className="w-4 h-4 text-[#5c5c5c]" />
                Громкость и Яркость
              </h4>
              <span className="text-[10px] text-neutral-600 font-mono">Мгновенная регулировка</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {/* Master Volume */}
              <div className="bg-[#ececec] border border-[#d3d3d3] rounded-xl p-3 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-black">
                    {currentVolume === 0 ? (
                      <VolumeX className="w-4 h-4 text-neutral-600" />
                    ) : (
                      <Volume2 className="w-4 h-4 text-[#5c5c5c]" />
                    )}
                    <span>Звук</span>
                  </div>
                  <span className="font-mono font-bold text-[#5c5c5c] text-xs">
                    {Math.round(currentVolume * 100)}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleVolumeChange(currentVolume === 0 ? 0.7 : 0)}
                    title={currentVolume === 0 ? 'Включить звук' : 'Выключить звук'}
                    className="p-1 rounded-lg text-neutral-600 hover:text-black bg-[#e0e0e0] cursor-pointer"
                  >
                    {currentVolume === 0 ? <VolumeX className="w-3.5 h-3.5 text-neutral-600" /> : <Volume2 className="w-3.5 h-3.5" />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={Math.round(currentVolume * 100)}
                    onChange={(e) => handleVolumeChange(Number(e.target.value) / 100)}
                    className="w-full h-2 bg-[#d3d3d3] rounded-lg appearance-none cursor-pointer accent-[#5c5c5c]"
                  />
                </div>
              </div>

              {/* Screen Brightness */}
              <div className="bg-[#ececec] border border-[#d3d3d3] rounded-xl p-3 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-black">
                    <Sun className="w-4 h-4 text-neutral-600" />
                    <span>Яркость</span>
                  </div>
                  <span className="font-mono font-bold text-neutral-600 text-xs">
                    {Math.round(currentBrightness * 100)}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleBrightnessChange(currentBrightness < 1 ? 1 : 0.5)}
                    title="Сброс на 100%"
                    className="p-1 rounded-lg text-neutral-600 hover:text-black bg-[#e0e0e0] cursor-pointer"
                  >
                    <SunMedium className="w-3.5 h-3.5 text-neutral-600" />
                  </button>
                  <input
                    type="range"
                    min="20"
                    max="100"
                    value={Math.round(currentBrightness * 100)}
                    onChange={(e) => handleBrightnessChange(Number(e.target.value) / 100)}
                    className="w-full h-2 bg-[#d3d3d3] rounded-lg appearance-none cursor-pointer accent-neutral-600"
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Profile Quick Card */}
          <div
            onClick={() => {
              triggerHaptic('tap');
              soundManager.playBeep(1000, 0.05);
              onClose();
              if (onOpenProfileDrawer) onOpenProfileDrawer();
            }}
            className="bg-[#e5e5e5] border border-[#d3d3d3] hover:border-[#5c5c5c] rounded-2xl p-3.5 shadow-md cursor-pointer flex items-center justify-between transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[#dedede] border-2 border-[#5c5c5c] flex items-center justify-center text-2xl shrink-0 shadow-sm overflow-hidden">
                {userProfile.avatar && (userProfile.avatar.startsWith('data:') || userProfile.avatar.startsWith('http') || userProfile.avatar.startsWith('/')) ? (
                  <img src={userProfile.avatar} alt="Аватар" className="w-full h-full object-cover" />
                ) : (
                  <span>{userProfile.avatar || '🐵'}</span>
                )}
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-black group-hover:text-[#5c5c5c] transition-colors">
                  {userProfile.name || 'Пользователь'}
                </h3>
                <p className="text-[11px] text-neutral-600">
                  {userProfile.status || 'В сети'}
                </p>
                <span className="text-[10px] text-[#5c5c5c] block mt-0.5">
                  Открыть профиль, приватность и аватар →
                </span>
              </div>
            </div>
            <div className="px-3 py-1.5 bg-[#5c5c5c] text-white font-extrabold rounded-xl text-[10px] uppercase shrink-0">
              Профиль
            </div>
          </div>

          {/* 1. THEMES SELECTOR */}
          <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
              <Palette className="w-4 h-4 text-[#5c5c5c]" />
              Темы интерфейса
            </h4>
            <p className="text-[11px] text-neutral-600">
              Выберите цветовую схему и визуальный стиль всей экосистемы:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {THEMES_LIST.map((th) => {
                const isSelected = theme === th.id;
                return (
                  <button
                    key={th.id}
                    onClick={() => {
                      triggerHaptic('tap');
                      soundManager.playBeep(1000, 0.05);
                      if (onChangeTheme) onChangeTheme(th.id);
                    }}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#5c5c5c] bg-[#5c5c5c]/10 shadow-[0_0_15px_rgba(92,92,92,0.25)] ring-1 ring-[#5c5c5c]'
                        : 'border-[#d3d3d3] bg-[#eaeaea] hover:border-[#5c5c5c]/50 hover:bg-[#e4e4e4]'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg border flex items-center justify-center text-xs font-bold shrink-0 ${th.previewClass}`}>
                      ✓
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-black text-xs flex items-center justify-between">
                        <span>{th.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#5c5c5c] shrink-0" />}
                      </div>
                      <div className="text-[10px] text-neutral-600 mt-0.5 line-clamp-2">
                        {th.desc}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. ACCENT COLORS */}
          <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
              <Sparkles className="w-4 h-4 text-[#5c5c5c]" />
              Цветовые акценты приложения
            </h4>
            <p className="text-[11px] text-neutral-600">
              Цвет кнопок, активных иконок, подсветки и элементов управления:
            </p>

            <div className="flex items-center gap-2.5 flex-wrap">
              {ACCENT_COLORS.map((col) => {
                const isSelected = accentColor === col.id;
                return (
                  <button
                    key={col.id}
                    onClick={() => {
                      triggerHaptic('tap');
                      soundManager.playBeep(1100, 0.04);
                      if (onChangeAccentColor) onChangeAccentColor(col.id);
                    }}
                    title={col.name}
                    className={`w-10 h-10 rounded-2xl ${col.class} transition-all transform flex items-center justify-center cursor-pointer shadow-md ${
                      isSelected
                        ? 'ring-3 ring-black scale-110 shadow-[0_0_15px_rgba(0,0,0,0.4)]'
                        : 'opacity-70 hover:opacity-100 hover:scale-105'
                    }`}
                  >
                    {isSelected && <Check className="w-5 h-5 text-white font-black" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. FONTS & TEXT SIZE */}
          <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
              <Type className="w-4 h-4 text-[#5c5c5c]" />
              Шрифт и размер текста
            </h4>

            <div>
              <span className="font-bold text-neutral-700 block mb-1.5 text-[11px]">Шрифт системы:</span>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'sans', name: 'Стандартный Sans' },
                  { id: 'display', name: 'Премиум Serif' },
                  { id: 'mono', name: 'Моноширинный' },
                  { id: 'pixel', name: 'Пиксельный' },
                  { id: 'comic', name: 'Комикс' },
                  { id: 'serif', name: 'Классический' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => {
                      triggerHaptic('tap');
                      if (onChangeFontFamily) onChangeFontFamily(f.id as FontFamilyType);
                    }}
                    className={`py-2 px-2 rounded-xl text-[11px] font-bold border transition-all cursor-pointer truncate ${
                      fontFamily === f.id
                        ? 'bg-[#5c5c5c] text-white border-[#5c5c5c] shadow-sm'
                        : 'bg-[#eaeaea] text-neutral-700 border-[#d3d3d3] hover:border-[#5c5c5c]/50'
                    }`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-[#d3d3d3]">
              <span className="font-bold text-neutral-700 block mb-1.5 text-[11px]">Размер шрифта:</span>
              <div className="grid grid-cols-3 gap-2">
                {(['small', 'medium', 'large'] as const).map((sz) => (
                  <button
                    key={sz}
                    onClick={() => {
                      triggerHaptic('tap');
                      onChangeFontSize(sz);
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      fontSize === sz
                        ? 'bg-[#5c5c5c] text-white border-[#5c5c5c] shadow-sm'
                        : 'bg-[#eaeaea] text-neutral-600 border-[#d3d3d3] hover:border-[#5c5c5c]/50'
                    }`}
                  >
                    {sz === 'small' ? 'Мелкий' : sz === 'medium' ? 'Обычный' : 'Крупный'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 4. CHAT WALLPAPERS */}
          {onChangeChatWallpaper && (
            <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
              <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
                <Sparkles className="w-4 h-4 text-[#5c5c5c]" />
                Фон чата
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {WallpaperOptions.map((wp) => {
                  const isSelected = chatWallpaper === wp.id;
                  return (
                    <button
                      key={wp.id}
                      type="button"
                      onClick={() => {
                        triggerHaptic('tap');
                        onChangeChatWallpaper(wp.id);
                      }}
                      className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-[#5c5c5c] bg-[#5c5c5c]/15 shadow-[0_0_12px_rgba(92,92,92,0.3)]'
                          : 'border-[#d3d3d3] bg-[#eaeaea] hover:border-neutral-500'
                      }`}
                    >
                      <div className={`w-full h-10 rounded-lg ${wp.previewClass} border border-black/10`} />
                      <span className="text-[11px] font-bold text-black text-center leading-tight">
                        {wp.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 5. BLUE SCREEN OF DEATH (BSOD) - Direct trigger */}
          <div className="bg-[#e5e5e5] border border-neutral-500/40 rounded-2xl p-4 space-y-3 shadow-md">
            <h4 className="font-extrabold text-neutral-600 uppercase tracking-wider flex items-center gap-2 text-xs">
              <AlertTriangle className="w-4 h-4 text-neutral-600" />
              Экран смерти (BSOD)
            </h4>

            <button
              onClick={() => {
                triggerHaptic('heavy');
                onClose();
                if (onTriggerBsod) onTriggerBsod();
              }}
              className="w-full py-3 bg-neutral-400/30 hover:bg-neutral-400/60 border border-neutral-500 text-neutral-800 font-extrabold uppercase rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 text-xs shadow-md active:scale-98"
            >
              <Monitor className="w-4 h-4 text-neutral-600" />
              <span>Вызвать экран смерти</span>
            </button>
          </div>

          {/* 7. VIDEO & DISPLAY MODES */}
          <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
              <Tv className="w-4 h-4 text-[#5c5c5c]" />
              Видео и режимы отображения
            </h4>

            <div>
              <span className="font-bold text-neutral-700 block mb-2 text-[11px]">Качество видео:</span>
              <div className="grid grid-cols-5 gap-1.5">
                {(['144p', '240p', '360p', '480p', '720p', '1080p', '2k', '4k', '8k', '16k'] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => {
                      triggerHaptic('tap');
                      if (onChangeQuality) onChangeQuality(q);
                    }}
                    className={`py-1.5 rounded-xl font-mono font-bold uppercase text-[10px] border transition-all cursor-pointer ${
                      quality === q
                        ? 'bg-[#5c5c5c] text-white border-[#5c5c5c] shadow-sm'
                        : 'bg-[#eaeaea] text-neutral-600 border-[#d3d3d3] hover:border-[#5c5c5c]/50 hover:text-black'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-[#d3d3d3]">
              <div className="flex items-center justify-between p-2.5 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <span className="font-bold text-black flex items-center gap-2 text-xs">
                  <Eye className="w-4 h-4 text-neutral-600" /> VR режим
                </span>
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    if (onToggleVrMode) onToggleVrMode();
                  }}
                  className={`px-3 py-1 rounded-xl font-extrabold uppercase text-[10px] cursor-pointer transition-all ${
                    vrMode ? 'bg-neutral-500 text-white shadow-sm' : 'bg-[#dcdcdc] text-neutral-600 border border-[#d3d3d3]'
                  }`}
                >
                  {vrMode ? 'ВКЛ' : 'ВЫКЛ'}
                </button>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <span className="font-bold text-black flex items-center gap-2 text-xs">
                  <Tv className="w-4 h-4 text-neutral-600" /> Режим кинотеатра
                </span>
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    if (onToggleCinemaMode) onToggleCinemaMode();
                  }}
                  className={`px-3 py-1 rounded-xl font-extrabold uppercase text-[10px] cursor-pointer transition-all ${
                    cinemaMode ? 'bg-neutral-600 text-white shadow-sm' : 'bg-[#dcdcdc] text-neutral-600 border border-[#d3d3d3]'
                  }`}
                >
                  {cinemaMode ? 'ВКЛ' : 'ВЫКЛ'}
                </button>
              </div>
            </div>
          </div>

          {/* 8. COOL MODE & POWER SAVING */}
          <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
              <Moon className="w-4 h-4 text-[#5c5c5c]" />
              Производительность и спецрежимы
            </h4>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <div className="font-bold text-black flex items-center gap-2 text-xs">
                  <Sparkles className="w-4 h-4 text-neutral-600" />
                  Крутой режим
                </div>
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    onToggleCoolMode();
                  }}
                  className={`px-3.5 py-1.5 rounded-xl font-extrabold uppercase text-[10px] cursor-pointer transition-all ${
                    coolMode ? 'bg-neutral-600 text-white shadow-sm' : 'bg-[#dcdcdc] text-neutral-600 border border-[#d3d3d3]'
                  }`}
                >
                  {coolMode ? 'ВКЛ' : 'ВЫКЛ'}
                </button>
              </div>

              <div className="flex items-center justify-between p-3 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <div className="font-bold text-black flex items-center gap-2 text-xs">
                  <AlertTriangle className="w-4 h-4 text-neutral-600" />
                  Режим катастрофы
                </div>
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    setDisasterMode(!disasterMode);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl font-extrabold uppercase text-[10px] cursor-pointer transition-all ${
                    disasterMode ? 'bg-neutral-400 text-black shadow-sm' : 'bg-[#dcdcdc] text-neutral-600 border border-[#d3d3d3]'
                  }`}
                >
                  {disasterMode ? 'ВКЛ' : 'ВЫКЛ'}
                </button>
              </div>

              <div className="flex items-center justify-between p-3 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <div>
                  <span className="font-bold text-black block text-xs flex items-center gap-2">
                    <Zap className="w-4 h-4 text-neutral-600" /> Режим экономии энергии
                  </span>
                  <span className="text-[10px] text-neutral-600 block mt-0.5">Снижает частоту анимаций</span>
                </div>
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    if (onTogglePowerSavingMode) onTogglePowerSavingMode();
                  }}
                  className={`px-3 py-1.5 rounded-xl font-extrabold uppercase text-[10px] cursor-pointer transition-all ${
                    powerSavingMode ? 'bg-[#5c5c5c] text-white shadow-sm' : 'bg-[#dcdcdc] text-neutral-600 border border-[#d3d3d3]'
                  }`}
                >
                  {powerSavingMode ? 'ВКЛ' : 'ВЫКЛ'}
                </button>
              </div>

              <div className="flex items-center justify-between p-3 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <div className="font-bold text-black flex items-center gap-2 text-xs">
                  <Volume2 className="w-4 h-4 text-[#5c5c5c]" />
                  Звук при отправке сообщений
                </div>
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    if (onToggleSendSound) onToggleSendSound();
                  }}
                  className={`px-3 py-1.5 rounded-xl font-extrabold uppercase text-[10px] cursor-pointer transition-all ${
                    sendSoundEnabled ? 'bg-[#5c5c5c] text-white shadow-sm' : 'bg-[#dcdcdc] text-neutral-600 border border-[#d3d3d3]'
                  }`}
                >
                  {sendSoundEnabled ? 'ВКЛ' : 'ВЫКЛ'}
                </button>
              </div>
            </div>
          </div>

          {/* 9. NOTIFICATIONS & STORAGE */}
          <div className="bg-[#e5e5e5] border border-[#d3d3d3] rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="font-extrabold text-[#5c5c5c] uppercase tracking-wider flex items-center gap-2 text-xs">
              <Bell className="w-4 h-4 text-[#5c5c5c]" />
              Уведомления и память
            </h4>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <div>
                  <span className="font-bold text-black block text-xs">Случайные уведомления</span>
                  <span className="text-[10px] text-neutral-600">Симулирует входящие сообщения</span>
                </div>
                <button
                  onClick={() => {
                    triggerHaptic('tap');
                    onToggleNotifications(!notificationsEnabled);
                  }}
                  className={`px-3 py-1.5 rounded-xl font-extrabold uppercase text-[10px] cursor-pointer transition-all ${
                    notificationsEnabled ? 'bg-[#5c5c5c] text-white shadow-sm' : 'bg-[#dcdcdc] text-neutral-600 border border-[#d3d3d3]'
                  }`}
                >
                  {notificationsEnabled ? 'ВКЛ' : 'ВЫКЛ'}
                </button>
              </div>

              {/* Clear Cache */}
              <div className="p-3 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-bold text-black block text-xs flex items-center gap-2">
                    <Trash2 className="w-4 h-4 text-neutral-600" /> Очистить кэш
                  </span>
                  <span className="text-[10px] text-neutral-600">Освобождает временные файлы</span>
                </div>
                <button
                  onClick={handleClearCache}
                  disabled={isClearingCache}
                  className="px-3.5 py-1.5 bg-neutral-500 hover:bg-neutral-600 text-white font-extrabold rounded-xl uppercase text-[10px] cursor-pointer shadow-sm transition-all"
                >
                  {isClearingCache ? 'Очистка...' : 'Очистить'}
                </button>
              </div>

              {/* Active Sessions */}
              <div className="p-3 bg-[#eaeaea] border border-[#d3d3d3] rounded-xl">
                <button
                  onClick={() => setShowActiveSessions(!showActiveSessions)}
                  className="w-full flex items-center justify-between text-left cursor-pointer"
                >
                  <span className="font-bold text-black text-xs flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-[#5c5c5c]" /> Активные сессии ({activeSessions.length})
                  </span>
                  <ChevronRight className={`w-4 h-4 text-neutral-600 transition-transform ${showActiveSessions ? 'rotate-90' : ''}`} />
                </button>

                {showActiveSessions && (
                  <div className="mt-3 space-y-2 pt-2 border-t border-[#d3d3d3]">
                    {activeSessions.map((s, idx) => (
                      <div key={idx} className="p-2 bg-[#e4e4e4] border border-[#d3d3d3] rounded-lg text-[10px] flex items-center justify-between">
                        <div>
                          <div className="font-bold text-black flex items-center gap-1.5">
                            {s.device}
                            {s.isCurrent && <span className="text-[9px] bg-[#5c5c5c] text-white px-1 rounded font-bold">Это</span>}
                          </div>
                          <div className="text-neutral-600">{s.location} • {s.time}</div>
                        </div>
                        {!s.isCurrent && (
                          <button
                            onClick={() => setActiveSessions((prev) => prev.filter((_, i) => i !== idx))}
                            className="text-neutral-600 hover:text-neutral-700 text-[10px] font-bold p-1"
                          >
                            Завершить
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Version Footer */}
          <div className="text-center py-3 border-t border-[#dbdbdb] text-neutral-500 font-mono text-[11px]">
            Версия приложения: <span className="text-[#5c5c5c] font-bold">0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.1</span>
          </div>

        </div>
      </div>

      {/* CACHE CLEARED MODAL */}
      {showCacheModal && (
        <div className="fixed inset-0 bg-white/85 z-[150] flex items-center justify-center p-4 font-sans">
          <div className="w-full max-w-xs bg-[#e5e5e5] border-2 border-[#5c5c5c] rounded-2xl p-5 text-center shadow-[0_0_40px_rgba(92,92,92,0.3)] space-y-4">
            <div className="w-12 h-12 bg-[#5c5c5c]/20 border border-[#5c5c5c] rounded-full flex items-center justify-center text-2xl mx-auto">
              🧹
            </div>
            <h3 className="text-sm font-extrabold text-black uppercase tracking-wider">Кэш успешно очищен!</h3>
            <p className="text-[#5c5c5c] font-mono font-bold text-sm bg-[#eaeaea] p-3 border border-[#d3d3d3] rounded-xl">
              Очищено: {clearedCacheAmount}
            </p>
            <button
              onClick={() => setShowCacheModal(false)}
              className="w-full py-2.5 bg-[#5c5c5c] text-white font-extrabold uppercase rounded-xl cursor-pointer hover:bg-[#3a3a3a] transition-all"
            >
              Отлично
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

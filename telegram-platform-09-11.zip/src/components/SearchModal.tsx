import React, { useState } from 'react';
import { X, Search as SearchIcon } from 'lucide-react';
import { Chat } from '../types';

interface SearchModalProps {
  chats: Chat[];
  onClose: () => void;
  onSelectChat: (chatId: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  chats,
  onClose,
  onSelectChat,
}) => {
  const [query, setQuery] = useState('');
  const [confirmChatId, setConfirmChatId] = useState<string | null>(null);

  // Filter chats matching query in title or messages
  const matchingChats = query.trim()
    ? chats.filter((c) => {
        if (!c) return false;
        const q = query.toLowerCase();
        const nameStr = (c.name || '').toLowerCase();
        const lastMsgStr = (c.lastMessage || '').toLowerCase();
        const matchesName = nameStr.includes(q);
        const matchesLast = lastMsgStr.includes(q);
        const matchesMsg =
          Array.isArray(c.messages) &&
          c.messages.some((m) => m && m.text && m.text.toLowerCase().includes(q));
        return matchesName || matchesLast || matchesMsg;
      })
    : [];

  const handleTileClick = (chatId: string) => {
    // Shows popup screen confirmation!
    setConfirmChatId(chatId);
  };

  const handleConfirmYes = () => {
    if (confirmChatId) {
      onSelectChat(confirmChatId);
      setConfirmChatId(null);
      onClose();
    }
  };

  const renderHighlightedText = (text: string | undefined | null, highlight: string) => {
    const str = text || '';
    if (!highlight.trim()) return str;
    try {
      const escaped = highlight.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const parts = str.split(new RegExp(`(${escaped})`, 'gi'));
      return parts.map((part, i) =>
        part.toLowerCase() === highlight.toLowerCase() ? (
          <span key={i} className="text-neutral-500 font-extrabold bg-neutral-50/60 px-0.5 rounded">
            {part}
          </span>
        ) : (
          part
        )
      );
    } catch {
      return str;
    }
  };

  return (
    <div className="fixed inset-0 bg-[#ffffff] z-50 flex flex-col font-sans">
      {/* Search Header */}
      <div className="p-4 bg-[#eaeaea] border-b border-[#d6d6d6] flex items-center gap-3">
        <SearchIcon className="w-5 h-5 text-[#5c5c5c]" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Поиск по чатам и сообщениям..."
          className="flex-1 bg-[#e4e4e4] border border-[#d6d6d6] rounded-xl px-4 py-2.5 text-black placeholder-neutral-500 outline-none focus:border-[#5c5c5c] font-medium"
          autoFocus
        />
        <button
          onClick={onClose}
          className="p-2 text-neutral-600 hover:text-[#5c5c5c] rounded-xl transition-colors cursor-pointer"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Results List as Tiles Grid */}
      <div className="flex-1 overflow-y-auto p-4">
        {!query.trim() && (
          <div className="text-center text-neutral-500 py-12 font-medium">
            Введите текст для поиска по вашим чатам
          </div>
        )}

        {query.trim() && matchingChats.length === 0 && (
          <div className="text-center text-neutral-500 py-12 font-medium">
            Ничего не найдено по запросу "{query}"
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {matchingChats.map((chat) => (
            <div
              key={chat.id}
              onClick={() => handleTileClick(chat.id)}
              className="bg-[#eaeaea] hover:bg-[#e4e4e4] border border-[#d6d6d6] hover:border-[#5c5c5c] rounded-2xl p-4 flex items-center gap-4 cursor-pointer transition-all shadow-md group"
            >
              <div className="w-12 h-12 rounded-full p-[2px] bg-gradient-to-tr from-[#cfcfcf] via-[#797979] to-[#5c5c5c] flex items-center justify-center text-xl font-bold text-black shrink-0 group-hover:scale-105 transition-transform">
                <span className="w-full h-full bg-[#e4e4e4] rounded-full flex items-center justify-center">
                  {chat.avatar}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-black font-bold text-base truncate">
                  {renderHighlightedText(chat.name, query)}
                </h3>
                <p className="text-neutral-600 text-sm truncate mt-0.5">
                  {renderHighlightedText(chat.lastMessage, query)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full screen Confirm Popup when clicking a tile */}
      {confirmChatId && (
        <div className="fixed inset-0 bg-white/90 backdrop-blur-md z-[100] flex flex-col justify-end p-6 select-none">
          <div className="w-full max-w-lg mx-auto bg-[#eaeaea] border border-[#5c5c5c]/50 rounded-2xl p-6 flex flex-col items-center gap-6 shadow-[0_0_30px_rgba(92,92,92,0.3)] text-center">
            <h2 className="text-xl md:text-2xl font-black text-black uppercase tracking-wider">
              вы точно хотите это найти?
            </h2>

            <div className="w-full grid grid-cols-2 gap-4">
              <button
                onClick={() => setConfirmChatId(null)}
                className="py-3.5 bg-[#e4e4e4] hover:bg-[#dcdcdc] text-neutral-700 font-extrabold text-xl rounded-xl border border-[#d6d6d6] transition-colors uppercase cursor-pointer"
              >
                нет
              </button>
              <button
                onClick={handleConfirmYes}
                className="py-3.5 bg-[#5c5c5c] hover:bg-[#3a3a3a] text-white font-extrabold text-xl rounded-xl shadow-[0_0_15px_rgba(92,92,92,0.4)] transition-all uppercase cursor-pointer"
              >
                да
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Tv } from 'lucide-react';

interface ToolProps {
  onClose: () => void;
}

const CHANNELS = [
  'Первый канал',
  'Россия 1',
  'НТВ',
  'СТС',
  'ТНТ',
  'Пятница!',
  'РЕН ТВ',
  'МУЗ-ТВ',
  'Карусель',
  'Матч ТВ',
  'Че',
  'Домашний',
  '2x2',
];

export const IptvTool: React.FC<ToolProps> = ({ onClose }) => {
  const [selectedChannel, setSelectedChannel] = useState<string | null>(null);
  const [isStaticNoise, setIsStaticNoise] = useState<boolean>(false);

  const handleSelectChannel = (ch: string) => {
    setSelectedChannel(ch);
    setIsStaticNoise(true);
    setTimeout(() => {
      setIsStaticNoise(false);
    }, 1000);
  };

  return (
    <ToolWrapper title="IPTV Плеер" onClose={onClose}>
      <div className="max-w-2xl mx-auto w-full flex-1 flex flex-col gap-6 py-2">
        {/* Video Player Box */}
        <div className="w-full aspect-video bg-white rounded-3xl border-2 border-neutral-200 flex flex-col items-center justify-center text-center p-6 shadow-2xl relative overflow-hidden">
          {isStaticNoise ? (
            /* 1-second static noise animation */
            <div className="absolute inset-0 bg-neutral-100 flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(#ffffff_2px,transparent_2px)] [background-size:6px_6px] animate-pulse opacity-80" />
              <div className="text-black font-mono font-black text-xl z-10 bg-white/60 px-4 py-2 rounded-xl border border-black/20">
                ПОМЕХИ СИГНАЛА...
              </div>
            </div>
          ) : !selectedChannel ? (
            /* Initial state */
            <>
              <Tv className="w-16 h-16 text-neutral-300 mb-4" />
              <h2 className="text-xl sm:text-2xl font-black text-black tracking-widest uppercase">
                Выберите канал
              </h2>
            </>
          ) : (
            /* After selecting channel and noise finishes */
            <>
              <Tv className="w-16 h-16 text-neutral-300 mb-4 animate-pulse" />
              <h2 className="text-xl sm:text-2xl font-black text-black tracking-widest uppercase">
                Подключите антенну
              </h2>
              <span className="text-xs text-neutral-600 font-mono mt-2">
                Канал: {selectedChannel}
              </span>
            </>
          )}
        </div>

        {/* Channel Selection Grid */}
        <div className="flex-1">
          <h3 className="text-xs font-bold text-neutral-600 uppercase tracking-wider mb-3">
            Список ТВ Каналов:
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {CHANNELS.map((ch) => (
              <button
                key={ch}
                onClick={() => handleSelectChannel(ch)}
                className={`p-3 rounded-2xl font-bold text-xs uppercase tracking-wider border transition-all cursor-pointer flex items-center justify-between ${
                  selectedChannel === ch
                    ? 'bg-neutral-500 text-neutral-50 border-neutral-600 shadow-lg scale-105'
                    : 'bg-neutral-100 text-neutral-700 border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <span className="truncate">{ch}</span>
                <span className="w-2 h-2 rounded-full bg-neutral-500 shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </ToolWrapper>
  );
};

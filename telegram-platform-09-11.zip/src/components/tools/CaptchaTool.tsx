import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { ShieldAlert, RefreshCw } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const CaptchaTool: React.FC<ToolProps> = ({ onClose }) => {
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [isDetectedBot, setIsDetectedBot] = useState(false);
  const [countdown, setCountdown] = useState(3);

  const toggleSelect = (idx: number) => {
    soundManager.playBeep(600, 0.05);
    setSelectedIndices((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  const handleVerify = () => {
    soundManager.playBeep(200, 0.3);
    setIsDetectedBot(true);
  };

  useEffect(() => {
    if (!isDetectedBot) return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onClose(); // Closes tool or app after 3 seconds!
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isDetectedBot, onClose]);

  if (isDetectedBot) {
    return (
      <div className="fixed inset-0 bg-neutral-50 z-50 flex flex-col items-center justify-center p-6 text-center animate-pulse font-mono select-none">
        <ShieldAlert className="w-32 h-32 text-neutral-500 mb-6 animate-bounce" />
        <h1 className="text-3xl sm:text-5xl font-black text-black uppercase tracking-tighter mb-4 text-neutral-600">
          ⚠️ ВНИМАНИЕ! ОБНАРУЖЕН БОТ! ⚠️
        </h1>
        <p className="text-xl font-bold text-neutral-800 mb-6 max-w-lg">
          Система защиты определила, что вы не человек! Доступ к приложению заблокирован!
        </p>
        <div className="text-4xl font-black bg-white border-4 border-neutral-500 px-8 py-4 text-neutral-500">
          ЗАКРЫТИЕ ЧЕРЕЗ {countdown} СЕК...
        </div>
      </div>
    );
  }

  return (
    <ToolWrapper title="Проверка на робота (reCAPTCHA)" onClose={onClose}>
      <div className="max-w-sm mx-auto w-full flex-1 flex flex-col items-center justify-center p-3 font-mono">
        <div className="bg-neutral-100 border-2 border-neutral-600 p-4 w-full shadow-2xl">
          {/* Captcha Header */}
          <div className="bg-neutral-400 p-3 text-neutral-50 font-black text-xs uppercase mb-3 text-center">
            Выберите все изображения с <span className="underline text-white font-extrabold text-sm">ДИНОЗАВРАМИ 🦖</span>
          </div>

          <p className="text-[10px] text-neutral-600 text-center mb-3">
            Если изображений нет, нажмите "Подтвердить"
          </p>

          {/* 3x3 Empty Grid */}
          <div className="grid grid-cols-3 gap-1.5 mb-4">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((idx) => {
              const isSel = selectedIndices.includes(idx);
              return (
                <button
                  key={idx}
                  onClick={() => toggleSelect(idx)}
                  className={`h-20 bg-neutral-50 border-2 transition-all relative cursor-pointer flex items-center justify-center ${
                    isSel ? 'border-neutral-600 bg-neutral-50/40' : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <span className="text-[9px] text-neutral-300 font-bold">ПУСТО</span>
                  {isSel && (
                    <div className="absolute top-1 right-1 w-4 h-4 bg-neutral-600 text-neutral-50 text-[10px] font-black flex items-center justify-center">
                      ✓
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between gap-2">
            <button
              onClick={() => setSelectedIndices([])}
              className="p-2 text-neutral-600 hover:text-black"
              title="Обновить"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={handleVerify}
              className="px-6 py-2.5 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black text-xs uppercase cursor-pointer"
            >
              Подтвердить
            </button>
          </div>
        </div>
      </div>
    </ToolWrapper>
  );
};

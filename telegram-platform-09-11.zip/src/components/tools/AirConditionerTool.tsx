import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Power, Wind, Droplets, Thermometer, Flame, Snowflake, Gauge, Activity } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const AirConditionerTool: React.FC<ToolProps> = ({ onClose }) => {
  const [isOn, setIsOn] = useState(true);
  const [targetTemp, setTargetTemp] = useState(20);
  const [humidity, setHumidity] = useState(48);
  const [fanSpeed, setFanSpeed] = useState<'Low' | 'Med' | 'High' | 'Turbo'>('Med');
  const [mode, setMode] = useState<'Cool' | 'Heat' | 'Dry' | 'Fan'>('Cool');
  const [swingActive, setSwingActive] = useState(true);

  const togglePower = () => {
    soundManager.playBeep(isOn ? 350 : 1300, 0.12);
    setIsOn(!isOn);
  };

  // Speed multiplier for animations
  const speedDurations = {
    Low: '2.5s',
    Med: '1.4s',
    High: '0.8s',
    Turbo: '0.4s',
  };

  const getTempTheme = () => {
    if (targetTemp <= 19) return { color: 'text-neutral-600', bg: 'bg-neutral-500', glow: 'shadow-[0_0_20px_rgba(99,99,99,0.4)]', modeName: 'Ледяной холод' };
    if (targetTemp <= 23) return { color: 'text-neutral-700', bg: 'bg-neutral-600', glow: 'shadow-[0_0_20px_rgba(94,94,94,0.3)]', modeName: 'Комфортная прохлада' };
    if (targetTemp <= 26) return { color: 'text-neutral-600', bg: 'bg-neutral-600', glow: 'shadow-[0_0_20px_rgba(98,98,98,0.3)]', modeName: 'Нейтральный климат' };
    return { color: 'text-neutral-600', bg: 'bg-neutral-500', glow: 'shadow-[0_0_20px_rgba(64,64,64,0.4)]', modeName: 'Интенсивный обогрев' };
  };

  const theme = getTempTheme();

  return (
    <ToolWrapper title="Кондиционер" onClose={onClose} headerColor="bg-[#eaeaea] border-neutral-100">
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full py-2 font-mono text-xs select-none space-y-3">
        
        {/* ========================================================================= */}
        {/* LIVE REALISTIC WALL AC UNIT INTERFACE */}
        {/* ========================================================================= */}
        <div className="p-4 bg-gradient-to-b from-neutral-100 via-[#e9e9e9] to-neutral-50 border-2 border-neutral-500/40 rounded-3xl shadow-2xl relative overflow-hidden">
          
          {/* Split Unit Casing */}
          <div className="w-full bg-gradient-to-b from-neutral-800 via-neutral-900 to-neutral-700 dark:from-neutral-200 dark:via-slate-850 dark:to-neutral-100 border-2 border-neutral-300 rounded-2xl p-4 shadow-xl relative">
            
            {/* Top Vent Grille */}
            <div className="flex justify-between items-center mb-2 px-2">
              <div className="flex gap-1">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="w-4 h-1 bg-neutral-300 rounded-full opacity-60" />
                ))}
              </div>
              <span className="text-[9px] font-sans font-bold tracking-widest text-neutral-600 uppercase">
                CLIMA•PRO INVERTER
              </span>
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isOn ? 'bg-neutral-600 animate-ping' : 'bg-neutral-500'}`} />
                <span className="text-[9px] text-neutral-600">{isOn ? 'ECO' : 'OFF'}</span>
              </div>
            </div>

            {/* Split Faceplate with Integrated Glow LED Display */}
            <div className="flex items-center justify-between bg-white/80 border border-neutral-300/80 rounded-xl px-4 py-2.5 my-1">
              <div className="flex items-center gap-2">
                {mode === 'Cool' ? (
                  <Snowflake className={`w-4 h-4 ${isOn ? 'text-neutral-600 animate-spin' : 'text-neutral-400'}`} />
                ) : (
                  <Flame className={`w-4 h-4 ${isOn ? 'text-neutral-600 animate-pulse' : 'text-neutral-400'}`} />
                )}
                <span className="text-[10px] font-black uppercase text-neutral-700">
                  {isOn ? theme.modeName : 'ВЫКЛЮЧЕН'}
                </span>
              </div>

              {/* Digital LED 7-Segment style readout */}
              <div className="flex items-baseline gap-1">
                <span className={`text-3xl font-black font-mono tracking-tight ${isOn ? theme.color : 'text-neutral-300'}`}>
                  {isOn ? targetTemp : '--'}
                </span>
                <span className={`text-xs font-black ${isOn ? theme.color : 'text-neutral-300'}`}>°C</span>
              </div>
            </div>

            {/* Bottom Air Outlet Louver (Flap that opens when ON and swings) */}
            <div className="mt-3 relative h-10 bg-neutral-50 border border-neutral-200 rounded-xl overflow-hidden flex flex-col justify-end p-1">
              {isOn ? (
                <>
                  {/* Active Louver Flap Angle */}
                  <div
                    className={`h-2.5 rounded-lg transition-all duration-700 border ${theme.bg} ${
                      swingActive ? 'animate-pulse' : ''
                    }`}
                    style={{
                      transform: swingActive ? 'scaleY(1.2)' : 'scaleY(0.9)',
                    }}
                  />
                  {/* Air Stream Particles */}
                  <div className="absolute inset-0 flex justify-around items-center pointer-events-none opacity-80">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className={`w-1 h-6 rounded-full ${theme.bg} opacity-75 blur-[1px] animate-bounce`}
                        style={{
                          animationDuration: speedDurations[fanSpeed],
                          animationDelay: `${i * 0.12}s`,
                        }}
                      />
                    ))}
                  </div>
                </>
              ) : (
                <div className="h-1.5 bg-neutral-300 rounded-md opacity-40 mx-auto w-full text-center" />
              )}
            </div>

          </div>

          {/* Quick Metrics Bar below Unit */}
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[10px]">
            <div className="p-2 bg-neutral-50/70 border border-neutral-200 rounded-xl">
              <span className="text-neutral-600 block">Поток:</span>
              <span className="font-black text-neutral-700">{isOn ? fanSpeed : '--'}</span>
            </div>
            <div className="p-2 bg-neutral-50/70 border border-neutral-200 rounded-xl">
              <span className="text-neutral-600 block">Влажность:</span>
              <span className="font-black text-neutral-700">{isOn ? `${humidity}%` : '--'}</span>
            </div>
            <div className="p-2 bg-neutral-50/70 border border-neutral-200 rounded-xl">
              <span className="text-neutral-600 block">Свинг-заслонка:</span>
              <span className="font-black text-neutral-600">{isOn ? (swingActive ? 'АВТО' : 'ФИКС') : '--'}</span>
            </div>
          </div>

        </div>

        {/* ========================================================================= */}
        {/* INTERACTIVE CONTROLS */}
        {/* ========================================================================= */}

        {/* Master Power & Mode */}
        <div className="flex items-center gap-2">
          <button
            onClick={togglePower}
            className={`flex-1 py-3 rounded-2xl font-black text-xs uppercase flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg active:scale-95 ${
              isOn
                ? 'bg-neutral-400 hover:bg-neutral-500 text-black shadow-neutral-400/30'
                : 'bg-neutral-400 hover:bg-neutral-500 text-black shadow-neutral-400/30'
            }`}
          >
            <Power className="w-4 h-4" />
            <span>{isOn ? 'Выключить сплит' : 'Включить кондиционер'}</span>
          </button>

          <button
            onClick={() => {
              soundManager.playBeep(900, 0.05);
              setSwingActive(!swingActive);
            }}
            disabled={!isOn}
            className={`px-4 py-3 rounded-2xl border font-bold text-xs cursor-pointer transition-all disabled:opacity-40 ${
              swingActive && isOn
                ? 'bg-neutral-500/20 border-neutral-600 text-neutral-700'
                : 'bg-neutral-100 border-neutral-200 text-neutral-600'
            }`}
          >
            Swing ↕
          </button>
        </div>

        {/* Temperature Slider */}
        <div className="bg-neutral-100 border border-neutral-200 p-3.5 rounded-2xl space-y-2">
          <div className="flex justify-between items-center text-neutral-700 font-bold">
            <span className="flex items-center gap-1.5 text-neutral-600">
              <Thermometer className="w-4 h-4" /> Заданная температура:
            </span>
            <span className="text-black text-sm font-black font-mono">{targetTemp}°C</span>
          </div>
          <input
            type="range"
            min={16}
            max={30}
            value={targetTemp}
            disabled={!isOn}
            onChange={(e) => {
              soundManager.playBeep(950, 0.04);
              setTargetTemp(parseInt(e.target.value, 10));
            }}
            className="w-full accent-neutral-600 cursor-pointer disabled:opacity-40"
          />
          <div className="flex justify-between text-[9px] text-neutral-500 font-bold">
            <span>16°C (Холод)</span>
            <span>22°C (Норма)</span>
            <span>30°C (Тепло)</span>
          </div>
        </div>

        {/* Humidity Slider */}
        <div className="bg-neutral-100 border border-neutral-200 p-3.5 rounded-2xl space-y-2">
          <div className="flex justify-between items-center text-neutral-700 font-bold">
            <span className="flex items-center gap-1.5 text-neutral-600">
              <Droplets className="w-4 h-4" /> Влажность воздуха:
            </span>
            <span className="text-black text-sm font-black font-mono">{humidity}%</span>
          </div>
          <input
            type="range"
            min={10}
            max={90}
            value={humidity}
            disabled={!isOn}
            onChange={(e) => {
              soundManager.playBeep(850, 0.04);
              setHumidity(parseInt(e.target.value, 10));
            }}
            className="w-full accent-neutral-600 cursor-pointer disabled:opacity-40"
          />
        </div>

        {/* Fan Speed Buttons */}
        <div className="bg-neutral-100 border border-neutral-200 p-3 rounded-2xl space-y-2">
          <span className="text-[10px] font-bold text-neutral-600 uppercase block tracking-wider">
            Скорость обдува:
          </span>
          <div className="grid grid-cols-4 gap-2">
            {(['Low', 'Med', 'High', 'Turbo'] as const).map((s) => (
              <button
                key={s}
                disabled={!isOn}
                onClick={() => {
                  soundManager.playBeep(1100, 0.04);
                  setFanSpeed(s);
                }}
                className={`py-2 rounded-xl font-bold text-xs cursor-pointer border transition-all ${
                  fanSpeed === s && isOn
                    ? 'bg-neutral-500 text-neutral-50 border-neutral-600 font-black shadow-lg shadow-neutral-500/20'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600 hover:border-neutral-300 disabled:opacity-40'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

      </div>
    </ToolWrapper>
  );
};

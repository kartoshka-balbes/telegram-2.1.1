import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Gauge } from 'lucide-react';

interface ToolProps {
  onClose: () => void;
}

export const TachometerTool: React.FC<ToolProps> = ({ onClose }) => {
  const [rpm, setRpm] = useState(2400);

  useEffect(() => {
    const interval = setInterval(() => {
      // Fluctuates +/- 300 RPM
      const delta = Math.floor(Math.random() * 600) - 300;
      setRpm((prev) => Math.max(0, prev + delta));
    }, 400);

    return () => clearInterval(interval);
  }, []);

  return (
    <ToolWrapper title="Тахометр" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col items-center justify-center p-4 text-center">
        <div className="bg-neutral-100 border-2 border-neutral-200 rounded-3xl p-6 w-full shadow-2xl flex flex-col items-center gap-6">
          <Gauge className="w-24 h-24 text-neutral-600 animate-pulse" />

          <div className="bg-neutral-50 border-2 border-neutral-200 rounded-2xl p-6 w-full font-mono">
            <span className="text-xs font-bold text-neutral-500 uppercase block mb-1">
              Обороты двигателя (RPM):
            </span>
            <div className="text-4xl sm:text-5xl font-black text-neutral-700">
              {rpm.toLocaleString('ru-RU')} Об/мин
            </div>
          </div>
        </div>
      </div>
    </ToolWrapper>
  );
};

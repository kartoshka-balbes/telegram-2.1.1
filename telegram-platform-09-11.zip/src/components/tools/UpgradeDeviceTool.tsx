import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Cpu, Zap, CheckCircle2, Gauge, ShieldCheck, Activity } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const UpgradeDeviceTool: React.FC<ToolProps> = ({ onClose }) => {
  const [upgrading, setUpgrading] = useState(false);
  const [isUpgraded, setIsUpgraded] = useState(false);

  const handleUpgrade = () => {
    setUpgrading(true);
    soundManager.playSiren();

    const duration = Math.floor(Math.random() * 2000) + 3000;
    setTimeout(() => {
      setUpgrading(false);
      setIsUpgraded(true);
      soundManager.playMicrowaveDing();
    }, duration);
  };

  return (
    <ToolWrapper title="Улучшить устройство" onClose={onClose}>
      <div className="flex-1 flex flex-col items-center justify-between max-w-md mx-auto w-full py-4 text-center">
        {/* Specs Card */}
        <div
          className={`bg-neutral-100 border-2 rounded-3xl p-6 w-full shadow-2xl transition-all ${
            isUpgraded
              ? 'border-neutral-500/80 bg-neutral-100/90'
              : upgrading
              ? 'border-neutral-600 animate-pulse'
              : 'border-neutral-200'
          }`}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Cpu
              className={`w-12 h-12 ${
                isUpgraded ? 'text-neutral-600' : 'text-neutral-600'
              }`}
            />
            <div className="text-left">
              <h3 className="text-black font-black text-lg uppercase leading-tight">
                {isUpgraded ? 'Устройство Pro Max' : 'Текущая конфигурация'}
              </h3>
              <span className="text-xs font-mono text-neutral-600 font-bold">
                {isUpgraded ? 'Максимальный профиль' : 'Базовый профиль'}
              </span>
            </div>
          </div>

          <div className="w-full space-y-3 font-mono text-xs text-left">
            {/* CPU Metric */}
            <div className="bg-neutral-50 p-3 rounded-2xl border border-neutral-200">
              <div className="flex justify-between text-neutral-600 mb-1 font-bold">
                <span className="flex items-center gap-1.5">
                  <Gauge className="w-4 h-4 text-neutral-600" /> Процессор (Частота)
                </span>
                <span className={isUpgraded ? 'text-neutral-600 font-black' : 'text-black'}>
                  {isUpgraded ? '5.4 ГГц (8 Cores + Neural)' : '2.8 ГГц'}
                </span>
              </div>
              <div className="w-full bg-neutral-200 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-1000 ${
                    isUpgraded ? 'w-full bg-neutral-600' : 'w-1/2 bg-neutral-600'
                  }`}
                />
              </div>
            </div>

            {/* RAM Metric */}
            <div className="bg-neutral-50 p-3 rounded-2xl border border-neutral-200">
              <div className="flex justify-between text-neutral-600 mb-1 font-bold">
                <span className="flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-neutral-600" /> ОЗУ (Скорость)
                </span>
                <span className={isUpgraded ? 'text-neutral-600 font-black' : 'text-black'}>
                  {isUpgraded ? '64 ГБ LPDDR5X (8500 МГц)' : '8 ГБ DDR4'}
                </span>
              </div>
              <div className="w-full bg-neutral-200 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-1000 ${
                    isUpgraded ? 'w-full bg-neutral-600' : 'w-1/3 bg-neutral-500'
                  }`}
                />
              </div>
            </div>

            {/* GPU Performance */}
            <div className="bg-neutral-50 p-3 rounded-2xl border border-neutral-200">
              <div className="flex justify-between text-neutral-600 mb-1 font-bold">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-neutral-600" /> Производительность GPU
                </span>
                <span className={isUpgraded ? 'text-neutral-600 font-black' : 'text-black'}>
                  {isUpgraded ? '128 TFLOPS (Ray Tracing)' : '12 TFLOPS'}
                </span>
              </div>
              <div className="w-full bg-neutral-200 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-1000 ${
                    isUpgraded ? 'w-full bg-neutral-600' : 'w-1/4 bg-neutral-500'
                  }`}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Upgrade Button */}
        <button
          onClick={handleUpgrade}
          disabled={upgrading || isUpgraded}
          className={`w-full py-4 rounded-2xl font-black text-base uppercase shadow-xl transition-all cursor-pointer ${
            isUpgraded
              ? 'bg-neutral-500 text-neutral-50 cursor-default'
              : upgrading
              ? 'bg-neutral-500 text-neutral-50 animate-pulse'
              : 'bg-neutral-500 hover:bg-neutral-600 text-neutral-50 shadow-neutral-500/30'
          }`}
        >
          {isUpgraded ? (
            <span className="flex items-center justify-center gap-2">
              <CheckCircle2 className="w-5 h-5" /> Устройство максимально улучшено
            </span>
          ) : upgrading ? (
            <span className="flex items-center justify-center gap-2">
              <Zap className="w-5 h-5 animate-spin" /> Улучшение...
            </span>
          ) : (
            'Улучшить устройство'
          )}
        </button>
      </div>
    </ToolWrapper>
  );
};

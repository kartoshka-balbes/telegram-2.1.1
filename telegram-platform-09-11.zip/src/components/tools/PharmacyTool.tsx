import React, { useState, useMemo } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { MedicationReminderTool } from './MedicationReminderTool';
import { ShoppingCart, Search, X, Star, Truck, ShieldCheck, Plus, Minus } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

const DRUGS = [
  { name: 'Активированный уголь (500 мг, 10 табл.)', price: 45, icon: '⚫' },
  { name: 'Парацетамол (500 мг, 20 табл.)', price: 68, icon: '💊' },
  { name: 'Ибупрофен (200 мг, 50 табл.)', price: 120, icon: '💊' },
  { name: 'Аскорбиновая кислота (50 мг, 200 шт.)', price: 35, icon: '🍊' },
  { name: 'Аспирин Упса (500 мг, 16 шип. табл.)', price: 295, icon: '🥤' },
  { name: 'Но-Шпа Дротаверин (40 мг, 24 табл.)', price: 240, icon: '💊' },
  { name: 'Нурофен Экспресс (200 мг, 12 капсул)', price: 310, icon: '💊' },
  { name: 'Терафлю Лимон (10 пакетиков)', price: 620, icon: '🍋' },
  { name: 'Мезим Форте (20 табл.)', price: 185, icon: '💊' },
  { name: 'Супрастин (25 мг, 20 табл.)', price: 190, icon: '💊' },
  { name: 'Пенталгин (12 табл.)', price: 260, icon: '💊' },
  { name: 'Корвалол (25 мл капли)', price: 55, icon: '🧴' },
  { name: 'Валидол (60 мг, 20 табл.)', price: 60, icon: '💊' },
  { name: 'Кеторол Экспресс (10 мг, 20 табл.)', price: 175, icon: '💊' },
  { name: 'Смекта Лимон (10 пакетиков)', price: 210, icon: '🍋' },
  { name: 'Омепразол (20 мг, 30 капсул)', price: 140, icon: '💊' },
  { name: 'Глицин (100 мг, 50 табл.)', price: 95, icon: '💊' },
  { name: 'АЦЦ 600 мг (10 шип. табл.)', price: 450, icon: '🥤' },
];

const Tabs: React.FC<{ tab: 'shop' | 'intake'; setTab: (t: 'shop' | 'intake') => void }> = ({ tab, setTab }) => (
  <div className="grid grid-cols-2 gap-1.5 p-1.5 rounded-full bg-black/[0.06] border border-black/10">
    <button
      onClick={() => setTab('shop')}
      className={`py-2.5 rounded-full text-xs font-bold cursor-pointer transition-all ${tab === 'shop' ? 'bg-black text-neutral-100' : 'text-neutral-700 hover:bg-black/10'}`}
    >
      🛒 Аптека
    </button>
    <button
      onClick={() => setTab('intake')}
      className={`relative py-2.5 rounded-full text-xs font-extrabold cursor-pointer transition-all ${
        tab === 'intake'
          ? 'bg-gradient-to-r from-neutral-500 to-neutral-600 text-black shadow-[0_6px_22px_rgba(122,122,122,0.55)]'
          : 'bg-gradient-to-r from-neutral-500/25 to-neutral-600/25 text-neutral-900 border border-neutral-600/50 animate-pulse'
      }`}
    >
      💊 Приём лекарств
    </button>
  </div>
);

export const PharmacyTool: React.FC<ToolProps> = ({ onClose }) => {
  const [tab, setTab] = useState<'shop' | 'intake'>('shop');
  const [cart, setCart] = useState<Record<number, number>>({});
  const [query, setQuery] = useState('');
  const [showErrorModal, setShowErrorModal] = useState(false);

  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);
  const total = Object.entries(cart).reduce((sum, [i, n]) => sum + DRUGS[Number(i)].price * n, 0);

  const add = (i: number) => {
    soundManager.playBeep(1000, 0.05);
    setCart((c) => ({ ...c, [i]: (c[i] || 0) + 1 }));
  };
  const remove = (i: number) =>
    setCart((c) => {
      const n = (c[i] || 0) - 1;
      const next = { ...c };
      if (n <= 0) delete next[i];
      else next[i] = n;
      return next;
    });

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return DRUGS.map((d, i) => ({ d, i })).filter(({ d }) => !q || d.name.toLowerCase().includes(q));
  }, [query]);

  if (tab === 'intake') {
    return <MedicationReminderTool onClose={onClose} title="💊 Приём лекарств" topSlot={<Tabs tab={tab} setTab={setTab} />} />;
  }

  return (
    <ToolWrapper title="Аптека" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col gap-3 py-1 select-none">
        <Tabs tab={tab} setTab={setTab} />

        {/* Шапка онлайн-аптеки */}
        <div className="relative overflow-hidden rounded-[1.75rem] p-4 bg-gradient-to-br from-[#bebebe] via-[#a7a7a7] to-[#8c8c8c] text-black shadow-xl">
          <div className="absolute -top-10 -right-8 w-40 h-40 rounded-full bg-black/15 blur-2xl" />
          <div className="relative flex items-center justify-between">
            <div>
              <h2 className="text-lg font-extrabold leading-tight">Онлайн-аптека</h2>
              <p className="text-[11px] text-black/85 mt-0.5 flex items-center gap-1">
                <Truck className="w-3.5 h-3.5" /> Доставка за 30 минут · круглосуточно
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-black/20 text-[10px] font-bold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Лицензия
            </span>
          </div>
          <div className="relative mt-3 flex items-center rounded-full bg-black text-neutral-200 px-4 py-2.5 shadow-lg">
            <Search className="w-4 h-4 text-neutral-300 mr-2" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Найти лекарство"
              className="w-full bg-transparent outline-none text-sm placeholder-neutral-600"
            />
          </div>
        </div>

        <h3 className="text-[11px] font-bold text-neutral-600 uppercase tracking-widest px-1">Каталог лекарственных препаратов</h3>

        <div className="grid grid-cols-2 gap-2.5">
          {list.map(({ d, i }) => {
            const n = cart[i] || 0;
            return (
              <div key={i} className="rounded-[1.5rem] bg-black/[0.05] border border-black/10 p-3 flex flex-col gap-2">
                <div className="h-20 rounded-2xl bg-gradient-to-br from-neutral-600/20 to-neutral-600/20 flex items-center justify-center text-4xl">{d.icon}</div>
                <h4 className="text-[12px] font-semibold text-black leading-snug min-h-[2.4em]">{d.name}</h4>
                <div className="flex items-center gap-1 text-[10px] text-neutral-700">
                  <Star className="w-3 h-3 fill-current" /> {(4.2 + (i % 8) / 10).toFixed(1)}
                  <span className="text-neutral-500 ml-1">({20 + i * 7})</span>
                </div>
                <div className="flex items-center justify-between mt-auto">
                  <span className="text-base font-extrabold text-black tabular-nums">{d.price} ₽</span>
                  {n === 0 ? (
                    <button onClick={() => add(i)} className="px-3 py-1.5 rounded-full bg-neutral-600 hover:bg-neutral-700 text-neutral-50 font-bold text-[11px] cursor-pointer active:scale-95 transition-all">
                      + Корзина
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5 rounded-full bg-neutral-600/20 border border-neutral-600/50 px-1.5 py-1">
                      <button onClick={() => remove(i)} className="w-5 h-5 rounded-full bg-black/15 flex items-center justify-center cursor-pointer"><Minus className="w-3 h-3" /></button>
                      <span className="text-xs font-bold text-black w-4 text-center tabular-nums">{n}</span>
                      <button onClick={() => add(i)} className="w-5 h-5 rounded-full bg-neutral-600 text-neutral-50 flex items-center justify-center cursor-pointer"><Plus className="w-3 h-3" /></button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {list.length === 0 && <div className="col-span-2 text-center text-neutral-500 py-8 text-sm">Ничего не найдено</div>}
        </div>

        {/* Корзина */}
        <div className="sticky bottom-0 pt-2 pb-1 bg-gradient-to-t from-[#ffffff] via-[#ffffff]/95 to-transparent">
          <button
            onClick={() => {
              soundManager.playBeep(900, 0.05);
              setShowErrorModal(true);
            }}
            className="w-full py-4 bg-gradient-to-r from-neutral-600 to-neutral-600 text-neutral-50 font-black text-base rounded-full flex items-center justify-center gap-2 shadow-[0_10px_30px_rgba(98,98,98,0.4)] uppercase cursor-pointer active:scale-[0.98] transition-all"
          >
            <ShoppingCart className="w-5 h-5" />
            <span>Купить ({cartCount} шт){total > 0 ? ` · ${total.toLocaleString('ru-RU')} ₽` : ''}</span>
          </button>
        </div>
      </div>

      {showErrorModal && (
        <div className="fixed inset-0 bg-white/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#e6e6e6] border border-black/10 rounded-3xl p-6 text-center shadow-2xl relative">
            <button onClick={() => setShowErrorModal(false)} className="absolute top-4 right-4 text-neutral-600 hover:text-black p-1 rounded-full cursor-pointer">
              <X className="w-6 h-6" />
            </button>
            <div className="text-6xl mb-4">💸</div>
            <h3 className="text-2xl font-black text-black uppercase mb-2">Недостаточно средств</h3>
            <p className="text-neutral-600 text-sm mb-6">бомж</p>
            <button onClick={() => setShowErrorModal(false)} className="w-full py-3 bg-black/10 hover:bg-black/15 text-black font-bold rounded-full cursor-pointer">
              Закрыть
            </button>
          </div>
        </div>
      )}
    </ToolWrapper>
  );
};

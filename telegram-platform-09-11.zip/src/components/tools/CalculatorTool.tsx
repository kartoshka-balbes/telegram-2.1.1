import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { soundManager } from '../../utils/soundEffects';
import { Cpu, Terminal, Delete, ShieldAlert } from 'lucide-react';

interface ToolProps {
  onClose: () => void;
}

export const CalculatorTool: React.FC<ToolProps> = ({ onClose }) => {
  const [display, setDisplay] = useState('0');
  const [expressionHistory, setExpressionHistory] = useState<string>('');
  const [isRad, setIsRad] = useState(true);
  const [memory, setMemory] = useState<number | null>(null);

  const handlePress = (val: string) => {
    soundManager.playBeep(450, 0.03);

    if (val === 'C') {
      setDisplay('0');
      setExpressionHistory('');
      return;
    }

    if (val === 'DEL') {
      if (display.length <= 1 || display === 'ОШИБКА' || display === '0') {
        setDisplay('0');
      } else {
        setDisplay((prev) => prev.slice(0, -1));
      }
      return;
    }

    if (val === 'RAD' || val === 'DEG') {
      setIsRad(!isRad);
      return;
    }

    if (val === 'M+') {
      try {
        const num = parseFloat(display);
        if (!isNaN(num)) {
          setMemory((prev) => (prev !== null ? prev + num : num));
        }
      } catch {}
      return;
    }

    if (val === 'MR') {
      if (memory !== null) {
        setDisplay(String(memory));
      }
      return;
    }

    if (val === 'MC') {
      setMemory(null);
      return;
    }

    if (val === '=') {
      try {
        setExpressionHistory(display);
        let expr = display
          .replace(/×/g, '*')
          .replace(/÷/g, '/')
          .replace(/π/g, 'Math.PI')
          .replace(/e/g, 'Math.E')
          .replace(/√\(/g, 'Math.sqrt(')
          .replace(/log\(/g, 'Math.log10(')
          .replace(/ln\(/g, 'Math.log(');

        if (isRad) {
          expr = expr.replace(/sin\(/g, 'Math.sin(').replace(/cos\(/g, 'Math.cos(');
        } else {
          expr = expr
            .replace(/sin\(([^)]+)\)/g, 'Math.sin(($1)*Math.PI/180)')
            .replace(/cos\(([^)]+)\)/g, 'Math.cos(($1)*Math.PI/180)');
        }

        expr = expr.replace(/\^/g, '**');

        const calculateFunc = new Function(`'use strict'; return (${expr})`);
        const res = calculateFunc();

        if (res === undefined || isNaN(res) || !isFinite(res)) {
          setDisplay('ОШИБКА');
        } else {
          // Format result cleanly
          const rounded = Number(res.toFixed(10)).toString();
          setDisplay(rounded);
        }
      } catch {
        setDisplay('ОШИБКА');
      }
      return;
    }

    if (['sin', 'cos', 'log', 'ln', '√'].includes(val)) {
      if (display === '0' || display === 'ОШИБКА') {
        setDisplay(val + '(');
      } else {
        setDisplay((prev) => prev + val + '(');
      }
      return;
    }

    if (display === '0' || display === 'ОШИБКА') {
      setDisplay(val);
    } else {
      setDisplay((prev) => prev + val);
    }
  };

  const BUTTON_ROWS = [
    [
      { label: isRad ? 'RAD' : 'DEG', type: 'mode' },
      { label: 'sin', type: 'fn' },
      { label: 'cos', type: 'fn' },
      { label: 'log', type: 'fn' },
      { label: 'ln', type: 'fn' },
      { label: 'C', type: 'danger' },
    ],
    [
      { label: '√', type: 'fn' },
      { label: '^', type: 'fn' },
      { label: '(', type: 'fn' },
      { label: ')', type: 'fn' },
      { label: 'DEL', type: 'fn' },
      { label: '÷', type: 'op' },
    ],
    [
      { label: 'MC', type: 'mem' },
      { label: '7', type: 'num' },
      { label: '8', type: 'num' },
      { label: '9', type: 'num' },
      { label: '%', type: 'fn' },
      { label: '×', type: 'op' },
    ],
    [
      { label: 'MR', type: 'mem' },
      { label: '4', type: 'num' },
      { label: '5', type: 'num' },
      { label: '6', type: 'num' },
      { label: 'π', type: 'fn' },
      { label: '-', type: 'op' },
    ],
    [
      { label: 'M+', type: 'mem' },
      { label: '1', type: 'num' },
      { label: '2', type: 'num' },
      { label: '3', type: 'num' },
      { label: 'e', type: 'fn' },
      { label: '+', type: 'op' },
    ],
    [
      { label: '0', type: 'num', span: 'col-span-2' },
      { label: '.', type: 'num' },
      { label: '=', type: 'action', span: 'col-span-3' },
    ],
  ];

  return (
    <ToolWrapper title="Инженерный Калькулятор" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-center py-2 select-none">
        
        {/* Brutalist Heavy Industrial Chassis */}
        <div className="bg-[#ededed] border-2 border-[#d1d1d1] rounded-2xl p-4 sm:p-5 shadow-[0_20px_50px_rgba(255,255,255,0.85)] flex flex-col gap-3 relative">
          
          {/* Top Industrial Header Plate */}
          <div className="flex items-center justify-between border-b border-[#dadada] pb-2 text-[10px] font-mono text-neutral-600 uppercase tracking-wider">
            <div className="flex items-center gap-1.5 font-bold">
              <Cpu className="w-3.5 h-3.5 text-neutral-700" />
              <span>CALC-UNIT MK.IV // SER. 904-B</span>
            </div>
            <div className="flex items-center gap-3">
              <span className={`px-1.5 py-0.5 rounded border text-[9px] font-bold ${
                isRad 
                  ? 'bg-neutral-200 border-neutral-400 text-neutral-800' 
                  : 'bg-neutral-200 border-neutral-400 text-neutral-700'
              }`}>
                {isRad ? 'RAD' : 'DEG'}
              </span>
              {memory !== null && (
                <span className="bg-neutral-200 border border-neutral-400 text-neutral-800 px-1.5 py-0.5 rounded text-[9px] font-bold">
                  M: {memory}
                </span>
              )}
            </div>
          </div>

          {/* Monochromatic Rugged LCD / VFD Display */}
          <div className="bg-[#ffffff] border-2 border-[#e0e0e0] rounded-xl p-3 sm:p-4 text-right shadow-[inset_0_4px_12px_rgba(255,255,255,0.95)] flex flex-col justify-between min-h-[90px] relative overflow-hidden">
            {/* Expression History */}
            <div className="text-right text-xs font-mono text-neutral-600 tracking-wider h-4 overflow-hidden truncate">
              {expressionHistory}
            </div>

            {/* Main Value Display */}
            <div className="overflow-x-auto whitespace-nowrap text-right py-1">
              <span className={`text-3xl sm:text-4xl font-mono font-black tracking-tight ${
                display === 'ОШИБКА' ? 'text-neutral-600' : 'text-neutral-900'
              }`}>
                {display}
              </span>
            </div>

            {/* Bottom Status Ticker */}
            <div className="flex justify-between items-center text-[9px] font-mono text-neutral-600 pt-1 border-t border-neutral-100">
              <span>STATUS: NOMINAL</span>
              <span>64-BIT PRECISION</span>
            </div>
          </div>

          {/* Heavy Block Keypad Grid */}
          <div className="space-y-1.5 pt-1">
            {BUTTON_ROWS.map((row, rIdx) => (
              <div key={rIdx} className="grid grid-cols-6 gap-1.5">
                {row.map((btn) => {
                  let style = 'bg-[#e5e5e5] hover:bg-[#dadada] text-neutral-800 border-[#d5d5d5]';

                  if (btn.type === 'num') {
                    style = 'bg-[#dedede] hover:bg-[#d0d0d0] text-black font-bold border-[#cacaca] active:bg-[#e9e9e9]';
                  } else if (btn.type === 'op') {
                    style = 'bg-[#d1d1d1] hover:bg-[#c3c3c3] text-neutral-900 font-black border-[#b8b8b8] active:bg-[#dcdcdc]';
                  } else if (btn.type === 'danger') {
                    style = 'bg-[#e5e5e5] hover:bg-[#dbdbdb] text-neutral-700 font-black border-[#d1d1d1] active:bg-[#ededed]';
                  } else if (btn.type === 'action') {
                    style = 'bg-[#bdbdbd] hover:bg-[#adadad] text-black font-black border-[#9d9d9d] active:bg-[#cecece] shadow-md';
                  } else if (btn.type === 'mode') {
                    style = 'bg-[#dddddd] hover:bg-[#d1d1d1] text-neutral-700 font-bold text-[11px] border-[#c6c6c6]';
                  } else if (btn.type === 'mem') {
                    style = 'bg-[#e8e8e8] hover:bg-[#dedede] text-neutral-600 font-mono text-[10px] border-[#dbdbdb]';
                  } else if (btn.type === 'fn') {
                    style = 'bg-[#e7e7e7] hover:bg-[#dbdbdb] text-neutral-700 font-mono text-xs border-[#d7d7d7]';
                  }

                  return (
                    <button
                      key={btn.label}
                      onClick={() => handlePress(btn.label)}
                      className={`py-3 sm:py-3.5 rounded-lg border text-sm transition-all duration-75 cursor-pointer flex items-center justify-center select-none active:translate-y-0.5 active:shadow-inner ${style} ${btn.span || ''}`}
                    >
                      {btn.label === 'DEL' ? <Delete className="w-4 h-4" /> : btn.label}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Chassis Bottom Markings */}
          <div className="flex justify-between items-center text-[8px] font-mono text-neutral-600 pt-1 px-1">
            <span>HEAVY DUTY CALCULATION MODULE</span>
            <span>SYSTEM CALIBRATED</span>
          </div>
        </div>
      </div>
    </ToolWrapper>
  );
};

import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Sparkles, Play, Pause, RotateCcw, Clock } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

export const MeditationTool: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [phase, setPhase] = useState<'Вдох' | 'Задержка' | 'Выдох'>('Вдох');
  const [isActive, setIsActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState<number>(300); // 5 minutes default
  const [initialSeconds, setInitialSeconds] = useState<number>(300);

  // Breathing rhythm phase cycle
  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => {
      setPhase((p) => (p === 'Вдох' ? 'Задержка' : p === 'Задержка' ? 'Выдох' : 'Вдох'));
    }, 4000);
    return () => clearInterval(interval);
  }, [isActive]);

  // Countdown timer
  useEffect(() => {
    if (!isActive || timerSeconds <= 0) return;
    const timer = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          setIsActive(false);
          soundManager.playBeep(1200, 0.4);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isActive, timerSeconds]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSelectPreset = (minutes: number) => {
    soundManager.playBeep(900, 0.05);
    setIsActive(false);
    setTimerSeconds(minutes * 60);
    setInitialSeconds(minutes * 60);
  };

  const handleResetTimer = () => {
    soundManager.playBeep(600, 0.05);
    setIsActive(false);
    setTimerSeconds(initialSeconds);
  };

  return (
    <ToolWrapper title="Медитация & Дыхательные практики" onClose={onClose} headerColor="bg-[#eaeaea] border-[#d6d6d6]">
      <div className="flex-1 flex flex-col items-center justify-between max-w-md mx-auto w-full py-4 font-sans select-none text-center space-y-5">
        
        {/* Preset Selector */}
        <div className="w-full bg-[#ededed] border border-[#d6d6d6] p-2 rounded-2xl flex items-center justify-between gap-1">
          <span className="text-[10px] font-extrabold text-neutral-600 uppercase px-2 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-[#5c5c5c]" /> Время:
          </span>
          {[1, 3, 5, 10, 15].map((m) => (
            <button
              key={m}
              onClick={() => handleSelectPreset(m)}
              className={`flex-1 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                initialSeconds === m * 60
                  ? 'bg-[#5c5c5c] text-white shadow-[0_0_10px_rgba(92,92,92,0.3)] font-black'
                  : 'bg-[#e4e4e4] text-neutral-700 hover:text-black border border-[#d6d6d6]'
              }`}
            >
              {m} мин
            </button>
          ))}
        </div>

        {/* Breathing Circle */}
        <div className="relative flex items-center justify-center my-auto">
          <div
            className={`w-44 h-44 sm:w-48 sm:h-48 rounded-full border-4 border-[#5c5c5c] bg-[#d6d6d6]/30 flex flex-col items-center justify-center transition-all duration-[4000ms] ease-in-out shadow-[0_0_35px_rgba(92,92,92,0.3)] ${
              isActive
                ? phase === 'Вдох'
                  ? 'scale-110 border-[#3a3a3a]'
                  : phase === 'Выдох'
                  ? 'scale-90 border-[#5c5c5c]/50'
                  : 'scale-105 border-neutral-600'
                : 'scale-100 border-neutral-300'
            }`}
          >
            <Sparkles className="w-7 h-7 text-[#5c5c5c] animate-pulse mb-1" />
            <span className="text-3xl font-black text-black font-mono tracking-tight my-0.5">
              {formatTime(timerSeconds)}
            </span>
            <span className="text-xs font-black text-[#5c5c5c] uppercase tracking-wider font-mono">
              {isActive ? phase : timerSeconds === 0 ? 'Завершено!' : 'Готово'}
            </span>
          </div>
        </div>

        <p className="text-xs text-neutral-600 max-w-xs leading-relaxed font-medium">
          Расслабьте плечи, закройте глаза и делайте плавные глубокие вдохи в такт пульсации.
        </p>

        {/* Controls */}
        <div className="w-full flex items-center gap-2">
          <button
            onClick={() => {
              soundManager.playBeep(1000, 0.05);
              if (timerSeconds === 0) setTimerSeconds(initialSeconds);
              setIsActive(!isActive);
            }}
            className="flex-1 py-3.5 bg-[#5c5c5c] hover:bg-[#3a3a3a] text-white font-black text-xs uppercase rounded-2xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95"
          >
            {isActive ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{isActive ? 'Пауза' : 'Старт медитации'}</span>
          </button>

          <button
            onClick={handleResetTimer}
            className="p-3.5 bg-[#e4e4e4] border border-[#d6d6d6] hover:border-[#5c5c5c] text-neutral-700 hover:text-black rounded-2xl transition-all cursor-pointer active:scale-95"
            title="Сбросить таймер"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

      </div>
    </ToolWrapper>
  );
};

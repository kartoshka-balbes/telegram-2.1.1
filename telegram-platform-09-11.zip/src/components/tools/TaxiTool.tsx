import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { TAXI_DRIVERS } from '../../data/mockData';
import {
  MapPin,
  Car,
  ChevronUp,
  RefreshCw,
  XCircle,
  Plus,
  Minus,
  Navigation,
  LocateFixed,
  Compass,
} from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

const RANDOM_WAIT_TIMES = [
  '1 год, 7 месяцев',
  '4 года, 3 месяца, 12 дней',
  '8 лет, 11 месяцев',
  '13 лет, 2 месяца, 3 минуты',
  '2 года, 9 месяцев, 45 минут',
  '7 лет, 1 месяц',
];

export const TaxiTool: React.FC<ToolProps> = ({ onClose }) => {
  // Пробки: случайное число от 100 до 291 (обновляется при открытии)
  const [trafficJam] = useState(() => 100 + Math.floor(Math.random() * 192));
  const [status, setStatus] = useState<'idle' | 'searching' | 'found'>('idle');
  const [driver, setDriver] = useState('');
  const [eta, setEta] = useState('');
  const [cardExpanded, setCardExpanded] = useState(true);
  const [waitCost, setWaitCost] = useState(0);
  const [distanceCost] = useState(120);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [carProgress, setCarProgress] = useState(0);

  // Animated taxi car progress along route when found
  useEffect(() => {
    if (status !== 'found') {
      setCarProgress(0);
      return;
    }
    const interval = setInterval(() => {
      setCarProgress((prev) => (prev >= 1 ? 0 : prev + 0.015));
    }, 100);
    return () => clearInterval(interval);
  }, [status]);

  const handleOrderTaxi = () => {
    soundManager.playBeep(900, 0.08);
    setStatus('searching');
    const delay = Math.floor(Math.random() * 2000) + 1200;

    setTimeout(() => {
      soundManager.playBeep(1200, 0.15);
      setStatus('found');
      const randomDriver = TAXI_DRIVERS[Math.floor(Math.random() * TAXI_DRIVERS.length)];
      const randomEta = RANDOM_WAIT_TIMES[Math.floor(Math.random() * RANDOM_WAIT_TIMES.length)];
      setDriver(randomDriver);
      setEta(randomEta);
    }, delay);
  };

  const handleCancelTaxi = () => {
    soundManager.playBeep(500, 0.1);
    setStatus('idle');
    setDriver('');
    setEta('');
    setWaitCost(0);
  };

  const handleAddWaitCost = (e: React.MouseEvent) => {
    e.stopPropagation();
    soundManager.playCoin();
    setWaitCost((prev) => prev + 10000);
  };

  return (
    <ToolWrapper title="Такси" onClose={onClose} headerColor="bg-[#e9e9e9] border-neutral-200">
      <div className="relative flex-1 flex flex-col -m-4 overflow-hidden select-none bg-[#e8e8e8]">
        {/* Realistic Interactive City Map Viewport */}
        <div className="absolute inset-0 overflow-hidden flex items-center justify-center">
          <div
            className="w-full h-full relative transition-transform duration-300 ease-out origin-center"
            style={{ transform: `scale(${zoomLevel})` }}
          >
            {/* SVG Realistic Vector City Map */}
            <svg
              viewBox="0 0 1000 800"
              className="w-full h-full object-cover select-none"
              preserveAspectRatio="xMidYMid slice"
            >
              <defs>
                {/* Linear Gradients for Rivers & Expressways */}
                <linearGradient id="riverGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#e0e0e0" />
                  <stop offset="50%" stopColor="#d9d9d9" />
                  <stop offset="100%" stopColor="#e3e3e3" />
                </linearGradient>

                <linearGradient id="routeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#636363" />
                  <stop offset="50%" stopColor="#404040" />
                  <stop offset="100%" stopColor="#585858" />
                </linearGradient>

                <filter id="mapGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="4" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>

                <filter id="shadowFilter" x="-10%" y="-10%" width="120%" height="120%">
                  <feDropShadow dx="2" dy="4" stdDeviation="3" floodColor="#ffffff" floodOpacity="0.6" />
                </filter>
              </defs>

              {/* 1. MAP BACKGROUND BASE */}
              <rect width="1000" height="800" fill="#e7e7e7" />

              {/* 2. PARK / GREEN SPACES */}
              {/* Central Park */}
              <polygon
                points="120,80 280,60 320,190 260,280 140,260 90,160"
                fill="#e3e3e3"
                stroke="#d9d9d9"
                strokeWidth="1.5"
              />
              <text x="180" y="170" fill="#767676" opacity="0.6" fontSize="13" fontWeight="bold" fontFamily="sans-serif">
                Парк Победы
              </text>

              {/* Riverside Park */}
              <polygon
                points="420,400 580,360 620,480 510,540 400,470"
                fill="#e3e3e3"
                stroke="#d9d9d9"
                strokeWidth="1.5"
              />
              <text x="470" y="460" fill="#767676" opacity="0.6" fontSize="12" fontWeight="bold" fontFamily="sans-serif">
                Набережный сквер
              </text>

              {/* North-East Park */}
              <polygon
                points="720,50 940,40 920,200 760,180"
                fill="#e5e5e5"
                stroke="#d9d9d9"
                strokeWidth="1.5"
              />

              {/* 3. WINDING RIVER WITH REALISTIC SHORELINE */}
              {/* River bank contour */}
              <path
                d="M-50,380 C 180,350 260,520 450,460 C 640,400 720,240 1050,220"
                fill="none"
                stroke="#cfcfcf"
                strokeWidth="74"
                strokeLinecap="round"
              />
              {/* River water */}
              <path
                d="M-50,380 C 180,350 260,520 450,460 C 640,400 720,240 1050,220"
                fill="none"
                stroke="url(#riverGrad)"
                strokeWidth="64"
                strokeLinecap="round"
              />
              <text x="120" y="440" fill="#636363" opacity="0.4" fontSize="11" fontWeight="bold" letterSpacing="3">
                р. МОСКВА
              </text>

              {/* 4. CITY BLOCKS & 3D BUILDING FOOTPRINTS */}
              <g filter="url(#shadowFilter)">
                {/* Block Group 1 (Top Left) */}
                <rect x="50" y="320" width="70" height="45" rx="4" fill="#d9d9d9" stroke="#cacaca" strokeWidth="1" />
                <rect x="135" y="310" width="85" height="55" rx="4" fill="#d6d6d6" stroke="#c6c6c6" strokeWidth="1" />
                <text x="170" y="342" fill="#8d8d8d" fontSize="10" fontFamily="sans-serif">14к1</text>

                <rect x="50" y="420" width="60" height="80" rx="4" fill="#dddddd" stroke="#cdcdcd" strokeWidth="1" />
                <rect x="125" y="460" width="95" height="50" rx="4" fill="#d9d9d9" stroke="#cacaca" strokeWidth="1" />

                {/* Block Group 2 (Center Top) */}
                <rect x="350" y="70" width="110" height="70" rx="5" fill="#d3d3d3" stroke="#c1c1c1" strokeWidth="1.5" />
                <text x="375" y="110" fill="#5e5e5e" fontSize="11" fontWeight="bold" fontFamily="sans-serif">ТЦ «Атриум»</text>

                <rect x="480" y="60" width="80" height="60" rx="4" fill="#dadada" stroke="#c9c9c9" strokeWidth="1" />
                <rect x="480" y="135" width="80" height="75" rx="4" fill="#d9d9d9" stroke="#c9c9c9" strokeWidth="1" />
                <rect x="370" y="160" width="90" height="50" rx="4" fill="#dcdcdc" stroke="#cccccc" strokeWidth="1" />

                {/* Block Group 3 (Center - Pickup Neighborhood) */}
                <rect x="360" y="240" width="120" height="90" rx="5" fill="#d1d1d1" stroke="#b9b9b9" strokeWidth="1.5" />
                <text x="390" y="290" fill="#2c2c2c" fontSize="12" fontWeight="bold" fontFamily="sans-serif">ул. Ленина, 42</text>
                <text x="410" y="308" fill="#4f4f4f" fontSize="10" fontWeight="bold" fontFamily="sans-serif">★ Вы здесь</text>

                <rect x="505" y="245" width="90" height="40" rx="4" fill="#dbdbdb" stroke="#cacaca" strokeWidth="1" />
                <rect x="505" y="295" width="90" height="40" rx="4" fill="#dadada" stroke="#c8c8c8" strokeWidth="1" />

                {/* Block Group 4 (Right Side) */}
                <rect x="680" y="260" width="130" height="85" rx="5" fill="#d6d6d6" stroke="#c3c3c3" strokeWidth="1" />
                <text x="710" y="305" fill="#5e5e5e" fontSize="11" fontFamily="sans-serif">БЦ «Плаза»</text>

                <rect x="830" y="250" width="120" height="60" rx="4" fill="#dadada" stroke="#cacaca" strokeWidth="1" />
                <rect x="830" y="325" width="120" height="70" rx="4" fill="#d8d8d8" stroke="#c8c8c8" strokeWidth="1" />

                {/* Block Group 5 (Bottom Right) */}
                <rect x="680" y="470" width="100" height="80" rx="4" fill="#dbdbdb" stroke="#cbcbcb" strokeWidth="1" />
                <rect x="800" y="470" width="140" height="110" rx="5" fill="#d5d5d5" stroke="#c1c1c1" strokeWidth="1" />
                <text x="830" y="530" fill="#5e5e5e" fontSize="11" fontFamily="sans-serif">ЖК «Ривер Парк»</text>

                <rect x="680" y="570" width="100" height="90" rx="4" fill="#dddddd" stroke="#cccccc" strokeWidth="1" />
                <rect x="800" y="600" width="140" height="70" rx="4" fill="#d9d9d9" stroke="#c9c9c9" strokeWidth="1" />

                {/* Block Group 6 (Bottom Center / Left) */}
                <rect x="230" y="580" width="140" height="90" rx="5" fill="#d6d6d6" stroke="#c4c4c4" strokeWidth="1" />
                <rect x="390" y="590" width="120" height="80" rx="4" fill="#dbdbdb" stroke="#c9c9c9" strokeWidth="1" />
                <rect x="60" y="590" width="145" height="85" rx="4" fill="#dcdcdc" stroke="#cbcbcb" strokeWidth="1" />
              </g>

              {/* 5. SECONDARY ROADS & STREETS */}
              <g stroke="#cfcfcf" strokeWidth="16" strokeLinecap="round" strokeLinejoin="round" fill="none">
                <path d="M 0,160 L 350,160 L 350,360 L 0,360" />
                <path d="M 230,0 L 230,800" />
                <path d="M 640,0 L 640,800" />
                <path d="M 350,360 L 1000,360" />
                <path d="M 350,560 L 1000,560" />
                <path d="M 780,220 L 780,800" />
                <path d="M 490,0 L 490,360" />
                <path d="M 490,560 L 490,800" />
              </g>

              <g stroke="#c0c0c0" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" fill="none">
                <path d="M 0,160 L 350,160 L 350,360 L 0,360" />
                <path d="M 230,0 L 230,800" />
                <path d="M 640,0 L 640,800" />
                <path d="M 350,360 L 1000,360" />
                <path d="M 350,560 L 1000,560" />
                <path d="M 780,220 L 780,800" />
                <path d="M 490,0 L 490,360" />
                <path d="M 490,560 L 490,800" />
              </g>

              {/* 6. PRIMARY HIGHWAY & BRIDGES (MAIN ARTERIAL ROADS) */}
              {/* Outer Ring Expressway */}
              <path
                d="M-50,720 Q 400,680 640,480 T 1050,100"
                stroke="#d9d9d9"
                strokeWidth="28"
                fill="none"
                strokeLinecap="round"
              />
              <path
                d="M-50,720 Q 400,680 640,480 T 1050,100"
                stroke="#b7b7b7"
                strokeWidth="22"
                fill="none"
                strokeLinecap="round"
              />
              <path
                d="M-50,720 Q 400,680 640,480 T 1050,100"
                stroke="#585858"
                strokeWidth="2.5"
                strokeDasharray="14 10"
                fill="none"
              />

              {/* Main Prospect Avenue */}
              <path
                d="M 350,-20 L 350,820"
                stroke="#d9d9d9"
                strokeWidth="32"
                fill="none"
              />
              <path
                d="M 350,-20 L 350,820"
                stroke="#b3b3b3"
                strokeWidth="26"
                fill="none"
              />
              <path
                d="M 350,-20 L 350,820"
                stroke="#000000"
                strokeWidth="2"
                strokeDasharray="16 12"
                fill="none"
                opacity="0.8"
              />

              {/* Bridge over River 1 */}
              <rect x="330" y="445" width="40" height="60" rx="3" fill="#acacac" stroke="#8d8d8d" strokeWidth="2" />
              <line x1="350" y1="445" x2="350" y2="505" stroke="#585858" strokeWidth="2.5" strokeDasharray="10 8" />

              {/* Bridge over River 2 */}
              <rect x="622" y="325" width="36" height="50" rx="3" fill="#acacac" stroke="#8d8d8d" strokeWidth="2" transform="rotate(-25 640 350)" />

              {/* 7. STREET NAMES & POIs */}
              <text x="358" y="50" fill="#5e5e5e" fontSize="12" fontWeight="bold" letterSpacing="1" fontFamily="sans-serif" transform="rotate(90 358 50)">
                ПРОСПЕКТ МИРА
              </text>
              <text x="358" y="660" fill="#5e5e5e" fontSize="12" fontWeight="bold" letterSpacing="1" fontFamily="sans-serif" transform="rotate(90 358 660)">
                ПРОСПЕКТ МИРА
              </text>
              <text x="700" y="352" fill="#8d8d8d" fontSize="11" fontWeight="bold" fontFamily="sans-serif">
                ул. Тверская
              </text>
              <text x="70" y="152" fill="#8d8d8d" fontSize="11" fontWeight="bold" fontFamily="sans-serif">
                ул. Арбат
              </text>
              <text x="700" y="552" fill="#8d8d8d" fontSize="11" fontWeight="bold" fontFamily="sans-serif">
                Садовая ул.
              </text>

              {/* Metro Station Badges */}
              <g transform="translate(325, 145)">
                <circle cx="10" cy="10" r="10" fill="#a3a3a3" stroke="#000000" strokeWidth="1.5" />
                <text x="6" y="14" fill="#000000" fontSize="11" fontWeight="black">М</text>
                <text x="26" y="14" fill="#666666" fontSize="10" fontWeight="bold">м. Проспект Мира</text>
              </g>

              <g transform="translate(615, 235)">
                <circle cx="10" cy="10" r="10" fill="#909090" stroke="#000000" strokeWidth="1.5" />
                <text x="6" y="14" fill="#000000" fontSize="11" fontWeight="black">М</text>
                <text x="26" y="14" fill="#585858" fontSize="10" fontWeight="bold">м. Тверская</text>
              </g>

              {/* 8. NEARBY IDLE TAXIS (Yandex Yellow Cars on streets) */}
              {/* Taxi 1 (Waiting at top corner) */}
              <g transform="translate(222, 110) rotate(15)">
                <rect x="-8" y="-14" width="16" height="28" rx="4" fill="#3a3a3a" stroke="#ffffff" strokeWidth="1.5" />
                <rect x="-6" y="-6" width="12" height="12" rx="2" fill="#d7d7d7" />
                <rect x="-4" y="-2" width="8" height="4" fill="#000000" />
                <text x="-3" y="1" fill="#ffffff" fontSize="4" fontWeight="black">🚕</text>
              </g>

              {/* Taxi 2 (Near river bank) */}
              <g transform="translate(772, 420) rotate(-10)">
                <rect x="-8" y="-14" width="16" height="28" rx="4" fill="#3a3a3a" stroke="#ffffff" strokeWidth="1.5" />
                <rect x="-6" y="-6" width="12" height="12" rx="2" fill="#d7d7d7" />
                <rect x="-4" y="-2" width="8" height="4" fill="#000000" />
              </g>

              {/* Taxi 3 (East side) */}
              <g transform="translate(632, 620) rotate(180)">
                <rect x="-8" y="-14" width="16" height="28" rx="4" fill="#3a3a3a" stroke="#ffffff" strokeWidth="1.5" />
                <rect x="-6" y="-6" width="12" height="12" rx="2" fill="#d7d7d7" />
                <rect x="-4" y="-2" width="8" height="4" fill="#000000" />
              </g>

              {/* 9. ACTIVE TAXI ROUTE & ANIMATED CAB (When Found / Searching) */}
              {(status === 'found' || status === 'searching') && (
                <g>
                  {/* Route Polyline Glow */}
                  <path
                    d="M 640,110 L 640,360 L 350,360 L 350,280"
                    fill="none"
                    stroke="#9a9a9a"
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    opacity="0.4"
                  />
                  {/* Glowing Animated Fast Route Path */}
                  <path
                    d="M 640,110 L 640,360 L 350,360 L 350,280"
                    fill="none"
                    stroke="url(#routeGrad)"
                    strokeWidth="6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeDasharray="12 8"
                    className="animate-pulse"
                  />

                  {/* Assigned Taxi Car driving along the route */}
                  {status === 'found' && (
                    <g
                      transform={`translate(${
                        carProgress < 0.45
                          ? 640
                          : carProgress < 0.85
                          ? 640 - ((carProgress - 0.45) / 0.4) * 290
                          : 350
                      }, ${
                        carProgress < 0.45
                          ? 110 + (carProgress / 0.45) * 250
                          : carProgress < 0.85
                          ? 360
                          : 360 - ((carProgress - 0.85) / 0.15) * 80
                      }) rotate(${
                        carProgress < 0.45 ? 180 : carProgress < 0.85 ? 270 : 0
                      })`}
                    >
                      {/* Car Headlights Beam */}
                      <polygon points="-12,-20 12,-20 35,-70 -35,-70" fill="#161616" opacity="0.35" />
                      {/* Car Body */}
                      <rect x="-11" y="-18" width="22" height="36" rx="5" fill="#4f4f4f" stroke="#e7e7e7" strokeWidth="2" filter="url(#shadowFilter)" />
                      {/* Windshields */}
                      <rect x="-8" y="-10" width="16" height="8" rx="2" fill="#e8e8e8" />
                      <rect x="-8" y="5" width="16" height="6" rx="2" fill="#e8e8e8" />
                      {/* Taxi Roof Sign */}
                      <rect x="-6" y="-2" width="12" height="5" rx="1.5" fill="#000000" stroke="#4f4f4f" strokeWidth="1" />
                      <text x="-4" y="2" fill="#ffffff" fontSize="3.5" fontWeight="black">TAXI</text>
                    </g>
                  )}
                </g>
              )}

              {/* 10. USER PICKUP LOCATION PIN (ул. Ленина, 42) */}
              <g transform="translate(350, 280)">
                {/* Radar pulse ripples */}
                <circle cx="0" cy="0" r="40" fill="#636363" opacity="0.15" className="animate-ping" />
                <circle cx="0" cy="0" r="24" fill="#9a9a9a" opacity="0.25" />
                <circle cx="0" cy="0" r="12" fill="#aeaeae" opacity="0.5" />

                {/* Pickup Address Callout Bubble */}
                <g transform="translate(-75, -60)" filter="url(#shadowFilter)">
                  <rect x="0" y="0" width="150" height="32" rx="16" fill="#ffffff" stroke="#585858" strokeWidth="1.5" />
                  <circle cx="16" cy="16" r="5" fill="#585858" />
                  <text x="28" y="16" fill="#000000" fontSize="10" fontWeight="bold" fontFamily="sans-serif" dominantBaseline="middle">
                    ул. Ленина, д. 42
                  </text>
                  <polygon points="75,32 70,38 80,38" fill="#585858" />
                </g>

                {/* Pin Circle Marker */}
                <circle cx="0" cy="0" r="10" fill="#585858" stroke="#000000" strokeWidth="3" filter="url(#shadowFilter)" />
                <circle cx="0" cy="0" r="4" fill="#ffffff" />
              </g>
            </svg>
          </div>

          {/* MAP INTERACTIVE CONTROLS OVERLAY */}
          {/* Top Right Info & Controls: Compass & Traffic */}
          <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
            {/* Traffic Widget */}
            <div className="bg-neutral-100/90 backdrop-blur-md border border-neutral-300/80 px-3 py-1.5 rounded-xl shadow-lg flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-neutral-600 animate-pulse" />
              <span className="text-[11px] font-bold text-neutral-800">Пробки: {trafficJam} {trafficJam % 10 === 1 && trafficJam % 100 !== 11 ? 'балл' : [2, 3, 4].includes(trafficJam % 10) && ![12, 13, 14].includes(trafficJam % 100) ? 'балла' : 'баллов'}</span>
            </div>

            {/* Compass */}
            <button
              onClick={() => setZoomLevel(1)}
              title="Север"
              className="w-10 h-10 bg-neutral-100/90 hover:bg-neutral-200 backdrop-blur-md border border-neutral-300/80 rounded-xl shadow-lg flex items-center justify-center text-neutral-800 cursor-pointer transition-all active:scale-90 ml-auto"
            >
              <Compass className="w-5 h-5 text-neutral-600" />
            </button>
          </div>

          {/* Right Side Zoom Buttons */}
          <div className="absolute right-4 top-28 flex flex-col gap-1.5 z-10">
            <button
              onClick={() => setZoomLevel((z) => Math.min(1.6, Number((z + 0.15).toFixed(2))))}
              title="Приблизить"
              className="w-10 h-10 bg-neutral-100/90 hover:bg-neutral-200 active:bg-neutral-600 active:text-white backdrop-blur-md border border-neutral-300/80 rounded-xl shadow-lg flex items-center justify-center text-black cursor-pointer transition-all active:scale-90"
            >
              <Plus className="w-5 h-5" />
            </button>
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.8, Number((z - 0.15).toFixed(2))))}
              title="Отдалить"
              className="w-10 h-10 bg-neutral-100/90 hover:bg-neutral-200 active:bg-neutral-600 active:text-white backdrop-blur-md border border-neutral-300/80 rounded-xl shadow-lg flex items-center justify-center text-black cursor-pointer transition-all active:scale-90"
            >
              <Minus className="w-5 h-5" />
            </button>
            <button
              onClick={() => setZoomLevel(1)}
              title="Моё местоположение"
              className="w-10 h-10 bg-neutral-100/90 hover:bg-neutral-200 active:bg-neutral-600 active:text-white backdrop-blur-md border border-neutral-300/80 rounded-xl shadow-lg flex items-center justify-center text-neutral-600 cursor-pointer transition-all active:scale-90"
            >
              <LocateFixed className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Pull-up Bottom Taxi Order Sheet */}
        <div
          className={`absolute bottom-0 inset-x-0 bg-neutral-100/95 backdrop-blur-xl border-t-2 border-neutral-300/80 rounded-t-3xl p-5 shadow-[0_-10px_35px_rgba(255,255,255,0.8)] transition-all duration-300 z-20 flex flex-col gap-3 ${
            cardExpanded ? 'translate-y-0' : 'translate-y-[calc(100%-74px)]'
          }`}
        >
          {/* Handle bar toggle */}
          <button
            onClick={() => setCardExpanded(!cardExpanded)}
            className="w-full flex flex-col items-center justify-center cursor-pointer py-0.5 text-neutral-600 hover:text-black"
          >
            <div className="w-10 h-1 bg-neutral-400 rounded-full mb-1" />
            <ChevronUp
              className={`w-4 h-4 transition-transform ${cardExpanded ? 'rotate-180' : ''}`}
            />
          </button>

          {/* Tariff Info Header */}
          <div className="flex justify-between items-center bg-neutral-50/80 p-3 rounded-2xl border border-neutral-200">
            <div>
              <span className="text-[10px] text-neutral-600 font-bold uppercase block">Выбранный тариф:</span>
              <span className="text-sm font-black text-neutral-600 uppercase tracking-wide">ЭКОНОМ</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-neutral-600 font-bold uppercase block">Цена за расстояние:</span>
              <span className="text-xs font-black text-neutral-600 font-mono">{distanceCost} ₽/км</span>
            </div>
          </div>

          {/* Order Action Button */}
          {status !== 'found' && (
            <button
              onClick={handleOrderTaxi}
              disabled={status === 'searching'}
              className={`w-full py-3.5 rounded-2xl font-black text-base uppercase tracking-wider shadow-2xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                status === 'idle'
                  ? 'bg-neutral-600 hover:bg-neutral-700 text-neutral-50 shadow-neutral-600/40 active:scale-95'
                  : 'bg-neutral-200 text-neutral-600 animate-pulse border border-neutral-600'
              }`}
            >
              <Car className="w-5 h-5" />
              <span>
                {status === 'idle' && 'Заказать такси (Эконом)'}
                {status === 'searching' && 'Поиск машины...'}
              </span>
            </button>
          )}

          {/* Driver & ETA Details */}
          {status === 'found' && (
            <div className="flex flex-col gap-2.5 animate-in fade-in zoom-in duration-300">
              <div className="bg-neutral-50/90 border border-neutral-200 rounded-2xl p-3.5 flex flex-col gap-2.5">
                <div className="flex items-center justify-between border-b border-neutral-200/80 pb-2">
                  <span className="text-xs font-bold text-neutral-600 uppercase">Водитель (Эконом):</span>
                  <span className="text-sm font-black text-neutral-600 uppercase font-mono">
                    {driver}
                  </span>
                </div>
                <div className="flex items-center justify-between border-b border-neutral-200/80 pb-2">
                  <span className="text-xs font-bold text-neutral-600 uppercase">Время ожидания:</span>
                  <span className="text-xs font-bold text-neutral-600 font-mono">{eta}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-600 uppercase">Платное ожидание:</span>
                  <span className="text-sm font-black text-neutral-600 font-mono">+{waitCost.toLocaleString('ru-RU')} ₽</span>
                </div>
              </div>

              <button
                onClick={handleAddWaitCost}
                className="w-full py-2 bg-neutral-50/80 hover:bg-neutral-100 text-neutral-700 border border-neutral-400/50 font-bold rounded-xl text-xs uppercase cursor-pointer transition-all active:scale-95"
              >
                Платное ожидание (+10 000 ₽)
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={handleOrderTaxi}
                  className="py-2.5 bg-neutral-200 hover:bg-neutral-300 text-neutral-600 border border-neutral-300 font-bold rounded-xl text-xs uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Другое такси</span>
                </button>
                <button
                  onClick={handleCancelTaxi}
                  className="py-2.5 bg-neutral-400/20 hover:bg-neutral-400/30 text-neutral-600 border border-neutral-500/40 font-bold rounded-xl text-xs uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Отменить такси</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Cpu, Zap, Activity } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const FpsBoosterTool: React.FC<ToolProps> = ({ onClose }) => {
  const [fps, setFps] = useState(60);

  const handleFpsChange = (val: number) => {
    soundManager.playBeep(200 + val / 100, 0.02);
    setFps(val);
  };

  return (
    <ToolWrapper title="NVIDIA FPS Booster Ultra 9000" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-between py-4 font-mono">
        <div className="bg-neutral-100 border-2 border-neutral-500 p-6 text-center space-y-6 shadow-2xl">
          <div className="flex justify-center items-center gap-2 text-neutral-600">
            <Cpu className="w-10 h-10 animate-spin" style={{ animationDuration: '3s' }} />
            <Zap className="w-8 h-8 text-neutral-600" />
          </div>

          <div>
            <span className="text-xs font-bold text-neutral-600 uppercase block mb-1">Уровень Кадров в секунду (FPS):</span>
            <div className="text-4xl sm:text-5xl font-black text-neutral-600 tracking-wider">
              {fps.toLocaleString('ru-RU')} <span className="text-xl text-black">FPS</span>
            </div>
          </div>

          <div className="space-y-2">
            <input
              type="range"
              min="0"
              max="57800"
              value={fps}
              onChange={(e) => handleFpsChange(Number(e.target.value))}
              className="w-full h-4 bg-neutral-50 rounded-lg appearance-none cursor-pointer accent-neutral-500"
            />
            <div className="flex justify-between text-[10px] text-neutral-600 font-bold">
              <span>0 FPS (Лаги)</span>
              <span>60 FPS</span>
              <span>57 800 FPS (Космос)</span>
            </div>
          </div>

          <div className="p-3 bg-neutral-50 border border-neutral-200 text-xs text-neutral-700 font-bold">
            {fps < 10 && '⚠️ Критическое замедление! Экран слайд-шоу.'}
            {fps >= 10 && fps <= 120 && '⚡ Стандартный плавный режим.'}
            {fps > 120 && '🚀 Сверхчеловеческая плавная герцовка! Видеокарта горит!'}
          </div>
        </div>
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Plane } from 'lucide-react';
import { FlightTracker } from './FlightTracker';

interface ToolProps {
  onClose: () => void;
}

const FLIGHTS = [
  { from: 'Москва', to: 'Париж', price: '45,000 ₽', duration: '3ч 40м' },
  { from: 'Санкт-Петербург', to: 'Сочи', price: '12,500 ₽', duration: '4ч 10м' },
  { from: 'Москва', to: 'Токио', price: '78,000 ₽', duration: '9ч 30м' },
  { from: 'Москва', to: 'Киев', price: '9,900 ₽', duration: '1ч 50м' },
  { from: 'Москва', to: 'Сургут', price: '21,400 ₽', duration: '3ч 15м' },
  { from: 'Воронеж', to: 'Ад', price: '6,660 ₽', duration: '6ч 06м' },
  { from: 'Ростов-на-Дону', to: 'Самара', price: '7,300 ₽', duration: '1ч 55м' },
  { from: 'Сыктывкар', to: 'Неизвестность', price: '15,000 ₽', duration: '∞' },
  { from: 'Саратов', to: 'Донецк', price: '11,200 ₽', duration: '2ч 25м' },
  { from: 'Вашингтон', to: 'Бахмут', price: '134,000 ₽', duration: '14ч 40м' },
  { from: 'Варшава', to: 'Токио', price: '92,500 ₽', duration: '12ч 05м' },
  { from: 'Аделаида', to: 'Преисподняя', price: '66,600 ₽', duration: '13ч 13м' },
  { from: 'Урюпинск', to: 'Урюпинск', price: '1,000 ₽', duration: '0ч 00м' },
  { from: 'Челябинск', to: 'Мусорка', price: '300 ₽', duration: '0ч 20м' },
  { from: 'Шанхай', to: 'Сиэтл', price: '58,700 ₽', duration: '11ч 45м' },
  { from: 'Оттава', to: '1914', price: '1,914,000 ₽', duration: '112 лет' },
  { from: '2026', to: '1939', price: '2,026,000 ₽', duration: '87 лет' },
  { from: 'Майами', to: 'Караганда', price: '104,300 ₽', duration: '19ч 20м' },
  { from: 'Нджамена', to: 'Баня-Лука', price: '73,800 ₽', duration: '8ч 50м' },
];

export const AviasalesTool: React.FC<ToolProps> = ({ onClose }) => {
  const [selectedFlight, setSelectedFlight] = useState<typeof FLIGHTS[0] | null>(null);
  const [purchasedModal, setPurchasedModal] = useState(false);
  const [tab, setTab] = useState<'flights' | 'tracker'>('flights');

  const handleConfirmPurchase = () => {
    setSelectedFlight(null);
    setPurchasedModal(true);
  };

  return (
    <ToolWrapper title="Авиасейлс" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col gap-6 py-4">
        {/* Вкладки */}
        <div className="grid grid-cols-2 border border-black">
          {([
            ['flights', 'Рейсы'],
            ['tracker', 'Трекер самолётов'],
          ] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`py-2.5 text-[12px] uppercase tracking-[0.02em] cursor-pointer border-0 ${tab === id ? 'bg-black text-white' : 'bg-white text-black'}`}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === 'tracker' && <FlightTracker />}

        {tab === 'flights' && (
          <>
        {/* Banner */}
        <div className="bg-neutral-400 rounded-3xl p-6 text-neutral-50 shadow-2xl flex items-center justify-between font-bold">
          <div>
            <h1 className="text-2xl font-black uppercase tracking-wider">АВИАСЕЙЛС</h1>
            <p className="text-xs text-neutral-100 mt-1">Поиск дешёвых авиабилетов</p>
          </div>
          <Plane className="w-10 h-10 transform -rotate-45" />
        </div>

        {/* Flight Cards */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-neutral-600 uppercase tracking-wider px-1">
            Доступные рейсы:
          </h3>
          {FLIGHTS.map((flight, idx) => (
            <div
              key={idx}
              className="bg-neutral-100 border border-neutral-200 hover:border-neutral-600 rounded-2xl p-4 flex items-center justify-between"
            >
              <div>
                <div className="text-black font-bold text-base flex items-center gap-2">
                  <span>{flight.from}</span>
                  <Plane className="w-4 h-4 text-neutral-600" />
                  <span>{flight.to}</span>
                </div>
                <span className="text-xs text-neutral-600 font-mono">{flight.duration}</span>
              </div>
              <button
                onClick={() => setSelectedFlight(flight)}
                className="px-4 py-2 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black text-xs rounded-xl uppercase transition-colors cursor-pointer"
              >
                {flight.price}
              </button>
            </div>
          ))}
        </div>

          </>
        )}

        {/* Scroll Confirm Modal */}
        {selectedFlight && (
          <div className="fixed inset-0 bg-white/90 z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-sm bg-neutral-100 border border-neutral-300 rounded-3xl p-6 text-center shadow-2xl flex flex-col h-[70vh]">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-black uppercase">Оформление билета</h3>
                <button
                  onClick={() => setSelectedFlight(null)}
                  className="text-neutral-600 hover:text-black text-xs font-bold uppercase"
                >
                  Отмена
                </button>
              </div>

              <div className="text-left text-xs font-bold text-neutral-600 mb-2">
                Рейс: {selectedFlight.from} ➔ {selectedFlight.to} ({selectedFlight.price})
              </div>

              {/* Прокручиваемая область: кнопка подтверждения находится очень далеко внизу, подсказок нет */}
              <div className="flex-1 overflow-y-auto bg-neutral-50 p-4 rounded-2xl border border-neutral-200">
                <div style={{ height: '4200px' }} />
                <div className="pt-4 border-t border-neutral-200">
                  <button
                    onClick={handleConfirmPurchase}
                    className="w-full py-4 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black rounded-xl uppercase tracking-wider cursor-pointer shadow-lg"
                  >
                    Подтвердить покупку
                  </button>
                </div>
                <div style={{ height: '40px' }} />
              </div>
            </div>
          </div>
        )}

        {/* Purchased Toast */}
        {purchasedModal && (
          <div className="fixed inset-0 bg-white/90 z-50 flex items-center justify-center p-6">
            <div className="w-full max-w-sm bg-neutral-100 border-2 border-neutral-600 rounded-3xl p-8 text-center shadow-2xl">
              <div className="text-6xl mb-4">✈️</div>
              <h2 className="text-2xl font-black text-black uppercase mb-4 leading-tight">
                Вы успешно купили билет
              </h2>
              <button
                onClick={() => setPurchasedModal(false)}
                className="w-full py-3 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black rounded-xl uppercase cursor-pointer"
              >
                Закрыть
              </button>
            </div>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

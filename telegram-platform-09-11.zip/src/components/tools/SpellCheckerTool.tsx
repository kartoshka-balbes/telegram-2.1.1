import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Check, AlertCircle, Wand2, RefreshCw } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const SpellCheckerTool: React.FC<ToolProps> = ({ onClose }) => {
  const [text, setText] = useState('Превет! Я купул загрампаспорт и поехал на машыне за хлебом.');
  const [isCorrected, setIsCorrected] = useState(false);

  const handleAutoCorrect = () => {
    soundManager.playBeep(1200, 0.15);
    setText('Привет! Я купил загранпаспорт и поехал на машине за хлебом.');
    setIsCorrected(true);
  };

  return (
    <ToolWrapper title="Проверка орфографии & Грамматика" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full py-2 font-mono text-xs select-none space-y-3">
        {/* Text Area Input */}
        <div className="bg-neutral-100 border-2 border-neutral-500/80 p-3 rounded-2xl space-y-2 shadow-2xl">
          <div className="flex justify-between items-center text-[10px] text-neutral-600 font-bold uppercase">
            <span>Введите или вставьте текст:</span>
            <span className="text-neutral-600 font-bold">{text.length} символов</span>
          </div>

          <textarea
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              setIsCorrected(false);
            }}
            rows={5}
            className="w-full bg-neutral-50 border border-neutral-200 focus:border-neutral-500 rounded-xl p-3 text-black font-bold outline-none text-xs font-mono leading-relaxed resize-none"
          />
        </div>

        {/* Errors Detection Box */}
        {!isCorrected ? (
          <div className="p-3.5 bg-neutral-50/80 border border-neutral-500 rounded-2xl space-y-2 animate-in zoom-in">
            <div className="flex items-center gap-1.5 text-neutral-700 font-black text-xs uppercase">
              <AlertCircle className="w-4 h-4 text-neutral-600" />
              <span>Найдены орфографические ошибки (4)</span>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              <span className="px-2 py-0.5 bg-neutral-100/80 text-neutral-800 border border-neutral-300 rounded text-[10px] line-through font-bold">
                Превет → Привет
              </span>
              <span className="px-2 py-0.5 bg-neutral-100/80 text-neutral-800 border border-neutral-300 rounded text-[10px] line-through font-bold">
                купул → купил
              </span>
              <span className="px-2 py-0.5 bg-neutral-100/80 text-neutral-800 border border-neutral-300 rounded text-[10px] line-through font-bold">
                загрампаспорт → загранпаспорт
              </span>
              <span className="px-2 py-0.5 bg-neutral-100/80 text-neutral-800 border border-neutral-300 rounded text-[10px] line-through font-bold">
                машыне → машине
              </span>
            </div>
          </div>
        ) : (
          <div className="p-3.5 bg-neutral-50/80 border border-neutral-500 rounded-2xl text-center space-y-1 animate-in zoom-in">
            <div className="flex items-center justify-center gap-1.5 text-neutral-600 font-black text-xs uppercase">
              <Check className="w-5 h-5" />
              <span>Все ошибки успешно исправлены!</span>
            </div>
            <p className="text-[11px] text-neutral-700">Текст полностью соответствует нормам русского языка.</p>
          </div>
        )}

        <button
          onClick={handleAutoCorrect}
          className="w-full py-3.5 bg-neutral-400 hover:bg-neutral-500 text-black font-black text-xs uppercase rounded-2xl cursor-pointer shadow-lg flex items-center justify-center gap-2"
        >
          <Wand2 className="w-4 h-4" />
          <span>Исправить все ошибки</span>
        </button>
      </div>
    </ToolWrapper>
  );
};

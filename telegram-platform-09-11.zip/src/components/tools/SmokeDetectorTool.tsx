import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Flame, AlertTriangle, X } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const SmokeDetectorTool: React.FC<ToolProps> = ({ onClose }) => {
  const [warnings, setWarnings] = useState<string[]>([]);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  useEffect(() => {
    // First warning after 6 seconds
    const firstTimer = setTimeout(() => {
      triggerSmokeWarning();

      // Then every 7-8 seconds
      const recurringInterval = setInterval(() => {
        triggerSmokeWarning();
      }, 7500);

      return () => clearInterval(recurringInterval);
    }, 6000);

    return () => clearTimeout(firstTimer);
  }, []);

  const triggerSmokeWarning = () => {
    soundManager.playNuclearAlarm();
    const time = new Date().toLocaleTimeString();
    const msg = `🚨 ОБНАРУЖЕНО ЗАДЫМЛЕНИЕ В ПОМЕЩЕНИИ! (${time})`;
    setWarnings((prev) => [msg, ...prev]);
    setActiveModal(msg);
  };

  return (
    <ToolWrapper title="Датчик дыма" onClose={onClose} headerColor="bg-neutral-100 border-neutral-200">
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-between py-4 font-mono text-xs">
        <div className="bg-neutral-100 border border-neutral-200 p-4 text-center space-y-1">
          <Flame className="w-8 h-8 text-neutral-500 mx-auto animate-pulse" />
          <h3 className="text-base font-black text-black uppercase">ПОЖАРНО-ИЗВЕЩАТЕЛЬНЫЙ ДАТЧИК</h3>
          <p className="text-neutral-600 text-[10px]">ОПТИЧЕСКИЙ ДАТЧИК ДЫМА И ГАЗА</p>
        </div>

        <div className="bg-neutral-100 border border-neutral-200 p-4 space-y-3 my-auto">
          <span className="text-neutral-600 font-bold block text-[10px] uppercase">
            ЖУРНАЛ СРАБАТЫВАНИЙ ДАТЧИКА:
          </span>

          {warnings.length === 0 ? (
            <div className="p-6 text-center text-neutral-500 font-bold">
              Датчик активен. Ожидание первого сигнала (6 сек)...
            </div>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {warnings.map((w, idx) => (
                <div key={idx} className="p-3 bg-neutral-50/60 border border-neutral-200 text-neutral-700 font-extrabold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-neutral-500 shrink-0" />
                  <span>{w}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Smoke Popup Warning Modal */}
        {activeModal && (
          <div className="fixed inset-0 bg-neutral-50/90 z-50 flex items-center justify-center p-6 animate-in zoom-in duration-150">
            <div className="w-full max-w-sm bg-neutral-100 border-4 border-neutral-400 p-6 text-center shadow-2xl relative font-mono space-y-4">
              <button
                onClick={() => setActiveModal(null)}
                className="absolute top-3 right-3 text-neutral-600 hover:text-black"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="text-6xl animate-bounce">💨</div>
              <h2 className="text-lg font-black text-neutral-500 uppercase tracking-widest">
                ВНИМАНИЕ!
              </h2>
              <p className="text-black font-black text-sm">{activeModal}</p>
              <button
                onClick={() => setActiveModal(null)}
                className="w-full py-3 bg-neutral-400 hover:bg-neutral-500 text-black font-black uppercase text-xs cursor-pointer"
              >
                ПРИНЯТЬ ТРЕВОГУ
              </button>
            </div>
          </div>
        )}

        <div className="p-3 bg-neutral-100 border border-neutral-200 text-center text-neutral-500 text-[10px]">
          АВТОНОМНЫЙ ПИТАТЕЛЬ 9V • СТАНДАРТ EN 14604
        </div>
      </div>
    </ToolWrapper>
  );
};

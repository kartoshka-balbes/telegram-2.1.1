import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';

interface ToolProps {
  onClose: () => void;
}

type ColorMode = 'white' | 'red' | 'blue' | 'yellow' | 'purple' | 'green' | 'brown' | 'epilepsy';

const COLOR_VALUES: Record<ColorMode, string> = {
  white: '#000000',
  red: '#b3b3b3',
  blue: '#a6a6a6',
  yellow: '#272727',
  purple: '#b2b2b2',
  green: '#626262',
  brown: '#ababab',
  epilepsy: '#a9a9a9',
};

const EPILEPSY_COLORS = ['#b3b3b3', '#5c5c5c', '#e2e2e2', '#1d1d1d', '#969696', '#4c4c4c'];

export const FlashlightTool: React.FC<ToolProps> = ({ onClose }) => {
  const [isOn, setIsOn] = useState(false);
  const [selectedColor, setSelectedColor] = useState<ColorMode>('red');
  const [currentEpilepsyIdx, setCurrentEpilepsyIdx] = useState(0);

  useEffect(() => {
    if (selectedColor === 'epilepsy' && isOn) {
      const interval = setInterval(() => {
        setCurrentEpilepsyIdx((prev) => (prev + 1) % EPILEPSY_COLORS.length);
      }, 400);
      return () => clearInterval(interval);
    }
  }, [selectedColor, isOn]);

  const activeBgColor =
    selectedColor === 'epilepsy'
      ? EPILEPSY_COLORS[currentEpilepsyIdx]
      : COLOR_VALUES[selectedColor];

  return (
    <ToolWrapper title="Фонарик" onClose={onClose}>
      {/* Fullscreen light overlay when ON */}
      {isOn && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-6 transition-colors duration-300"
          style={{ backgroundColor: activeBgColor }}
        >
          <button
            onClick={() => setIsOn(false)}
            className="px-8 py-4 bg-neutral-100/90 text-black font-black text-2xl rounded-2xl border-4 border-black shadow-2xl hover:scale-105 active:scale-95 transition-transform uppercase cursor-pointer"
          >
            ВЫКЛ
          </button>
        </div>
      )}

      <div className="flex-1 flex flex-col items-center justify-center max-w-sm mx-auto w-full py-6">
        {/* Big Glow Circle */}
        <div className="relative mb-8 flex items-center justify-center">
          <div
            className={`w-44 h-44 rounded-full border-4 border-neutral-500 flex items-center justify-center shadow-2xl transition-all duration-300 ${
              isOn ? 'scale-110 shadow-neutral-500/80 animate-pulse' : 'opacity-80'
            }`}
            style={{
              backgroundColor: COLOR_VALUES[selectedColor],
              boxShadow: isOn ? `0 0 60px ${COLOR_VALUES[selectedColor]}` : 'none',
            }}
          />
        </div>

        {/* Toggle Button */}
        <button
          onClick={() => setIsOn(!isOn)}
          className={`w-full py-4 rounded-2xl font-black text-xl uppercase tracking-wider shadow-xl transition-all mb-10 cursor-pointer ${
            isOn
              ? 'bg-neutral-400 hover:bg-neutral-500 text-black shadow-neutral-400/50'
              : 'bg-neutral-500 hover:bg-neutral-600 text-neutral-50 shadow-neutral-500/50'
          }`}
        >
          {isOn ? 'ВЫКЛ' : 'ВКЛЮЧИТЬ'}
        </button>

        {/* Small Color Selector Circles */}
        <div className="w-full bg-neutral-100 border border-neutral-200 rounded-2xl p-4">
          <div className="text-xs font-bold text-neutral-600 uppercase tracking-wider text-center mb-3">
            Выберите цвет луча:
          </div>
          <div className="grid grid-cols-4 gap-3">
            {(
              [
                { id: 'white', label: 'Белый', color: '#000000' },
                { id: 'red', label: 'Красный', color: '#b3b3b3' },
                { id: 'blue', label: 'Синий', color: '#a6a6a6' },
                { id: 'yellow', label: 'Жёлтый', color: '#272727' },
                { id: 'purple', label: 'Фиолетовый', color: '#b2b2b2' },
                { id: 'green', label: 'Зелёный', color: '#626262' },
                { id: 'brown', label: 'Коричневый', color: '#ababab' },
                { id: 'epilepsy', label: 'Эпилепсия', color: 'rainbow' },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                onClick={() => setSelectedColor(item.id)}
                className={`p-2 rounded-xl flex flex-col items-center gap-1 border transition-all cursor-pointer ${
                  selectedColor === item.id
                    ? 'border-neutral-600 bg-neutral-200 scale-105 shadow-md'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <div
                  className="w-7 h-7 rounded-full border border-neutral-300 shadow-inner"
                  style={{
                    background:
                      item.color === 'rainbow'
                        ? 'linear-gradient(45deg, red, yellow, green, cyan, blue, magenta)'
                        : item.color,
                  }}
                />
                <span className="text-[10px] text-neutral-700 font-semibold truncate w-full text-center">
                  {item.label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </ToolWrapper>
  );
};

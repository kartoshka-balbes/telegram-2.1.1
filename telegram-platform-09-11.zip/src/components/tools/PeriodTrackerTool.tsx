import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Heart, Calendar, Smile, Shield } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

export const PeriodTrackerTool: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [day, setDay] = useState(14);

  return (
    <ToolWrapper title="Женский календарь & Трекер цикла" onClose={onClose} headerColor="bg-[#eaeaea] border-[#d6d6d6]">
      <div className="flex-1 flex flex-col gap-3 max-w-md mx-auto w-full py-2 font-sans select-none overflow-y-auto pr-1">
        
        {/* Main Status Circle */}
        <div className="bg-[#ededed] border border-[#d6d6d6] p-5 rounded-3xl text-center flex flex-col items-center justify-center space-y-2 shadow-md">
          <div className="w-28 h-28 rounded-full border-4 border-[#5c5c5c] bg-[#d6d6d6]/30 flex flex-col items-center justify-center shadow-[inset_0_0_15px_rgba(92,92,92,0.2)]">
            <Heart className="w-8 h-8 text-[#5c5c5c] fill-[#5c5c5c]" />
            <span className="text-lg font-black text-black font-mono mt-0.5">{day} День</span>
            <span className="text-[9px] text-[#5c5c5c] uppercase font-bold">Овуляция</span>
          </div>
          <p className="text-xs text-neutral-700 font-bold">Фаза: Высокая вероятность зачатия (14/28 день)</p>
        </div>

        {/* Symptoms & Mood */}
        <div className="bg-[#eaeaea] p-3.5 rounded-2xl border border-[#d6d6d6] space-y-2">
          <div className="text-xs font-extrabold text-neutral-700 uppercase">Симптомы сегодня:</div>
          <div className="flex flex-wrap gap-1.5">
            {['😊 Хорошее настроение', '☕ Хочется кофе', '🍫 Хочется сладкого', '😴 Легкая усталость'].map((s, i) => (
              <span key={i} className="text-[10px] bg-[#e4e4e4] border border-[#d6d6d6] text-neutral-700 px-2.5 py-1 rounded-xl font-bold">
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* Prediction */}
        <div className="bg-[#ededed] p-3 rounded-2xl border border-[#d6d6d6] flex items-center justify-between">
          <span className="text-xs font-bold text-neutral-600">Следующий цикл через:</span>
          <span className="text-xs font-black text-[#3a3a3a] font-mono">14 дней (15 сентября)</span>
        </div>

      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { X } from 'lucide-react';

interface ToolProps {
  onClose: () => void;
}

export const BurgerKingTool: React.FC<ToolProps> = ({ onClose }) => {
  const [showModal, setShowModal] = useState(true);

  const handleCloseNotification = () => {
    setShowModal(false);
    onClose();
  };
  return (
    <ToolWrapper title="Бургер Кинг" onClose={onClose}>
      <div className="relative flex-1 flex flex-col py-4">
        {/* Background menu layout */}
        <div className="w-full max-w-2xl mx-auto space-y-4">
          <input
            type="text"
            placeholder="Поиск блюд (Воппер, Наггетсы)..."
            className="w-full bg-neutral-100 border border-neutral-300 rounded-2xl p-4 text-black text-sm"
          />
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-neutral-100 border border-neutral-200 p-4 rounded-2xl text-center">
              <div className="text-5xl mb-2">🍔</div>
              <div className="font-bold text-black text-sm">Воппер Комбо</div>
              <span className="text-xs text-neutral-600 font-mono font-bold">399 ₽</span>
            </div>
            <div className="bg-neutral-100 border border-neutral-200 p-4 rounded-2xl text-center">
              <div className="text-5xl mb-2">🍟</div>
              <div className="font-bold text-black text-sm">Кинг Фри</div>
              <span className="text-xs text-neutral-600 font-mono font-bold">149 ₽</span>
            </div>
          </div>
        </div>

        {/* Popup Modal with Close capability */}
        {showModal && (
          <div className="fixed inset-0 bg-white/85 z-50 flex items-center justify-center p-6">
            <div className="w-full max-w-md bg-gradient-to-b from-neutral-400 to-neutral-100 border-4 border-neutral-600 rounded-3xl p-8 text-center shadow-2xl relative">
              <button
                onClick={handleCloseNotification}
                className="absolute top-4 right-4 text-black/80 hover:text-black p-1 rounded-full bg-white/40 cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
              <div className="text-7xl mb-4 animate-bounce">💩</div>
              <h1 className="text-3xl md:text-4xl font-black text-neutral-700 tracking-wider leading-tight uppercase mb-6">
                БУРГЕР КИНГ ГОВНО
              </h1>
              <button
                onClick={handleCloseNotification}
                className="w-full py-3 bg-neutral-600 hover:bg-neutral-700 text-neutral-50 font-black rounded-xl uppercase tracking-wider cursor-pointer shadow-lg"
              >
                Закрыть
              </button>
            </div>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Mic, AlertTriangle, ShoppingCart, Send } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const YandexAliceTool: React.FC<ToolProps> = ({ onClose }) => {
  const [query, setQuery] = useState('');
  const [showError, setShowError] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);

  const handleAsk = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    soundManager.playBeep(800, 0.1);
    // Show access error only on attempt
    setShowError(true);
  };

  const handleBuyMicrophone = () => {
    soundManager.playBeep(400, 0.1);
    // On purchase attempt, show "not supported"
    setPurchaseError('Покупка устройства не поддерживается в вашем регионе или на данном устройстве!');
  };

  return (
    <ToolWrapper title="Яндекс Алиса Голосовой Помощник" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col justify-between py-4 font-mono text-center select-none">
        <div className="bg-neutral-100 border-2 border-neutral-500 p-6 space-y-5 shadow-2xl rounded-3xl">
          {/* Alice Logo */}
          <div className="w-20 h-20 mx-auto bg-neutral-400 rounded-full flex items-center justify-center text-black text-4xl shadow-xl shadow-neutral-400/30 animate-pulse">
            🟣
          </div>

          <h2 className="text-xl font-black text-black uppercase tracking-wider">Яндекс Алиса PRO</h2>

          {!showError ? (
            <div className="space-y-4">
              <p className="text-xs text-neutral-700 font-bold">
                «Привет! Я Алиса. Задайте мне любой вопрос или попросите включить музыку.»
              </p>

              <form onSubmit={handleAsk} className="flex gap-2">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Спросите о чем-нибудь..."
                  className="flex-1 bg-neutral-50 border border-neutral-200 focus:border-neutral-500 rounded-xl px-3 py-2 text-xs text-black outline-none font-bold"
                />
                <button
                  type="submit"
                  className="px-4 bg-neutral-400 hover:bg-neutral-500 text-black rounded-xl font-bold cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

              <button
                onClick={() => handleAsk()}
                className="w-full py-3 bg-neutral-400 hover:bg-neutral-500 text-black font-black text-xs uppercase flex items-center justify-center gap-2 rounded-xl cursor-pointer shadow-lg shadow-neutral-400/20"
              >
                <Mic className="w-5 h-5 animate-bounce" />
                <span>Голосовой ввод</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4 animate-in zoom-in duration-200">
              <div className="p-4 bg-neutral-50/80 border-2 border-neutral-500 rounded-2xl space-y-3">
                <AlertTriangle className="w-8 h-8 text-neutral-600 mx-auto animate-bounce" />
                <div className="text-sm font-black text-neutral-700 uppercase">ОШИБКА ДОСТУПА!</div>
                <p className="text-xs text-black leading-relaxed font-bold">
                  Для работы голосового помощника требуется купить премиум-микрофон студийного качества за{' '}
                  <span className="text-neutral-600 text-sm font-black underline">999 000 ₽</span> в Яндекс Маркете!
                </p>
              </div>

              {purchaseError && (
                <div className="p-3 bg-neutral-50 border border-neutral-500 text-neutral-700 text-xs font-bold rounded-xl animate-in fade-in">
                  ❌ {purchaseError}
                </div>
              )}

              <button
                onClick={handleBuyMicrophone}
                className="w-full py-3.5 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black text-xs uppercase flex items-center justify-center gap-2 cursor-pointer shadow-lg rounded-xl"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>Купить микрофон за 999 000 ₽</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </ToolWrapper>
  );
};

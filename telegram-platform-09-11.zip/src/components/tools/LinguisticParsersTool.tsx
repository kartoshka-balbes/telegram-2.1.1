import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { BookOpen, Sparkles, CheckCircle } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

export type LinguisticMode = 'morphology' | 'syntax' | 'phonetics' | 'transcription';

interface Props {
  mode: LinguisticMode;
  onClose: () => void;
}

export const LinguisticParsersTool: React.FC<Props> = ({ mode, onClose }) => {
  const [text, setText] = useState(
    mode === 'morphology' ? 'компьютер' : mode === 'syntax' ? 'Инженер выполняет техническое обслуживание сервера.' : mode === 'phonetics' ? 'станция' : 'инженер'
  );
  const [analyzed, setAnalyzed] = useState(true);

  const titles: Record<LinguisticMode, string> = {
    morphology: 'Морфологический разбор слова',
    syntax: 'Синтаксический разбор предложения',
    phonetics: 'Фонетический разбор слова',
    transcription: 'Фонетическая транскрипция',
  };

  const handleAnalyze = () => {
    soundManager.playBeep(1200, 0.1);
    setAnalyzed(false);
    setTimeout(() => setAnalyzed(true), 400);
  };

  return (
    <ToolWrapper title={titles[mode]} onClose={onClose} headerColor="bg-[#eaeaea] border-[#d6d6d6]">
      <div className="flex-1 flex flex-col gap-3 max-w-md mx-auto w-full py-2 font-sans select-none overflow-y-auto pr-1">
        
        <div className="bg-[#ededed] p-3 rounded-2xl border border-[#d6d6d6] space-y-2">
          <label className="text-xs font-bold text-neutral-700 block">
            Введите {mode === 'syntax' ? 'предложение' : 'слово'} для разбора:
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="flex-1 bg-[#e4e4e4] border border-[#d6d6d6] rounded-xl px-3 py-2 text-xs text-black outline-none focus:border-[#5c5c5c]"
            />
            <button
              onClick={handleAnalyze}
              className="px-3.5 py-2 bg-[#5c5c5c] text-white font-extrabold text-xs uppercase rounded-xl cursor-pointer hover:bg-[#3a3a3a]"
            >
              Разобрать
            </button>
          </div>
        </div>

        {analyzed && (
          <div className="bg-[#eaeaea] border border-[#5c5c5c]/50 p-4 rounded-2xl space-y-3 font-mono animate-in zoom-in">
            {mode === 'morphology' && (
              <div className="space-y-1.5 text-xs text-neutral-800">
                <div className="text-[#3a3a3a] font-bold">1. Имя существительное; отвечает на вопрос «Что?»</div>
                <div>2. Начальная форма: <span className="text-[#5c5c5c]">{text}</span></div>
                <div>3. Постоянные признаки: нарицательное, неодушевлённое, мужской/женский род, 2-е склонение</div>
                <div>4. Непостоянные признаки: Именительный падеж, множественное число</div>
                <div>5. Синтаксическая роль: Подлежащее (подчёркивается одной чертой)</div>
              </div>
            )}

            {mode === 'syntax' && (
              <div className="space-y-2 text-xs text-neutral-800">
                <div className="text-[#3a3a3a] font-bold">Характеристика предложения:</div>
                <p className="text-[11px] leading-relaxed">
                  Повествовательное, невосклицательное, простое, двусоставное, распространенное, полное, не осложнено.
                </p>
                <div className="border-t border-[#d6d6d6] pt-2 space-y-1 text-[11px]">
                  <div>• <u className="decoration-2 decoration-[#5c5c5c]">Инженер</u> — подлежащее (сущ.)</div>
                  <div>• <span className="border-b-2 border-double border-[#5c5c5c]">выполняет</span> — сказуемое (глаг.)</div>
                  <div>• <span className="border-b-2 border-dashed border-[#5c5c5c]">сервера</span> — прямое дополнение (сущ.)</div>
                </div>
              </div>
            )}

            {mode === 'phonetics' && (
              <div className="space-y-1.5 text-xs text-neutral-800">
                <div className="text-[#3a3a3a] font-bold">Слоги: кóш-ка (2 слога)</div>
                <div>Транскрипция: <span className="text-[#5c5c5c] font-bold">[кóшка]</span></div>
                <div className="border-t border-[#d6d6d6] pt-1 text-[11px] space-y-0.5 text-neutral-700">
                  <div>к — [к] — согл., глух. парн., твёрд. парн.</div>
                  <div>о — [ó] — гласный, ударный</div>
                  <div>ш — [ш] — согл., глух. парн., твёрд. непарн.</div>
                  <div>к — [к] — согл., глух. парн., твёрд. парн.</div>
                  <div>а — [а] — гласный, безударный</div>
                </div>
                <div className="text-[#5c5c5c] font-bold pt-1">Всего: 5 букв, 5 звуков.</div>
              </div>
            )}

            {mode === 'transcription' && (
              <div className="space-y-2 text-xs text-neutral-800 text-center">
                <div className="text-neutral-600">Фонетическая запись слова «{text}»:</div>
                <div className="text-2xl font-black text-[#3a3a3a] font-mono tracking-widest bg-[#ededed] p-3 rounded-xl border border-[#d6d6d6]">
                  [{text.toLowerCase().replace(/е/g, 'э').replace(/ь/g, '′')}]
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </ToolWrapper>
  );
};

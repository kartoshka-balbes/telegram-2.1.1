import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Bot, Send, Sparkles } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
}

const RESPONSES = [
  'Здравствуйте! Я могу помочь вам проанализировать данные или составить подробный отчёт.',
  'Информация принята. Выполняю обработку и форматирование результатов.',
  'Согласно актуальным спецификациям, данный алгоритм работает со сложностью O(n log n).',
  'Запрос успешно обработан базовым модулем анализа.',
  'Введенный фрагмент соответствует стандартной документации и техническим регламентам.',
];

export const ChatGPTTool: React.FC<ToolProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', sender: 'ai', text: 'Привет! Я виртуальный собеседник. Напишите любой вопрос!' },
  ]);
  const [input, setInput] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    soundManager.playBeep(800, 0.05);

    const userMsg: ChatMessage = { id: Date.now().toString(), sender: 'user', text: input.trim() };
    const randomReply = RESPONSES[Math.floor(Math.random() * RESPONSES.length)];
    const aiMsg: ChatMessage = { id: (Date.now() + 1).toString(), sender: 'ai', text: randomReply };

    setMessages((prev) => [...prev, userMsg, aiMsg]);
    setInput('');
  };

  return (
    <ToolWrapper title="ChatGPT OpenAI" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full py-2 font-mono">
        <div className="bg-neutral-100 border-2 border-neutral-500 p-3 flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="flex items-center gap-2 border-b border-neutral-200 pb-2 mb-2">
            <Bot className="w-5 h-5 text-neutral-600" />
            <span className="text-xs font-black text-neutral-600 uppercase">ChatGPT 4o-Omni</span>
          </div>

          {/* Messages */}
          <div className="flex-1 space-y-2 overflow-y-auto p-1 max-h-[350px]">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`p-2.5 max-w-[85%] text-xs font-bold ${
                  m.sender === 'user'
                    ? 'ml-auto bg-neutral-400 text-neutral-50 text-right'
                    : 'mr-auto bg-neutral-50 border border-neutral-200 text-neutral-700'
                }`}
              >
                {m.text}
              </div>
            ))}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSend} className="mt-2 pt-2 border-t border-neutral-200 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Напишите сообщение..."
              className="flex-1 bg-neutral-50 border border-neutral-200 p-2 text-xs text-black outline-none focus:border-neutral-500"
            />
            <button
              type="submit"
              className="px-4 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black text-xs uppercase cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Monitor, Cpu, Sliders, Check } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

export const NvidiaControlPanelTool: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [dsr, setDsr] = useState('4.00x (4K Ultra)');
  const [gSync, setGSync] = useState(true);
  const [filtering, setFiltering] = useState('16x (Максимальное качество)');
  const [applied, setApplied] = useState(false);

  const handleApply = () => {
    soundManager.playBeep(1200, 0.1);
    setApplied(true);
    setTimeout(() => setApplied(false), 2500);
  };

  return (
    <ToolWrapper title="Панель управления NVIDIA" onClose={onClose} headerColor="bg-[#eaeaea] border-[#5c5c5c]">
      <div className="flex-1 flex flex-col gap-3 max-w-md mx-auto w-full py-2 font-mono select-none overflow-y-auto pr-1">
        
        {/* Top Banner */}
        <div className="bg-[#ededed] p-3 rounded-2xl border border-[#5c5c5c] flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-black text-[#5c5c5c]">NVIDIA</span>
            <div>
              <div className="text-xs font-bold text-black">GeForce RTX 5090 Ti</div>
              <div className="text-[9px] text-neutral-600">Драйвер v560.81 WHQL</div>
            </div>
          </div>
          <span className="text-[10px] bg-[#5c5c5c] text-white px-2 py-0.5 rounded font-black uppercase">
            3D Pro
          </span>
        </div>

        {applied && (
          <div className="p-3 bg-[#d6d6d6] border border-[#5c5c5c] text-[#5c5c5c] text-xs font-bold text-center rounded-xl animate-in zoom-in">
            Параметры 3D успешно применены к видеокарте!
          </div>
        )}

        {/* Settings tree */}
        <div className="bg-[#eaeaea] border border-[#d6d6d6] p-4 rounded-2xl space-y-3 font-sans">
          <div className="text-xs font-extrabold text-[#5c5c5c] uppercase border-b border-[#d6d6d6] pb-1">
            Управление параметрами 3D
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-neutral-700 font-medium">DSR - Степень:</span>
              <select
                value={dsr}
                onChange={(e) => setDsr(e.target.value)}
                className="bg-[#e4e4e4] border border-[#d6d6d6] text-[#5c5c5c] rounded-lg px-2 py-1 text-xs outline-none"
              >
                <option>1.78x DL</option>
                <option>2.25x DL</option>
                <option>4.00x (4K Ultra)</option>
              </select>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-neutral-700 font-medium">G-SYNC:</span>
              <input
                type="checkbox"
                checked={gSync}
                onChange={(e) => setGSync(e.target.checked)}
                className="accent-[#5c5c5c] w-4 h-4 cursor-pointer"
              />
            </div>

            <div className="flex justify-between items-center">
              <span className="text-neutral-700 font-medium">Анизотропная фильтрация:</span>
              <select
                value={filtering}
                onChange={(e) => setFiltering(e.target.value)}
                className="bg-[#e4e4e4] border border-[#d6d6d6] text-[#5c5c5c] rounded-lg px-2 py-1 text-xs outline-none"
              >
                <option>Выкл</option>
                <option>4x</option>
                <option>8x</option>
                <option>16x (Максимальное качество)</option>
              </select>
            </div>
          </div>
        </div>

        <button
          onClick={handleApply}
          className="w-full py-3.5 bg-[#5c5c5c] hover:bg-[#3a3a3a] text-white font-extrabold text-xs uppercase rounded-2xl shadow-md cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-1.5"
        >
          <Check className="w-4 h-4" /> Применить Настройки
        </button>

      </div>
    </ToolWrapper>
  );
};

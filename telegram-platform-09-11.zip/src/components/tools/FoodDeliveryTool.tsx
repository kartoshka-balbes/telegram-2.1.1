import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Utensils, MapPin, Navigation, Clock } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const FoodDeliveryTool: React.FC<ToolProps> = ({ onClose }) => {
  const [selectedFood, setSelectedFood] = useState<string | null>(null);
  const [isDelivering, setIsDelivering] = useState(false);

  const menu = [
    { name: 'Бургер Сочный Мощный 250г', price: '450 ₽', icon: '🍔' },
    { name: 'Пицца Пепперони 30см', price: '690 ₽', icon: '🍕' },
    { name: 'Шаурма Сытная Классика', price: '280 ₽', icon: '🌯' },
    { name: 'Суши Сет «Филадельфия»', price: '1 290 ₽', icon: '🍣' },
    { name: 'Вок с курицей Teriyaki', price: '420 ₽', icon: '🍜' },
    { name: 'Рамен Острый с телятиной', price: '510 ₽', icon: '🍲' },
    { name: 'Тако с говядиной и гуакамоле', price: '390 ₽', icon: '🌮' },
    { name: 'Чизкейк Нью-Йорк', price: '290 ₽', icon: '🍰' },
  ];

  const handleOrder = (foodName: string) => {
    soundManager.playBeep(800, 0.1);
    setSelectedFood(foodName);
    setIsDelivering(true);
  };

  return (
    <ToolWrapper title="Яндекс Еда / Быстрая Доставка" onClose={onClose} headerColor="bg-[#eaeaea] border-[#d6d6d6]">
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full py-2 font-sans text-xs select-none">
        {!isDelivering ? (
          <div className="space-y-2.5">
            <span className="text-xs font-extrabold text-[#5c5c5c] uppercase block mb-1">Выберите блюдо для быстрой доставки:</span>
            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {menu.map((m) => (
                <div key={m.name} className="bg-[#eaeaea] border border-[#d6d6d6] p-3.5 rounded-2xl flex justify-between items-center hover:border-[#5c5c5c]/50 transition-all shadow-md">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{m.icon}</span>
                    <div>
                      <h4 className="text-xs font-extrabold text-black">{m.name}</h4>
                      <span className="text-xs font-black text-[#3a3a3a] font-mono">{m.price}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleOrder(m.name)}
                    className="px-3.5 py-2 bg-[#5c5c5c] hover:bg-[#3a3a3a] text-white font-extrabold text-xs uppercase cursor-pointer rounded-xl shadow-[0_0_10px_rgba(92,92,92,0.3)] transition-all active:scale-95"
                  >
                    Заказать
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-[#eaeaea] border-2 border-[#5c5c5c] p-6 text-center space-y-4 rounded-3xl shadow-[0_0_30px_rgba(92,92,92,0.2)] animate-in zoom-in">
            <div className="w-16 h-16 bg-[#5c5c5c] rounded-full flex items-center justify-center text-white mx-auto animate-bounce text-3xl shadow-[0_0_15px_rgba(92,92,92,0.4)]">
              🛵
            </div>
            <h3 className="text-base font-black text-[#5c5c5c] uppercase tracking-wider">КУРЬЕР УЖЕ В ПУТИ!</h3>
            <div className="bg-[#ededed] border border-[#d6d6d6] p-4 text-xs text-black rounded-2xl space-y-2 shadow-inner">
              <div>Заказ: <span className="font-extrabold text-[#5c5c5c]">{selectedFood}</span></div>
              <div className="pt-2 border-t border-[#d6d6d6]">
                Ожидаемое время доставки (увеличено в 786 раз):
                <div className="text-lg font-black text-neutral-600 font-mono mt-1">
                  9 432 МИНУТЫ (157 ЧАСОВ)
                </div>
                <span className="text-[10px] text-neutral-600 font-bold">(~ 6.5 дней ожидания)</span>
              </div>
            </div>
            <button
              onClick={() => setIsDelivering(false)}
              className="w-full py-3 bg-[#e4e4e4] hover:bg-[#dcdcdc] border border-[#d6d6d6] text-neutral-700 font-extrabold text-xs uppercase cursor-pointer rounded-xl transition-all"
            >
              Вернуться в меню
            </button>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Wind, AlertTriangle } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const BreathalyzerTool: React.FC<ToolProps> = ({ onClose }) => {
  const [measuring, setMeasuring] = useState(false);
  const [percentResult, setPercentResult] = useState<number | null>(null);

  const handleBlow = () => {
    soundManager.playBeep(600, 0.1);
    setMeasuring(true);
    setPercentResult(null);

    setTimeout(() => {
      soundManager.playSiren();
      setMeasuring(false);
      // Random result strictly between 42.2% and 91.78%
      const val = 42.2 + Math.random() * (91.78 - 42.2);
      setPercentResult(parseFloat(val.toFixed(2)));
    }, 2000);
  };

  const norm = 0.16;
  const multiplier = percentResult ? (percentResult / norm).toFixed(1) : '0';
  const state = measuring ? 'measure' : percentResult !== null ? 'result' : 'ready';

  return (
    <ToolWrapper title="Алкотестер" onClose={onClose}>
      <div className="max-w-sm mx-auto w-full flex-1 flex flex-col items-center py-2 select-none">
        {/* Корпус прибора */}
        <div className="relative w-full rounded-[2.5rem] bg-gradient-to-b from-[#d0d0d0] via-[#e2e2e2] to-[#eeeeee] border border-black/10 shadow-[0_30px_70px_rgba(255,255,255,0.6)] px-5 pt-3 pb-6">
          {/* Мундштук */}
          <div className="mx-auto -mt-1 w-28 h-9 rounded-b-3xl bg-gradient-to-b from-[#c0c0c0] to-[#d9d9d9] border border-black/10 flex items-center justify-center gap-1.5 shadow-inner">
            {[0, 1, 2, 3, 4].map((i) => (
              <span key={i} className="w-1.5 h-4 rounded-full bg-white/60" />
            ))}
          </div>

          {/* Индикаторы */}
          <div className="flex items-center justify-between mt-4 px-1">
            <div className="flex items-center gap-2">
              {[
                { c: 'bg-neutral-600', on: state === 'ready', l: 'ГОТОВ' },
                { c: 'bg-neutral-600', on: state === 'measure', l: 'ЗАМЕР' },
                { c: 'bg-neutral-500', on: state === 'result', l: 'ТРЕВОГА' },
              ].map((d) => (
                <div key={d.l} className="flex flex-col items-center gap-1">
                  <span
                    className={`w-3 h-3 rounded-full ${d.c} ${d.on ? 'shadow-[0_0_12px_currentColor] opacity-100' : 'opacity-20'} ${
                      d.on && state !== 'ready' ? 'animate-pulse' : ''
                    }`}
                    style={{ color: d.on ? undefined : undefined }}
                  />
                  <span className="text-[8px] text-neutral-500 tracking-widest">{d.l}</span>
                </div>
              ))}
            </div>
            <span className="text-[10px] font-semibold text-neutral-500 tracking-widest">BAC-84920</span>
          </div>

          {/* ЖК-дисплей */}
          <div className="mt-4 rounded-2xl bg-[#535353] border-4 border-[#ffffff] shadow-[inset_0_4px_18px_rgba(255,255,255,0.45)] p-4 min-h-[190px] flex flex-col justify-between font-mono text-[#e3e3e3]">
            <div className="flex items-center justify-between text-[10px] font-bold tracking-widest opacity-80">
              <span>{state === 'ready' ? 'READY' : state === 'measure' ? 'ANALYZING' : 'RESULT'}</span>
              <span>BrAC %</span>
            </div>

            <div className="flex-1 flex items-center justify-center text-center">
              {state === 'ready' && (
                <div className="space-y-1">
                  <Wind className="w-9 h-9 mx-auto" />
                  <div className="text-lg font-extrabold leading-tight">ПОДУЙТЕ НА ЭКРАН</div>
                  <div className="text-[10px] font-bold opacity-80 leading-snug">
                    Для проведения измерений удерживайте дыхание на сенсоре
                  </div>
                </div>
              )}

              {state === 'measure' && (
                <div className="w-full space-y-3">
                  <div className="text-base font-extrabold animate-pulse">АНАЛИЗ ВОЗДУХА... (2 СЕК)</div>
                  <div className="h-3 rounded-full bg-[#e3e3e3]/20 overflow-hidden">
                    <div className="h-full bg-[#e3e3e3] rounded-full" style={{ animation: 'brth-fill 2s linear forwards' }} />
                  </div>
                  <style>{`@keyframes brth-fill { from { width: 0%; } to { width: 100%; } }`}</style>
                </div>
              )}

              {state === 'result' && percentResult !== null && (
                <div className="w-full space-y-1">
                  <div className="text-[10px] font-bold tracking-wider">УРОВЕНЬ АЛКОГОЛЯ В КРОВИ</div>
                  <div className="text-6xl font-black tabular-nums leading-none">{percentResult.toFixed(2)}%</div>
                  <div className="flex items-center justify-center gap-1.5 text-[#cfcfcf] font-extrabold text-xs pt-1">
                    <AlertTriangle className="w-4 h-4" /> ПРЕВЫШЕНИЕ ДОПУСТИМОЙ НОРМЫ
                  </div>
                </div>
              )}
            </div>

            {state === 'result' && (
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#e3e3e3]/30 text-left text-[10px] font-bold">
                <div>
                  <span className="opacity-70 block">Допустимая норма:</span>
                  <span className="text-sm">0.16%</span>
                </div>
                <div>
                  <span className="opacity-70 block">Превышение нормы:</span>
                  <span className="text-sm text-[#cfcfcf]">В {multiplier} РАЗ</span>
                </div>
              </div>
            )}
          </div>

          {/* Кнопка */}
          <div className="mt-6 flex justify-center">
            {state === 'ready' && (
              <button
                onClick={handleBlow}
                className="w-28 h-28 rounded-full bg-gradient-to-b from-neutral-700 to-neutral-500 text-neutral-50 font-black text-sm uppercase flex flex-col items-center justify-center gap-1 shadow-[0_8px_0_#9a9a9a,0_18px_30px_rgba(88,88,88,0.35)] active:translate-y-1 active:shadow-[0_4px_0_#9a9a9a] transition-all cursor-pointer"
              >
                <Wind className="w-7 h-7" />
                <span>ПОДУТЬ</span>
              </button>
            )}
            {state === 'measure' && (
              <div className="w-28 h-28 rounded-full bg-[#d0d0d0] border border-black/10 flex items-center justify-center">
                <div className="w-14 h-14 border-4 border-neutral-600 border-t-transparent rounded-full animate-spin" />
              </div>
            )}
            {state === 'result' && (
              <button
                onClick={handleBlow}
                className="w-full py-3.5 rounded-full bg-gradient-to-b from-neutral-700 to-neutral-500 text-neutral-50 font-black uppercase text-xs cursor-pointer shadow-[0_6px_0_#9a9a9a] active:translate-y-1 active:shadow-[0_2px_0_#9a9a9a] transition-all"
              >
                ПОВТОРИТЬ ТЕСТ
              </button>
            )}
          </div>
        </div>

        <div className="mt-4 text-center text-neutral-500 text-[10px] font-semibold tracking-wider">
          ПРИБОР КАЛИБРОВАН • СЕРТИФИКАТ № 84920-BAC
        </div>
      </div>
    </ToolWrapper>
  );
};

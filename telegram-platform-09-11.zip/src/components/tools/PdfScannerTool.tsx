import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Camera, FileText, Download, Check, Sparkles, Layers } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const PdfScannerTool: React.FC<ToolProps> = ({ onClose }) => {
  const [scannedPages, setScannedPages] = useState<number>(1);
  const [filterMode, setFilterMode] = useState<'Color' | 'B&W' | 'Magic'>('Magic');
  const [isExported, setIsExported] = useState(false);

  const handleScanPage = () => {
    soundManager.playBeep(1200, 0.1);
    setIsExported(false);
    setScannedPages((prev) => prev + 1);
  };

  const handleExportPdf = () => {
    soundManager.playBeep(1500, 0.2);
    setIsExported(true);
  };

  return (
    <ToolWrapper title="Сканер документов PDF" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full py-2 font-mono text-xs select-none space-y-3">
        {/* Camera Scanner Viewport with Document Outline Box */}
        <div className="bg-neutral-50 border-2 border-neutral-500 rounded-2xl h-56 relative overflow-hidden flex flex-col justify-between p-4 shadow-2xl">
          {/* Grid lines */}
          <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px]" />

          {/* Glowing Contour Detection Frame */}
          <div className="absolute inset-6 border-2 border-dashed border-neutral-600 rounded-xl pointer-events-none animate-pulse flex items-center justify-center">
            <div className="bg-neutral-50/80 px-3 py-1 rounded text-[10px] text-neutral-700 font-bold border border-neutral-500">
              [ ДОКУМЕНТ ОБНАРУЖЕН ]
            </div>
          </div>

          <div className="relative z-10 flex justify-between items-center bg-neutral-100/90 border border-neutral-200 p-2 rounded-xl">
            <span className="text-black font-bold flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-neutral-600" /> Отсканировано страниц: {scannedPages}
            </span>
            <span className="text-neutral-600 font-black text-[10px] uppercase">
              Фильтр: {filterMode}
            </span>
          </div>

          {/* Capture Trigger */}
          <div className="relative z-10 flex justify-center">
            <button
              onClick={handleScanPage}
              className="px-6 py-2.5 bg-neutral-400 hover:bg-neutral-500 text-black font-black text-xs uppercase rounded-xl cursor-pointer shadow-lg shadow-neutral-400/30 flex items-center gap-2"
            >
              <Camera className="w-4 h-4" />
              <span>Захватить страницу</span>
            </button>
          </div>
        </div>

        {/* Filter Selector */}
        <div className="bg-neutral-100 border border-neutral-200 p-3 rounded-2xl space-y-2">
          <span className="text-[10px] font-bold text-neutral-600 uppercase block tracking-wider">
            Режим обработки скана:
          </span>
          <div className="grid grid-cols-3 gap-2">
            {(['Magic', 'B&W', 'Color'] as const).map((f) => (
              <button
                key={f}
                onClick={() => {
                  soundManager.playBeep(800, 0.05);
                  setFilterMode(f);
                }}
                className={`py-2 rounded-xl font-bold text-xs cursor-pointer border transition-all ${
                  filterMode === f
                    ? 'bg-neutral-500 text-black border-neutral-600 shadow-md'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600 hover:border-neutral-300'
                }`}
              >
                {f === 'Magic' ? '✨ Четкий текст' : f === 'B&W' ? 'Ч/Б скан' : 'Цветной'}
              </button>
            ))}
          </div>
        </div>

        {/* Export PDF Button */}
        {!isExported ? (
          <button
            onClick={handleExportPdf}
            className="w-full py-3.5 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black text-xs uppercase rounded-2xl cursor-pointer shadow-lg flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Сохранить документ в PDF ({scannedPages} стр.)</span>
          </button>
        ) : (
          <div className="p-4 bg-neutral-50 border-2 border-neutral-500 rounded-2xl text-center space-y-1 animate-in zoom-in">
            <div className="text-neutral-600 font-black uppercase text-xs flex items-center justify-center gap-1.5">
              <Check className="w-5 h-5" />
              <span>Файл "Scan_Document_2026.pdf" сохранен!</span>
            </div>
            <p className="text-[11px] text-neutral-700">Файл успешно загружен в память устройства.</p>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

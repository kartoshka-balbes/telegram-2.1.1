import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { AlarmClock, Bell, BellOff } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const AlarmClockTool: React.FC<ToolProps> = ({ onClose }) => {
  const [alarmTime, setAlarmTime] = useState('07:00');
  const [alarmDate, setAlarmDate] = useState('2026-08-04');
  const [isArmed, setIsArmed] = useState(false);

  useEffect(() => {
    if (!isArmed) return;

    const interval = setInterval(() => {
      soundManager.playSiren();
    }, 1000);

    return () => clearInterval(interval);
  }, [isArmed]);

  return (
    <ToolWrapper title="Будильник" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col items-center justify-center p-4 text-center">
        <div className="bg-neutral-100 border-2 border-neutral-200 rounded-3xl p-6 w-full shadow-2xl flex flex-col items-center gap-6">
          <AlarmClock className={`w-20 h-20 ${isArmed ? 'text-neutral-500 animate-bounce' : 'text-neutral-600'}`} />

          <div className="w-full space-y-4">
            <div className="flex flex-col gap-1 text-left">
              <label className="text-xs font-bold text-neutral-600 uppercase">Время будильника:</label>
              <input
                type="time"
                value={alarmTime}
                onChange={(e) => setAlarmTime(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl p-4 text-black text-xl font-mono outline-none focus:border-neutral-600 text-center font-bold"
              />
            </div>

            <div className="flex flex-col gap-1 text-left">
              <label className="text-xs font-bold text-neutral-600 uppercase">Дата:</label>
              <input
                type="date"
                value={alarmDate}
                onChange={(e) => setAlarmDate(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl p-4 text-black text-base font-mono outline-none focus:border-neutral-600 text-center font-bold"
              />
            </div>
          </div>

          <button
            onClick={() => setIsArmed(!isArmed)}
            className={`w-full py-4 rounded-2xl font-black text-base uppercase tracking-wider shadow-lg transition-transform active:scale-95 cursor-pointer flex items-center justify-center gap-2 ${
              isArmed
                ? 'bg-neutral-400 text-black animate-pulse'
                : 'bg-neutral-500 hover:bg-neutral-600 text-neutral-50'
            }`}
          >
            {isArmed ? (
              <>
                <BellOff className="w-5 h-5" />
                <span>Отключить будильник</span>
              </>
            ) : (
              <>
                <Bell className="w-5 h-5" />
                <span>Завести будильник</span>
              </>
            )}
          </button>
        </div>
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Phone, PhoneCall, HeartHandshake, ShieldAlert, PhoneOff, ArrowRight, UserCheck, Sparkles, Volume2, X } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

interface SupportLine {
  id: string;
  name: string;
  phone: string;
  category: string;
  hours: string;
  badgeColor: string;
  icon: string;
  description: string;
}

const SUPPORT_LINES: SupportLine[] = [
  {
    id: '1',
    name: 'Единый всероссийский телефон доверия',
    phone: '8-800-200-01-22',
    category: 'Кризисная помощь',
    hours: 'Круглосуточно • 24/7',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🤝',
    description: 'Экстренная психологическая помощь при кризисных состояниях и тревоге.',
  },
  {
    id: '2',
    name: 'Служба неотложной психологической помощи',
    phone: '051',
    category: 'Городская линия',
    hours: 'Круглосуточно • Бесплатно',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🏢',
    description: 'Прямая линия поддержки жителей в стрессовых и конфликтных ситуациях.',
  },
  {
    id: '3',
    name: 'Горячая линия душевного равновесия',
    phone: '+7 (495) 989-50-50',
    category: 'Стресс и депрессия',
    hours: '24/7',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🧠',
    description: 'Индивидуальные консультации по преодолению эмоционального выгорания.',
  },
  {
    id: '4',
    name: 'Линия экстренной помощи при панике и страхе',
    phone: '8-800-333-44-34',
    category: 'Панические атаки',
    hours: 'Круглосуточно',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🫀',
    description: 'Техники стабилизации дыхания, заземления и снятия острого приступа тревоги.',
  },
  {
    id: '5',
    name: 'Кабинет мгновенного утешения и поддержки',
    phone: '8-800-500-11-22',
    category: 'Одиночество',
    hours: '24/7 • Анонимно',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🫂',
    description: 'Теплый доверительный разговор, если не с кем разделить накопившиеся переживания.',
  },
  {
    id: '6',
    name: 'Центр психологической реабилитации',
    phone: '8-800-200-47-03',
    category: 'Восстановление',
    hours: 'Круглосуточно',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🌿',
    description: 'Помощь в преодолении постстрессовых реакций и обретении внутренней опоры.',
  },
  {
    id: '7',
    name: 'Горячая линия поддержки «Не грусти»',
    phone: '+7 (999) 777-66-55',
    category: 'Позитив и надежда',
    hours: '08:00 - 02:00',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '☀️',
    description: 'Дружеская поддержка, добрые советы и мотивационные установки на день.',
  },
  {
    id: '8',
    name: 'Скорая антистресс-помощь',
    phone: '+7 (495) 625-31-01',
    category: 'Срочный вызов',
    hours: '24/7 • Экстренно',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🚑',
    description: 'Оперативная психологическая помощь при внезапных стрессовых потрясениях.',
  },
  {
    id: '9',
    name: 'Служба доверия «Второе дыхание»',
    phone: '8-800-100-49-94',
    category: 'Самопознание',
    hours: 'Круглосуточно',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '🌊',
    description: 'Психологические практики для восстановления жизненного ресурса и тонуса.',
  },
  {
    id: '10',
    name: 'Линия принятия и самосострадания',
    phone: '+7 (499) 177-34-94',
    category: 'Самооценка',
    hours: '24/7 • Анонимно',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/40',
    icon: '💖',
    description: 'Поддержка при чувстве вины, самоедстве и синдроме самозванца.',
  }
];

const CALL_OUTCOMES = [
  {
    title: 'Недостаточно средств',
    subtitle: 'На вашем балансе недостаточно средств для совершения данного вызова.',
    icon: '💳',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/50',
    soundType: 'busy',
  },
  {
    title: 'Поплачь',
    subtitle: 'Абонент ответил: «Просто поплачь, легче станет...» и повесил трубку.',
    icon: '😭',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/50',
    soundType: 'cry',
  },
  {
    title: 'Линия занята',
    subtitle: 'Все операторы и специалисты в данный момент заняты на другой линии.',
    icon: '📞',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/50',
    soundType: 'busy',
  },
  {
    title: 'Абонент вне зоны действия сети',
    subtitle: 'Номер временно недоступен или находится вне зоны действия сети.',
    icon: '📶',
    badgeColor: 'bg-neutral-500/20 text-neutral-700 border-neutral-500/50',
    soundType: 'beep',
  },
];

export const PsychologicalHelpTool: React.FC<ToolProps> = ({ onClose }) => {
  const [activeCall, setActiveCall] = useState<SupportLine | null>(null);
  const [callPhase, setCallPhase] = useState<'dialing' | 'result' | null>(null);
  const [chosenOutcome, setChosenOutcome] = useState<(typeof CALL_OUTCOMES)[0] | null>(null);

  const handleStartCall = (line: SupportLine) => {
    setActiveCall(line);
    setCallPhase('dialing');
    soundManager.playPhoneRing();

    // Random outcome selection
    const outcome = CALL_OUTCOMES[Math.floor(Math.random() * CALL_OUTCOMES.length)];
    setChosenOutcome(outcome);

    // Save call attempt into phone history localStorage
    try {
      const raw = localStorage.getItem('phone_call_history');
      const prev = raw ? JSON.parse(raw) : [];
      const newHistoryItem = {
        id: Date.now().toString(),
        name: line.name,
        phone: line.phone,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'Исходящий вызов',
        status: outcome.title,
      };
      const updated = [newHistoryItem, ...prev];
      localStorage.setItem('phone_call_history', JSON.stringify(updated));
      window.dispatchEvent(new Event('phone_history_updated'));
    } catch {}

    // After 2.2 seconds of ringing, reveal the random outcome
    setTimeout(() => {
      setCallPhase('result');
      if (outcome.title === 'Поплачь') {
        soundManager.playBeep(450, 0.4);
      } else {
        soundManager.playBeep(800, 0.2);
      }
    }, 2200);
  };

  const handleCloseCallModal = () => {
    setActiveCall(null);
    setCallPhase(null);
    setChosenOutcome(null);
  };

  const handleOpenPhoneTool = () => {
    handleCloseCallModal();
    window.dispatchEvent(new CustomEvent('open_tool', { detail: 'phone' }));
  };

  const CAT_STYLE: Record<string, string> = {
    '1': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '2': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '3': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '4': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '5': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '6': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '7': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '8': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '9': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
    '10': 'bg-neutral-950 text-neutral-300 ring-neutral-800',
  };

  return (
    <ToolWrapper title="Психологическая помощь" onClose={onClose}>
      <div className="flex-1 min-h-0 flex flex-col max-w-2xl mx-auto w-full select-none">
        {/* Светлая клиническая панель */}
        <div className="flex-1 min-h-0 overflow-y-auto rounded-[2rem] bg-[#000000] text-neutral-200 p-3 sm:p-4 space-y-3 shadow-[0_20px_60px_rgba(255,255,255,0.35)]">
          {/* Hero */}
          <div className="relative overflow-hidden rounded-[1.75rem] p-5 bg-gradient-to-br from-[#a3a3a3] via-[#8e8e8e] to-[#8f8f8f] text-black shadow-lg shadow-neutral-100/20">
            <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full bg-black/10" />
            <div className="absolute right-6 bottom-3 text-black/15 text-7xl font-black leading-none">+</div>
            <svg className="absolute left-0 right-0 bottom-0 w-full h-10 opacity-30" viewBox="0 0 400 40" preserveAspectRatio="none">
              <polyline fill="none" stroke="white" strokeWidth="2" points="0,22 70,22 85,22 95,6 105,36 115,22 190,22 205,22 215,10 225,32 235,22 400,22" />
            </svg>
            <div className="relative flex items-start justify-between gap-3">
              <div>
                <div className="inline-flex items-center gap-1.5 bg-black/20 backdrop-blur rounded-full px-2.5 py-1 text-[10px] font-semibold tracking-wide mb-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-neutral-700 animate-pulse" /> Служба работает 24/7
                </div>
                <h2 className="text-lg sm:text-xl font-bold leading-tight">Служба психологической помощи</h2>
                <p className="text-xs text-black/85 mt-1 max-w-xs">
                  Выберите номер из каталога горячих линий для экстренной связи
                </p>
              </div>
              <button
                onClick={handleOpenPhoneTool}
                className="px-3.5 py-2 bg-black text-neutral-300 hover:bg-neutral-950 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-md"
              >
                <Phone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">В телефон</span>
              </button>
            </div>

            <div className="relative grid grid-cols-3 gap-2 mt-4">
              {[
                ['10', 'линий'],
                ['24/7', 'приём'],
                ['100%', 'анонимно'],
              ].map(([n, l]) => (
                <div key={l} className="bg-black/15 backdrop-blur rounded-2xl py-2 text-center">
                  <div className="text-base font-bold leading-none">{n}</div>
                  <div className="text-[10px] text-black/80 mt-1">{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="px-1 text-[11px] font-semibold text-neutral-500 uppercase tracking-widest">Каталог горячих линий</div>

          {/* Directory */}
          <div className="space-y-2.5">
            {SUPPORT_LINES.map((line) => (
              <div
                key={line.id}
                className="bg-black border border-neutral-800/70 hover:border-neutral-700 p-3.5 rounded-[1.5rem] transition-all shadow-[0_4px_16px_rgba(204,204,204,0.06)] hover:shadow-[0_8px_24px_rgba(178,178,178,0.14)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-neutral-950 to-neutral-900 border border-neutral-900 flex items-center justify-center text-xl shrink-0 group-hover:scale-105 transition-transform">
                    {line.icon}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="text-[13px] font-bold text-neutral-200 leading-snug">{line.name}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ring-1 ${CAT_STYLE[line.id] || 'bg-neutral-950 text-neutral-400 ring-neutral-800'}`}>
                        {line.category}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-500 mb-2 leading-relaxed">{line.description}</p>
                    <div className="flex items-center gap-2 flex-wrap text-[11px]">
                      <span className="px-2.5 py-1 rounded-full bg-neutral-900 text-neutral-300 font-semibold tabular-nums">📞 {line.phone}</span>
                      <span className="text-neutral-600">{line.hours}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleStartCall(line)}
                  className="px-5 py-3 bg-gradient-to-r from-neutral-500 to-neutral-500 hover:from-neutral-600 hover:to-neutral-600 text-black font-bold text-xs rounded-full shadow-lg shadow-neutral-500/25 hover:shadow-neutral-500/40 transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2 shrink-0"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Позвонить</span>
                </button>
              </div>
            ))}
          </div>
          <div className="h-2" />
        </div>

        {/* Окно вызова */}
        {activeCall && (
          <div className="fixed inset-0 bg-neutral-100/60 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className="bg-black text-neutral-200 rounded-[2rem] max-w-sm w-full p-6 text-center shadow-2xl relative space-y-5">
              <button
                onClick={handleCloseCallModal}
                className="absolute top-4 right-4 text-neutral-600 hover:text-neutral-300 p-1.5 rounded-full hover:bg-neutral-900 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="relative w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-neutral-950 to-neutral-900 border border-neutral-900 flex items-center justify-center text-4xl">
                {callPhase === 'dialing' ? (
                  <>
                    <span className="absolute inset-0 rounded-full border-2 border-neutral-700 animate-ping" />
                    <PhoneCall className="w-9 h-9 text-neutral-500" />
                  </>
                ) : (
                  <span>{chosenOutcome?.icon}</span>
                )}
              </div>

              <div>
                <h3 className="text-base font-bold text-neutral-200 leading-snug">{activeCall.name}</h3>
                <p className="text-xs font-semibold text-neutral-400 mt-1 tabular-nums">{activeCall.phone}</p>
              </div>

              {callPhase === 'dialing' && (
                <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-900 space-y-3">
                  <div className="text-xs font-semibold text-neutral-400 tracking-wide animate-pulse">Соединение с абонентом...</div>
                  <svg viewBox="0 0 200 30" className="w-full h-8">
                    <polyline fill="none" stroke="#7a7a7a" strokeWidth="2" strokeLinecap="round" points="0,15 40,15 50,15 56,4 62,26 68,15 120,15 130,15 136,6 142,24 148,15 200,15" />
                  </svg>
                  <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-neutral-500 h-full w-full animate-progress" />
                  </div>
                </div>
              )}

              {callPhase === 'result' && chosenOutcome && (
                <div className="space-y-4 animate-in zoom-in duration-200">
                  <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-900 text-left space-y-1.5">
                    <div className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                      <span>{chosenOutcome.icon}</span>
                      <span>{chosenOutcome.title}</span>
                    </div>
                    <p className="text-xs leading-relaxed text-neutral-400">{chosenOutcome.subtitle}</p>
                  </div>

                  <div className="flex flex-col gap-2 pt-1">
                    <button
                      onClick={() => handleStartCall(activeCall)}
                      className="w-full py-3 bg-gradient-to-r from-neutral-500 to-neutral-500 text-black font-bold text-xs rounded-full transition-all cursor-pointer shadow-md flex items-center justify-center gap-2 active:scale-95"
                    >
                      <PhoneCall className="w-4 h-4" />
                      <span>Позвонить снова</span>
                    </button>

                    <button
                      onClick={handleOpenPhoneTool}
                      className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 font-semibold text-xs rounded-full transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Phone className="w-4 h-4 text-neutral-400" />
                      <span>Открыть в инструменте «Телефон»</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

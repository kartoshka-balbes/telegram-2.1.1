import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Radio, AlertTriangle, Zap } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const GeigerCounterTool: React.FC<ToolProps> = ({ onClose }) => {
  const [measuring, setMeasuring] = useState(false);
  const [radiationValue, setRadiationValue] = useState<number | null>(null);
  const [interferenceGlitch, setInterferenceGlitch] = useState(false);
  const [glassCracked, setGlassCracked] = useState(false);

  useEffect(() => {
    if (radiationValue === null) return;
    const interval = setInterval(() => {
      // Fluctuating value around 146x normal (~17.52)
      const base = 146 * 0.12;
      const fluc = (Math.random() * 2 - 1) * 1.8;
      setRadiationValue(parseFloat((base + fluc).toFixed(2)));
      soundManager.playBeep(1600, 0.04);
      if (Math.random() > 0.6) {
        soundManager.playStaticNoise(0.15);
      }
    }, 450);

    return () => clearInterval(interval);
  }, [radiationValue]);

  const handleMeasure = () => {
    setMeasuring(true);
    setRadiationValue(null);
    setGlassCracked(false);
    setInterferenceGlitch(true);
    soundManager.playBeep(800, 0.1);
    soundManager.playStaticNoise(0.6);

    // Click sound effects & light interference during measurement
    const interval = setInterval(() => {
      soundManager.playBeep(1200 + Math.random() * 400, 0.03);
      if (Math.random() > 0.5) {
        soundManager.playStaticNoise(0.2);
      }
    }, 180);

    const duration = Math.floor(Math.random() * 2000) + 2200;
    setTimeout(() => {
      clearInterval(interval);
      setMeasuring(false);
      setRadiationValue(17.52);
      setGlassCracked(true);
      // Play glass break sound and glitch sound
      soundManager.playGlassBreak();
      soundManager.playStaticNoise(0.8);
      setTimeout(() => {
        setInterferenceGlitch(false);
      }, 1000);
    }, duration);
  };

  return (
    <ToolWrapper title="Счётчик Гейгера" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col items-center justify-center p-4 text-center select-none relative overflow-hidden">
        {/* Light interference / Screen radiation glitch overlay */}
        {(measuring || interferenceGlitch) && (
          <div className="absolute inset-0 pointer-events-none z-30 bg-neutral-500/10 mix-blend-screen animate-pulse flex items-center justify-center">
            <div className="w-full h-full bg-[repeating-linear-gradient(0deg,rgba(255,255,255,0.15)_0px,rgba(255,255,255,0.15)_2px,transparent_2px,transparent_4px)] opacity-70" />
          </div>
        )}

        <div className={`bg-neutral-100 border-2 rounded-3xl p-6 w-full shadow-2xl flex flex-col items-center gap-5 transition-all relative ${
          glassCracked ? 'border-neutral-500/70 shadow-neutral-50/50' : 'border-neutral-200'
        }`}>
          {/* Glass crack visual overlay when cracked */}
          {glassCracked && (
            <div className="absolute top-3 right-4 px-2.5 py-1 bg-neutral-50/80 border border-neutral-500 text-neutral-600 rounded-lg text-[10px] font-black uppercase flex items-center gap-1 animate-bounce">
              <AlertTriangle className="w-3 h-3" />
              <span>ДАТЧИК ПОВРЕЖДЁН (ТРЕСНУЛ)</span>
            </div>
          )}

          <div className={`p-4 rounded-full border transition-all ${
            measuring
              ? 'bg-neutral-500/20 border-neutral-600 animate-spin'
              : glassCracked
              ? 'bg-neutral-500/20 border-neutral-500 animate-pulse'
              : 'bg-neutral-500/10 border-neutral-500/30'
          }`}>
            {measuring ? (
              <Zap className="w-16 h-16 text-neutral-700" />
            ) : (
              <Radio className={`w-16 h-16 ${glassCracked ? 'text-neutral-600' : 'text-neutral-600'}`} />
            )}
          </div>

          <div className="bg-neutral-50 border-2 border-neutral-200 rounded-2xl p-5 w-full font-mono relative overflow-hidden">
            {measuring && (
              <div className="absolute inset-0 bg-neutral-500/5 animate-pulse" />
            )}
            <span className="text-xs font-bold text-neutral-500 uppercase block mb-1">
              Уровень радиационного фона:
            </span>
            <div className={`text-3xl sm:text-4xl font-black min-h-[48px] flex items-center justify-center transition-colors ${
              glassCracked ? 'text-neutral-500 animate-pulse' : 'text-neutral-600'
            }`}>
              {measuring ? (
                <span className="animate-pulse text-neutral-700 text-xl font-bold flex items-center gap-2">
                  <span className="inline-block animate-spin">⚡</span> Замер фона...
                </span>
              ) : radiationValue !== null ? (
                `${radiationValue} мкЗв/ч`
              ) : (
                '0.00 мкЗв/ч'
              )}
            </div>
            {radiationValue !== null && (
              <span className="text-[10px] text-neutral-600 font-bold uppercase tracking-wider block mt-1">
                КРИТИЧЕСКОЕ ПРЕВЫШЕНИЕ (×146 НОРМЫ)
              </span>
            )}
          </div>

          <button
            onClick={handleMeasure}
            disabled={measuring}
            className={`w-full py-4 font-black text-base rounded-2xl uppercase tracking-wider shadow-lg transition-transform active:scale-95 cursor-pointer ${
              measuring
                ? 'bg-neutral-200 text-neutral-500 cursor-not-allowed'
                : 'bg-neutral-500 hover:bg-neutral-600 text-neutral-50 shadow-neutral-500/20'
            }`}
          >
            {measuring ? 'Идёт замер радиации...' : 'Измерить'}
          </button>
        </div>
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Lock, CreditCard, ShieldAlert, ArrowUpRight, History, QrCode, Sparkles, PlusCircle, PhoneCall } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

interface Operation {
  id: string;
  title: string;
  amount: number;
  type: 'in' | 'out';
  date: string;
}

export const SberbankTool: React.FC<ToolProps> = ({ onClose }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [balance, setBalance] = useState(17381836);
  const [creditError, setCreditError] = useState(false);
  const [cashback, setCashback] = useState(-14850);

  // Modals / Sections
  const [activeModal, setActiveModal] = useState<'history' | 'transfer' | 'qr' | 'cashback' | null>(null);
  
  // Form inputs
  const [transferComment, setTransferComment] = useState('');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const [operations, setOperations] = useState<Operation[]>([
    { id: '1', title: 'Оплата Бургер Кинг', amount: 890, type: 'out', date: 'Вчера, 19:45' },
    { id: '2', title: 'Перевод по СБП', amount: 1500, type: 'out', date: '04.08.2026' },
  ]);

  const handleGlobalClick = () => {
    if (!isLoggedIn) return;
    soundManager.playBeep(400, 0.05);

    setBalance((prev) => {
      if (prev <= 0) return prev - 10000;
      const next = Math.floor(prev / 2);
      return next <= 0 ? -10000 : next;
    });
  };

  const handleStealMoney = (e: React.MouseEvent) => {
    e.stopPropagation();
    const stolen = Math.random() < 0.5 ? 2 : 3;
    setBalance((prev) => prev + stolen);
    soundManager.playCoin();
    setOperations((prev) => [
      { id: Date.now().toString(), title: 'Украдено', amount: stolen, type: 'in', date: 'Только что' },
      ...prev,
    ]);
    setStatusMsg(`+${stolen} ₽ успешно украдено на счёт!`);
    setTimeout(() => setStatusMsg(null), 2500);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) {
      setLoginError('Введите пароль!');
      return;
    }
    setIsLoggedIn(true);
  };

  const handleTakeCredit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCreditError(true);
    setTimeout(() => setCreditError(false), 3000);
  };

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const val = 1000;
    setBalance((prev) => prev - val);
    setOperations((prev) => [
      { id: Date.now().toString(), title: `Перевод (${transferComment || 'Без комментария'})`, amount: val, type: 'out', date: 'Только что' },
      ...prev,
    ]);
    setStatusMsg(`Перевод с комментарием "${transferComment || '-'}" успешно отправлен!`);
    setTransferComment('');
    setTimeout(() => setStatusMsg(null), 3000);
  };

  return (
    <ToolWrapper title="Сбербанк" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div onClick={handleGlobalClick} className="flex-1 flex flex-col justify-between max-w-md mx-auto w-full py-3 font-mono select-none">
        {!isLoggedIn ? (
          /* Login Screen */
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <div className="w-20 h-20 rounded-full bg-neutral-400 flex items-center justify-center text-4xl text-black font-bold mb-6 shadow-xl shadow-neutral-400/30">
              🏦
            </div>
            <h2 className="text-2xl font-bold text-black mb-6 uppercase tracking-wider">
              Вход в Сбербанк Онлайн
            </h2>
            <form onSubmit={handleLogin} className="w-full space-y-4" onClick={(e) => e.stopPropagation()}>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setLoginError('');
                  }}
                  placeholder="Введите пароль..."
                  className="w-full bg-neutral-100 border border-neutral-300 rounded-none px-4 py-3 text-black text-center outline-none focus:border-neutral-500"
                />
                <Lock className="w-5 h-5 text-neutral-500 absolute left-4 top-3.5" />
              </div>
              {loginError && (
                <div className="text-neutral-600 text-xs font-bold uppercase animate-pulse">{loginError}</div>
              )}
              <button
                type="submit"
                className="w-full py-3.5 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black text-lg rounded-none shadow-lg transition-transform active:scale-95 cursor-pointer uppercase"
              >
                Войти
              </button>
            </form>
          </div>
        ) : (
          /* Personal Cabinet */
          <div className="flex-1 flex flex-col gap-4 overflow-y-auto pr-1">
            {/* Account Card & Steal action */}
            <div className="bg-gradient-to-br from-neutral-200 to-neutral-50 border-2 border-neutral-400 rounded-none p-5 shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Личный счёт пользователя
                  </div>
                  <div
                    className={`text-2xl sm:text-3xl font-black tracking-tight transition-colors ${
                      balance < 0 ? 'text-neutral-600' : 'text-black'
                    }`}
                  >
                    {balance.toLocaleString('ru-RU')} ₽
                  </div>
                  <div className="text-[10px] text-neutral-700 mt-1 font-bold">
                    Кэшбэк: {cashback.toLocaleString('ru-RU')} СберСпасибо
                  </div>
                </div>

                {/* Steal Button - Always available (+2 or +3 on click) */}
                <button
                  type="button"
                  onClick={handleStealMoney}
                  className="px-4 py-2.5 bg-gradient-to-r from-neutral-500 to-neutral-400 hover:from-neutral-600 hover:to-neutral-500 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg hover:scale-105 active:scale-95 transition-all cursor-pointer border border-neutral-700 flex items-center gap-1.5 shrink-0"
                >
                  <span>💰</span>
                  <span>Украсть</span>
                </button>
              </div>
            </div>

            {/* Floating Status Message Toast (Overlay: does not shift UI) */}
            {statusMsg && (
              <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 max-w-sm w-[90%] bg-neutral-50/95 backdrop-blur-md border-2 border-neutral-500 p-3 text-neutral-700 text-center font-bold text-xs shadow-2xl animate-in zoom-in pointer-events-none rounded-xl">
                {statusMsg}
              </div>
            )}

            {/* Floating Error Toast for credit (Overlay: does not shift UI) */}
            {creditError && (
              <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 max-w-sm w-[90%] bg-neutral-100/95 backdrop-blur-md border-2 border-neutral-500 p-3 text-black text-center font-bold text-xs flex items-center justify-center gap-2 shadow-2xl animate-in zoom-in pointer-events-none rounded-xl">
                <ShieldAlert className="w-5 h-5 text-neutral-600 shrink-0" />
                <span>Отказано: плохая кредитная история пользователя!</span>
              </div>
            )}

            {/* Quick Action Grid */}
            <div className="grid grid-cols-3 gap-2" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={() => setActiveModal('transfer')}
                className="p-3 bg-neutral-100 border border-neutral-200 hover:border-neutral-500 text-left flex items-center gap-2 cursor-pointer"
              >
                <PhoneCall className="w-5 h-5 text-neutral-600" />
                <span className="text-xs font-bold text-black">Перевод</span>
              </button>

              <button
                onClick={() => setActiveModal('history')}
                className="p-3 bg-neutral-100 border border-neutral-200 hover:border-neutral-500 text-left flex items-center gap-2 cursor-pointer"
              >
                <History className="w-5 h-5 text-neutral-600" />
                <span className="text-xs font-bold text-black">История</span>
              </button>

              <button
                onClick={() => setActiveModal('qr')}
                className="p-3 bg-neutral-100 border border-neutral-200 hover:border-neutral-500 text-left flex items-center gap-2 cursor-pointer"
              >
                <QrCode className="w-5 h-5 text-neutral-600" />
                <span className="text-xs font-bold text-black">QR код</span>
              </button>
            </div>

            <button
              onClick={() => setActiveModal('cashback')}
              className="p-3 bg-gradient-to-r from-neutral-50 to-neutral-100 border border-neutral-400/50 flex items-center justify-between cursor-pointer"
              onClickCapture={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-neutral-600" />
                <div>
                  <div className="text-xs font-bold text-black">Кэшбэк СберСпасибо</div>
                  <div className="text-[10px] text-neutral-600 font-bold">{cashback} баллов</div>
                </div>
              </div>
              <span className="text-[10px] bg-neutral-400 text-black px-2 py-1 font-black uppercase">Задолженность</span>
            </button>

            {/* Credit Button */}
            <button
              onClick={handleTakeCredit}
              className="bg-neutral-100 border border-neutral-200 hover:border-neutral-500/50 p-3 flex items-center justify-between text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <CreditCard className="w-5 h-5 text-neutral-600" />
                <div>
                  <div className="font-bold text-black text-xs">Взять кредит</div>
                  <div className="text-[10px] text-neutral-500">До 10 000 000 ₽</div>
                </div>
              </div>
              <span className="text-[9px] px-2 py-0.5 bg-neutral-50 text-neutral-700 font-bold border border-neutral-200 uppercase">
                Заблокировано
              </span>
            </button>

            {/* Modal Windows */}
            {activeModal === 'transfer' && (
              <div className="p-3 bg-neutral-50 border border-neutral-500 space-y-2" onClick={(e) => e.stopPropagation()}>
                <div className="text-xs font-bold text-neutral-600 uppercase">Перевод денег</div>
                <form onSubmit={handleTransferSubmit} className="space-y-2">
                  <input
                    type="text"
                    value={transferComment}
                    onChange={(e) => setTransferComment(e.target.value)}
                    placeholder="Комментарий..."
                    className="w-full bg-neutral-100 border border-neutral-200 p-2 text-xs text-black outline-none focus:border-neutral-500"
                  />
                  <div className="flex gap-2">
                    <button type="submit" className="flex-1 py-1.5 bg-neutral-500 text-neutral-50 font-bold text-xs uppercase">
                      Перевести
                    </button>
                    <button type="button" onClick={() => setActiveModal(null)} className="px-3 bg-neutral-200 text-black text-xs font-bold">
                      Закрыть
                    </button>
                  </div>
                </form>
              </div>
            )}

            {activeModal === 'history' && (
              <div className="p-3 bg-neutral-50 border border-neutral-500 space-y-2" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-neutral-600 uppercase">История операций</span>
                  <button onClick={() => setActiveModal(null)} className="text-xs text-neutral-600">✕</button>
                </div>
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {operations.map((op) => (
                    <div key={op.id} className="p-2 bg-neutral-100 border border-neutral-200 flex justify-between items-center text-xs">
                      <div>
                        <div className="font-bold text-black">{op.title}</div>
                        <div className="text-[9px] text-neutral-500">{op.date}</div>
                      </div>
                      <span className={`font-black ${op.type === 'in' ? 'text-neutral-600' : 'text-neutral-600'}`}>
                        {op.type === 'in' ? '+' : '-'}{op.amount.toLocaleString('ru-RU')} ₽
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeModal === 'qr' && (
              <div className="p-4 bg-neutral-50 border border-neutral-500 text-center space-y-3" onClick={(e) => e.stopPropagation()}>
                <div className="text-xs font-bold text-neutral-600 uppercase">Оплата по QR-коду</div>
                <div className="w-32 h-32 mx-auto bg-black p-2 border-2 border-neutral-600 flex items-center justify-center">
                  <QrCode className="w-24 h-24 text-neutral-50" />
                </div>
                <p className="text-[10px] text-neutral-600">Покажите QR-код кассиру для списания бонусов и оплаты</p>
                <button onClick={() => setActiveModal(null)} className="w-full py-1.5 bg-neutral-200 text-black text-xs font-bold uppercase">
                  Закрыть
                </button>
              </div>
            )}

            {activeModal === 'cashback' && (
              <div className="p-4 bg-neutral-50 border border-neutral-500 text-center space-y-3" onClick={(e) => e.stopPropagation()}>
                <div className="text-xs font-bold text-neutral-600 uppercase">Задолженность СберСпасибо</div>
                <div className="text-2xl font-black text-neutral-600">{cashback.toLocaleString('ru-RU')} БАЛЛОВ</div>
                <p className="text-[10px] text-neutral-600">Требуется погасить задолженность по СберСпасибо</p>
                <button onClick={() => setActiveModal(null)} className="w-full py-1 bg-neutral-200 text-black text-xs font-bold uppercase">
                  Закрыть
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

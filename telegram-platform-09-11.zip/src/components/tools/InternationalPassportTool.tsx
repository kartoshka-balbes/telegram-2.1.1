import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { FileText, CheckCircle2, Shield, DollarSign, Send } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const InternationalPassportTool: React.FC<ToolProps> = ({ onClose }) => {
  const [passportType, setPassportType] = useState<'10' | '5'>('10');
  const [fullName, setFullName] = useState('Иванов Иван Иванович');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playBeep(1200, 0.15);
    setIsSubmitted(true);
  };

  return (
    <ToolWrapper title="Оформление загранпаспорта (Госуслуги)" onClose={onClose} headerColor="bg-neutral-50 border-neutral-100">
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full py-2 font-mono text-xs select-none space-y-3">
        {/* Header Badge */}
        <div className="bg-neutral-100 border-2 border-neutral-500/80 p-4 rounded-2xl space-y-2 shadow-2xl">
          <div className="flex items-center gap-2 text-neutral-600 font-bold text-xs uppercase">
            <Shield className="w-5 h-5 text-neutral-600 shrink-0" />
            <span>Госуслуги: Подача заявления на загранпаспорт</span>
          </div>
          <p className="text-[11px] text-neutral-700">
            Госпошлина: <span className="text-neutral-600 font-black">{passportType === '10' ? '5 000 ₽' : '2 000 ₽'}</span>
          </p>
        </div>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="bg-neutral-100 border border-neutral-200 p-4 rounded-2xl space-y-3">
            {/* Passport Type Selector */}
            <div>
              <label className="text-[10px] text-neutral-600 block font-bold mb-1 uppercase">Срок действия паспорта:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    soundManager.playBeep(800, 0.05);
                    setPassportType('10');
                  }}
                  className={`p-2.5 rounded-xl font-bold text-xs cursor-pointer border transition-all ${
                    passportType === '10'
                      ? 'bg-neutral-400 text-black border-neutral-600 shadow'
                      : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                  }`}
                >
                  10 лет (Биометрический)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    soundManager.playBeep(800, 0.05);
                    setPassportType('5');
                  }}
                  className={`p-2.5 rounded-xl font-bold text-xs cursor-pointer border transition-all ${
                    passportType === '5'
                      ? 'bg-neutral-400 text-black border-neutral-600 shadow'
                      : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                  }`}
                >
                  5 лет (Старый образец)
                </button>
              </div>
            </div>

            {/* FIO Input */}
            <div>
              <label className="text-[10px] text-neutral-600 block font-bold mb-1 uppercase">ФИО заявителя:</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-200 focus:border-neutral-500 rounded-xl p-2.5 text-black font-bold outline-none text-xs"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-neutral-400 hover:bg-neutral-500 text-black font-black text-xs uppercase rounded-xl cursor-pointer shadow-lg flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Подать заявление & Оплатить пошлину</span>
            </button>
          </form>
        ) : (
          <div className="p-5 bg-neutral-50 border-2 border-neutral-500 rounded-2xl text-center space-y-2 animate-in zoom-in">
            <CheckCircle2 className="w-10 h-10 text-neutral-600 mx-auto" />
            <h3 className="font-black text-neutral-700 uppercase text-xs">ЗАЯВЛЕНИЕ №7700-2026 ПРИНЯТО!</h3>
            <p className="text-[11px] text-neutral-800">Ваш загранпаспорт на {passportType} лет успешно передан в МВД РФ на изготовление.</p>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const DisinfectionTool: React.FC<ToolProps> = ({ onClose }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [completed, setCompleted] = useState(false);

  const handleStartScan = () => {
    setIsScanning(true);
    setCompleted(false);
    soundManager.playSiren();

    setTimeout(() => {
      setIsScanning(false);
      setCompleted(true);
      soundManager.playMicrowaveDing();
    }, 5500);
  };

  return (
    <ToolWrapper title="Дезинфекция" onClose={onClose}>
      <div className="relative flex-1 flex flex-col items-center justify-center p-4">
        {/* Irregular small "Начать" button in top-left corner */}
        {!isScanning && !completed && (
          <button
            onClick={handleStartScan}
            className="absolute top-2 left-2 px-3 py-1 bg-neutral-600 hover:bg-neutral-700 text-neutral-50 font-black text-xs rounded shadow-md border border-white cursor-pointer transform -rotate-6 hover:rotate-0 transition-transform"
          >
            Начать
          </button>
        )}

        {/* Instructions */}
        {!isScanning && !completed && (
          <div className="text-center max-w-sm bg-neutral-100 border border-neutral-200 rounded-3xl p-8 shadow-2xl">
            <div className="text-7xl mb-6 animate-pulse">✋</div>
            <h2 className="text-xl font-bold text-black leading-relaxed">
              Приложите руку к экрану, а затем нажмите кнопку для дезинфекции.
            </h2>
          </div>
        )}

        {/* Scanning state */}
        {isScanning && (
          <div className="text-center flex flex-col items-center justify-center">
            <div className="relative w-64 h-64 border-4 border-neutral-600/40 rounded-3xl overflow-hidden flex items-center justify-center mb-6 bg-neutral-50/20 shadow-2xl">
              <div className="absolute inset-x-0 h-1 bg-neutral-600 shadow-[0_0_15px_#5c5c5c] animate-scan" />
              <div className="text-8xl animate-pulse">✋</div>
            </div>
            <p className="text-xl font-black text-neutral-600 animate-pulse tracking-wider uppercase">
              ИДЁТ СВЕРХМОЩНАЯ ДЕЗИНФЕКЦИЯ... (5 сек)
            </p>
          </div>
        )}

        {/* Completed state */}
        {completed && (
          <div className="text-center bg-neutral-50/40 border-2 border-neutral-500 rounded-3xl p-8 max-w-sm shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="text-7xl mb-4">✨</div>
            <h2 className="text-2xl font-black text-neutral-600 mb-4 uppercase">
              рука продезинфицирована!
            </h2>
            <p className="text-neutral-700 text-sm mb-6">
              Все бактерии и вирусы успешно уничтожены квантовым лазером приложения.
            </p>
            <button
              onClick={() => setCompleted(false)}
              className="w-full py-3 bg-neutral-500 hover:bg-neutral-600 text-neutral-50 font-black rounded-xl uppercase tracking-wider cursor-pointer"
            >
              Повторить
            </button>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};

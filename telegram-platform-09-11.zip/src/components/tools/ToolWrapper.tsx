import React from 'react';
import { ArrowLeft, X } from 'lucide-react';

interface ToolWrapperProps {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  headerColor?: string;
  hideDefaultClose?: boolean;
}

// Оформление в духе белой галереи: белый холст, чёрный текст, линии 1px
export const ToolWrapper: React.FC<ToolWrapperProps> = ({ title, onClose, children, hideDefaultClose = false }) => {
  return (
    <div className="fixed inset-0 bg-white text-black z-40 flex flex-col overflow-hidden">
      {/* Шапка */}
      <div className="relative z-10 px-5 py-2.5 flex items-center justify-between gap-3 bg-white border-b border-black">
        <button onClick={onClose} className="flex items-center gap-1.5 text-[15px] underline cursor-pointer bg-transparent border-0 p-1">
          <ArrowLeft className="w-4 h-4" />
          <span>Назад</span>
        </button>

        <h2 className="text-[12px] uppercase tracking-[0.02em] font-medium truncate min-w-0 text-center">{title}</h2>

        {!hideDefaultClose ? (
          <button onClick={onClose} className="p-1.5 cursor-pointer bg-transparent border-0" title="Закрыть инструмент" aria-label="Закрыть">
            <X className="w-5 h-5" />
          </button>
        ) : (
          <div className="w-8" />
        )}
      </div>

      {/* Контент */}
      <div className="flex-1 overflow-y-auto relative z-10 p-4 sm:p-6 flex flex-col">{children}</div>
    </div>
  );
};

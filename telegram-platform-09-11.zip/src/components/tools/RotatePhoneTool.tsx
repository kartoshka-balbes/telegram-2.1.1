import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { RotateCw, Smartphone } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

export const RotatePhoneTool: React.FC<ToolProps> = ({ onClose }) => {
  const [rotation, setRotation] = useState<number>(0);

  const handleRotate = () => {
    soundManager.playBeep(900, 0.08);
    setRotation((prev) => (prev + 90) % 360);
  };

  const isLandscape = rotation === 90 || rotation === 270;

  return (
    <ToolWrapper title="Поверните телефон" onClose={onClose} headerColor="bg-[#eaeaea] border-[#d6d6d6]">
      <div className="flex-1 w-full h-full min-h-[75vh] flex flex-col items-center justify-between p-4 overflow-hidden bg-[#ffffff] select-none font-sans">
        
        {/* Top Info Bar */}
        <div className="w-full max-w-sm bg-[#ededed] border border-[#d8d8d8] rounded-2xl p-3 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[#5c5c5c]" />
            <span className="text-xs font-bold text-neutral-800">
              Ориентация: <span className="text-[#5c5c5c]">{isLandscape ? 'Альбомная' : 'Портретная'} ({rotation}°)</span>
            </span>
          </div>

          <span className="text-[10px] font-mono text-neutral-600 bg-black/5 px-2 py-0.5 rounded-full border border-black/10">
            Датчик гироскопа
          </span>
        </div>

        {/* Interactive Rotating Vector Smartphone */}
        <div className="relative my-auto flex items-center justify-center p-6">
          <div
            onClick={handleRotate}
            className="cursor-pointer transition-transform duration-500 ease-out"
            style={{
              transform: `rotate(${rotation}deg)`,
            }}
          >
            {/* Phone Body with Titanium Frame & Curved Corners */}
            <div className="w-48 h-84 sm:w-56 sm:h-96 bg-neutral-50 border-4 border-neutral-300 rounded-[44px] shadow-[0_0_50px_rgba(255,255,255,0.9)] p-2 relative flex flex-col items-center justify-between ring-2 ring-neutral-200">
              
              {/* Dynamic Island / Speaker Notch */}
              <div className="w-20 h-4 bg-white rounded-full z-20 flex items-center justify-end px-2 border border-neutral-200">
                <div className="w-2 h-2 rounded-full bg-neutral-50 border border-neutral-400/40" />
              </div>

              {/* OLED Screen Content */}
              <div className="w-full flex-1 bg-gradient-to-b from-[#ececec] via-[#ffffff] to-white rounded-[34px] overflow-hidden p-4 flex flex-col items-center justify-between text-center relative border border-black/5 my-1">
                
                {/* Status Bar */}
                <div className="w-full flex justify-between items-center text-[10px] font-mono text-neutral-600 px-1">
                  <span>12:00</span>
                  <div className="flex items-center gap-1">
                    <span>5G</span>
                    <span>100%</span>
                  </div>
                </div>

                {/* Animated Gyro Graphic */}
                <div className="flex flex-col items-center gap-3 my-auto">
                  <div className="w-16 h-16 rounded-full bg-[#5c5c5c]/10 border-2 border-[#5c5c5c] flex items-center justify-center shadow-[0_0_20px_rgba(92,92,92,0.3)] animate-pulse">
                    <RotateCw className="w-8 h-8 text-[#5c5c5c] animate-spin-slow" />
                  </div>
                  <h3 className="font-extrabold text-black text-xs uppercase tracking-wider">
                    {isLandscape ? 'ГОРИЗОНТАЛЬНЫЙ РЕЖИМ' : 'ПОВЕРНИТЕ УСТРОЙСТВО'}
                  </h3>
                  <p className="text-[10px] text-neutral-600 leading-tight">
                    Нажмите на экран телефона для поворота на 90 градусов
                  </p>
                </div>

                {/* Home Indicator Bar */}
                <div className="w-24 h-1 bg-black/40 rounded-full" />
              </div>

              {/* Bottom Volume / Bezel indicator */}
              <div className="h-2" />
            </div>
          </div>
        </div>

        {/* Rotate Action Button */}
        <div className="w-full max-w-sm space-y-2">
          <button
            onClick={handleRotate}
            className="w-full py-3.5 bg-[#5c5c5c] hover:bg-[#3a3a3a] text-white font-black text-xs uppercase rounded-2xl flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(92,92,92,0.3)] transition-all active:scale-95 cursor-pointer"
          >
            <RotateCw className="w-4 h-4" />
            <span>Повернуть телефон (+90°)</span>
          </button>
        </div>

      </div>
    </ToolWrapper>
  );
};

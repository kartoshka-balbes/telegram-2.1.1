import React, { StrictMode, ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  declare props: Readonly<ErrorBoundaryProps>;
  declare state: Readonly<ErrorBoundaryState>;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('App runtime error caught by boundary:', error, errorInfo);
  }

  handleReset = () => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {}
    window.location.reload();
  };

  render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full bg-neutral-50 text-black flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-neutral-500/20 text-neutral-600 flex items-center justify-center text-3xl mb-4 border border-neutral-500/30 shadow-lg shadow-neutral-500/10">
            ⚠️
          </div>
          <h1 className="text-2xl font-bold mb-2">Произошла ошибка загрузки</h1>
          <p className="text-neutral-600 text-sm max-w-md mb-6">
            Интерфейс приложения перезапускается. Если ошибка повторяется, нажмите кнопку ниже для сброса временных данных.
          </p>
          <button
            onClick={this.handleReset}
            className="px-6 py-2.5 bg-neutral-500 hover:bg-neutral-400 active:scale-95 text-neutral-50 font-semibold rounded-xl transition-all shadow-lg shadow-neutral-500/20 cursor-pointer"
          >
            Перезапустить приложение
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>
  );
}
